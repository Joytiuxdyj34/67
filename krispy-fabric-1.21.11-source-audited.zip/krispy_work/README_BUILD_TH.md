# Krispy Fabric Client — Minecraft 1.21.11

โปรเจกต์นี้เป็นซอร์สโค้ด Krispy ที่อยู่ในไฟล์ ZIP ต้นฉบับ โดยคงโมดูลจากซอร์สเดิมไว้ และเพิ่มการระบุ Fabric API เป็น dependency ใน metadata ให้ชัดเจน ไม่มีการสร้าง JAR ปลอมแทนไฟล์ที่ build ไม่สำเร็จ

## เวอร์ชันที่ตั้งค่าไว้
- Minecraft: 1.21.11
- Java: 21
- Fabric Loader: 0.19.3
- Fabric API: 0.141.6+1.21.11
- Fabric Loom: 1.17.13
- Yarn mappings: 1.21.11+build.6

## Build
1. ติดตั้ง JDK 21
2. ให้เครื่องเชื่อมต่ออินเทอร์เน็ต เพื่อให้ Gradle ดาวน์โหลด Gradle distribution และ dependencies
3. Linux/macOS: `chmod +x gradlew` แล้วรัน `./gradlew clean build`
4. Windows: รัน `gradlew.bat clean build`
5. หาก build สำเร็จ ไฟล์ JAR จะอยู่ใน `build/libs/` (เลือก JAR หลัก ไม่ใช่ sources JAR หากมี)
6. คัดลอก JAR ไปยังโฟลเดอร์ `.minecraft/mods` พร้อม Fabric Loader และ Fabric API เวอร์ชันที่ตรงกัน

## สถานะการตรวจสอบในสภาพแวดล้อมนี้
ได้ตรวจดูโครงสร้างซอร์สและการตั้งค่าเวอร์ชันแล้ว แต่ยังยืนยันการคอมไพล์ไม่ได้: การเรียก Gradle Wrapper พยายามดาวน์โหลด Gradle 9.5.1 จาก `services.gradle.org` แล้วล้มเหลวด้วย `UnknownHostException` เนื่องจากสภาพแวดล้อมนี้เข้าถึง DNS/อินเทอร์เน็ตไม่ได้ จึงไม่มีการแนบ JAR ที่อ้างว่าใช้งานได้ และยังไม่ได้ทดสอบเปิดเกมจริง

## หมายเหตุ
ซอร์สมีระบบ GUI และโมดูลจำนวนมากอยู่แล้ว การมีไฟล์ซอร์สหรือการตั้งค่าเวอร์ชันที่ถูกต้องไม่ใช่หลักฐานว่าแต่ละโมดูลทำงานได้ครบในเกมจริง จำเป็นต้อง build และทดสอบกับ Minecraft 1.21.11/Fabric ในสภาพแวดล้อมที่ดาวน์โหลด dependencies ได้ก่อนเผยแพร่เป็นรุ่นใช้งานจริง
