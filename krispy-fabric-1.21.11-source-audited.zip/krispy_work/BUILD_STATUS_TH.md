# รายงานสถานะ Build — Krispy / Minecraft Fabric 1.21.11

วันที่ตรวจสอบ: 13 ตุลาคม 2026

## สิ่งที่ตรวจสอบได้
- พบซอร์ส Java 376 ไฟล์
- `fabric.mod.json` ระบุ Minecraft `=1.21.11`, Java `>=21`, Fabric Loader `>=0.19.3` และ entrypoint `krispy.Main`
- ตรวจสอบแล้วว่า `client.mixins.json` เป็น JSON ที่อ่านได้ และชื่อ mixin/accessor ที่ประกาศมีไฟล์ Java ตรงกันทั้งหมด
- โปรเจกต์ตั้งค่า Java release 21 และมี Fabric Loom / Fabric API dependencies

## ผลการลอง Build
สั่ง `./gradlew build --no-daemon` แล้ว แต่หยุดก่อนเริ่มคอมไพล์ เนื่องจาก Wrapper ต้องดาวน์โหลด Gradle 9.5.1 จาก `services.gradle.org` และสภาพแวดล้อมนี้ไม่สามารถ resolve โฮสต์ได้ (`UnknownHostException: services.gradle.org`).

นี่เป็นข้อจำกัดการเข้าถึงเครือข่าย ไม่ใช่หลักฐานว่าซอร์สคอมไพล์ผ่านหรือไม่ผ่าน จึงยังไม่สามารถยืนยันการสร้าง JAR, การเปิดเกม, การทำงานของ Click GUI หรือการทำงานของทุกโมดูลได้

## วิธี Build บนเครื่องที่มีอินเทอร์เน็ต
1. ติดตั้ง Java 21 (ตรวจสอบด้วย `java -version`).
2. แตก ZIP ไปยังโฟลเดอร์ที่เขียนไฟล์ได้
3. เปิด Terminal ในโฟลเดอร์โปรเจกต์ที่มี `gradlew`
4. Linux/macOS: `chmod +x gradlew && ./gradlew clean build`
   Windows: `gradlew.bat clean build`
5. หาก Build สำเร็จ ไฟล์ JAR จะอยู่ใน `build/libs/` (เลือกไฟล์ที่ไม่ใช่ `-sources.jar` หากมี)
6. ติดตั้ง Fabric Loader สำหรับ Minecraft 1.21.11 และใส่ JAR กับ Fabric API เวอร์ชันที่ตรงกันในโฟลเดอร์ `mods`
7. ทดสอบในโปรไฟล์แยกก่อน แล้วตรวจ `logs/latest.log` หากเกมปิดตัวเอง

## ข้อควรระวัง
อย่านำ JAR ไปใช้เป็นไฟล์พร้อมใช้งานจนกว่า `clean build` จะผ่าน และเกมเปิดได้จริงอย่างน้อยหนึ่งครั้ง การตรวจ JSON และการมีไฟล์ mixin ไม่สามารถแทนการคอมไพล์หรือการทดสอบในเกมได้
