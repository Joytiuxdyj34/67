package krispy.feature;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import java.util.zip.Deflater;
import java.util.zip.DeflaterOutputStream;
import krispy.feature.UiTextureAtlas.TexturePixels;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
final class CharacterTextureAtlas {
   private static final int SIZE = 2048;
   private static final int PAD = 4;
   private static final int MAX_SIDE = 8192;
   final int width;
   final int height;
   private final int[] pixels;
   private final Map<Integer, float[]> regions = new HashMap<>();
   private final Map<Integer, int[]> tiles = new HashMap<>();

   private CharacterTextureAtlas(int var1, int var2) {
      this.width = var1;
      this.height = var2;
      this.pixels = new int[var1 * var2];
   }

   static CharacterTextureAtlas pack(GlbDocument var0, Map<Integer, float[]> var1, UiTextureAtlas var2) throws IOException {
      LinkedHashMap var3 = new LinkedHashMap();
      HashMap var4 = new HashMap();
      HashMap var5 = new HashMap();

      for (Entry var7 : var1.entrySet()) {
         float[] var8 = (float[])var7.getValue();
         int var9 = (int)Math.floor((double)(var8[0] + 0.0010000000474974513F));
         int var10 = (int)Math.floor((double)(var8[1] + 0.0010000000474974513F));
         int var11 = Math.min(
            8,
            Math.max(1, (int)Math.ceil((double)(var8[2] - 0.0010000000474974513F)) - var9)
         );
         int var12 = Math.min(
            8,
            Math.max(1, (int)Math.ceil((double)(var8[3] - 0.0010000000474974513F)) - var10)
         );
         UiTextureAtlas.TexturePixels var13 = tile(baseColor(var0, (Integer)var7.getKey(), var2), var11, var12);
         Integer var10001 = (Integer)var7.getKey();
         int[] var10002 = new int[4];
         var10002[0] = var9;
         var10002[1] = var10;
         var10002[2] = var11;
         var10002[3] = var12;
         var5.put(var10001, var10002);
         float var14 = (var8[0] - (float)var9) / (float)var11;
         float var15 = (var8[1] - (float)var10) / (float)var12;
         float var16 = (var8[2] - (float)var9) / (float)var11;
         float var17 = (var8[3] - (float)var10) / (float)var12;
         int var18 = clamp(
            (int)Math.floor((double)(var14 * (float)var13.width())) - (2),
            0,
            var13.width() - (1)
         );
         int var19 = clamp(
            (int)Math.floor((double)(var15 * (float)var13.height())) - (2), 0, var13.height() - (1)
         );
         int var20 = clamp(
            (int)Math.ceil((double)(var16 * (float)var13.width())) + (2), var18 + (1), var13.width()
         );
         int var21 = clamp(
            (int)Math.ceil((double)(var17 * (float)var13.height())) + (2), var19 + (1), var13.height()
         );
         var3.put((Integer)var7.getKey(), crop(var13, var18, var19, var20, var21));
         var10001 = (Integer)var7.getKey();
         float[] var28 = new float[4];
         var28[0] = (float)var18 / (float)var13.width();
         var28[1] = (float)var19 / (float)var13.height();
         var28[2] = (float)var20 / (float)var13.width();
         var28[3] = (float)var21 / (float)var13.height();
         var4.put(var10001, var28);
      }

      double var22 = 0.0;

      for (Object var25Object : var3.values()) { UiTextureAtlas.TexturePixels var25 = (UiTextureAtlas.TexturePixels)var25Object;
         var22 += (double)(var25.width() + (8)) * (double)(var25.height() + (8));
      }

      double var24 = Math.min(
         1.0,
         Math.sqrt(
            3858759.68
               / Math.max(1.0, var22)
         )
      );

      while (true) {
         CharacterTextureAtlas var26 = tryPack(var3, var4, var24);
         if (var26 != null) {
            var26.tiles.putAll(var5);
            return var26;
         }

         var24 *= 0.93;
      }
   }

   private static UiTextureAtlas.TexturePixels baseColor(GlbDocument var0, int var1, UiTextureAtlas var2) throws IOException {
      byte[] var3 = var0.baseColorImage(var1);
      UiTextureAtlas.TexturePixels var4 = var3 == null
         ? new UiTextureAtlas.TexturePixels(
            4, 4, filled(16, -1)
         )
         : var2.decode(var3);
      float[] var5 = var0.baseColorFactor(var1);
      if (var5[0] == 1.0F
         && var5[1] == 1.0F
         && var5[2] == 1.0F
         && var5[3] == 1.0F) {
         return var4;
      } else {
         for (int var6 = 0; var6 < (3); var6++) {
            var5[var6] = (float)Math.pow((double)var5[var6], 0.45454545454545453);
         }

         int[] var13 = new int[var4.argb().length];

         for (int var7 = 0; var7 < var13.length; var7++) {
            int var8 = var4.argb()[var7];
            int var9 = Math.round((float)(var8 >>> (24)) * var5[3]);
            int var10 = Math.round((float)(var8 >> (16) & (255)) * var5[0]);
            int var11 = Math.round((float)(var8 >> (8) & (255)) * var5[1]);
            int var12 = Math.round((float)(var8 & (255)) * var5[2]);
            var13[var7] = var9 << (24) | var10 << (16) | var11 << (8) | var12;
         }

         return new UiTextureAtlas.TexturePixels(var4.width(), var4.height(), var13);
      }
   }

   private static int[] filled(int var0, int var1) {
      int[] var2 = new int[var0];
      Arrays.fill(var2, var1);
      return var2;
   }

   private static UiTextureAtlas.TexturePixels tile(UiTextureAtlas.TexturePixels var0, int var1, int var2) {
      if (var1 == (1) && var2 == (1)) {
         return var0;
      } else {
         if (var0.width() * var1 > (8192) || var0.height() * var2 > (8192)) {
            var0 = resize(
               var0,
               Math.max(1, Math.min(var0.width(), (8192) / var1)),
               Math.max(1, Math.min(var0.height(), (8192) / var2))
            );
         }

         int var3 = var0.width() * var1;
         int var4 = var0.height() * var2;
         int[] var5 = new int[var3 * var4];

         for (int var6 = 0; var6 < var4; var6++) {
            for (int var7 = 0; var7 < var3; var7++) {
               var5[var6 * var3 + var7] = var0.argb()[var6 % var0.height() * var0.width() + var7 % var0.width()];
            }
         }

         return new UiTextureAtlas.TexturePixels(var3, var4, var5);
      }
   }

   private static UiTextureAtlas.TexturePixels crop(UiTextureAtlas.TexturePixels var0, int var1, int var2, int var3, int var4) {
      int var5 = var3 - var1;
      int var6 = var4 - var2;
      int[] var7 = new int[var5 * var6];

      for (int var8 = 0; var8 < var6; var8++) {
         System.arraycopy(var0.argb(), (var2 + var8) * var0.width() + var1, var7, var8 * var5, var5);
      }

      return new UiTextureAtlas.TexturePixels(var5, var6, var7);
   }

   private static CharacterTextureAtlas tryPack(Map<Integer, UiTextureAtlas.TexturePixels> var0, Map<Integer, float[]> var1, double var2) {
      ArrayList var4 = new ArrayList(var0.keySet());
      var4.sort((var1x, var2x) -> Integer.compare(((UiTextureAtlas.TexturePixels)var0.get(var2x)).height(), ((UiTextureAtlas.TexturePixels)var0.get(var1x)).height()));
      int var5 = 0;
      int var6 = 0;
      int var7 = 0;
      int var8 = 0;
      HashMap var9 = new HashMap();

      for (Object var20Object : var4) { int var20 = (Integer)var20Object;
         UiTextureAtlas.TexturePixels var21 = (UiTextureAtlas.TexturePixels)var0.get(var20);
         int var22 = Math.max(1, (int)Math.round((double)var21.width() * var2));
         int var23 = Math.max(1, (int)Math.round((double)var21.height() * var2));
         if (var5 + var22 + (8) > (2048)) {
            var5 = 0;
            var6 += var7;
            var7 = 0;
         }

         if (var22 + (8) > (2048) || var6 + var23 + (8) > (2048)) {
            return null;
         }

         Integer var25 = var20;
         int[] var26 = new int[4];
         var26[0] = var5 + (4);
         var26[1] = var6 + (4);
         var26[2] = var22;
         var26[3] = var23;
         var9.put(var25, var26);
         var5 += var22 + (8);
         var7 = Math.max(var7, var23 + (8));
         var8 = Math.max(var8, var5);
      }

      CharacterTextureAtlas var19 = new CharacterTextureAtlas(pow2(var8), pow2(var6 + var7));

      for (Object var12Object : var4) { int var12 = (Integer)var12Object;
         int[] var13 = (int[])var9.get(var12);
         UiTextureAtlas.TexturePixels var14 = resize(
            (UiTextureAtlas.TexturePixels)var0.get(var12), var13[2], var13[3]
         );

         for (int var15 = -4; var15 < var13[3] + (4); var15++) {
            for (int var16 = -4; var16 < var13[2] + (4); var16++) {
               int var17 = clamp(var16, 0, var13[2] - (1));
               int var18 = clamp(var15, 0, var13[3] - (1));
               var19.pixels[(var13[1] + var15) * var19.width + var13[0] + var16] = var14.argb()[var18
                     * var13[2]
                  + var17];
            }
         }

         float[] var24 = (float[])var1.get(var12);
         Map var10000 = var19.regions;
         Integer var10001 = var12;
         float[] var10002 = new float[8];
         var10002[0] = var24[0];
         var10002[1] = var24[1];
         var10002[2] = var24[2];
         var10002[3] = var24[3];
         var10002[4] = (float)var13[0];
         var10002[5] = (float)var13[1];
         var10002[6] = (float)var13[2];
         var10002[7] = (float)var13[3];
         var10000.put(var10001, var10002);
      }

      return var19;
   }

   float[] map(int var1, float var2, float var3) {
      float[] var4 = this.regions.get(var1);
      int[] var5 = this.tiles.get(var1);
      float var6 = (var2 - (float)var5[0]) / (float)var5[2];
      float var7 = (var3 - (float)var5[1]) / (float)var5[3];
      float var8 = (var6 - var4[0]) / (var4[2] - var4[0]);
      float var9 = (var7 - var4[1]) / (var4[3] - var4[1]);
      float[] var10000 = new float[2];
      var10000[0] = (var4[4] + var8 * var4[6]) / (float)this.width;
      var10000[1] = (var4[5] + var9 * var4[7]) / (float)this.height;
      return var10000;
   }

   byte[] packed() throws IOException {
      byte[] var1 = new byte[this.pixels.length * (4)];

      for (int var2 = 0; var2 < this.pixels.length; var2++) {
         int var3 = var2 % this.width == 0 ? 0 : this.pixels[var2 - (1)];

         for (int var4 = 0; var4 < (4); var4++) {
            var1[var2 * (4) + var4] = (byte)(
               (this.pixels[var2] >>> (24) - var4 * (8))
                  - (var3 >>> (24) - var4 * (8))
            );
         }
      }

      ByteArrayOutputStream var8 = new ByteArrayOutputStream();

      try (DeflaterOutputStream var9 = new DeflaterOutputStream(var8, new Deflater(9))) {
         var9.write(var1);
      }

      return var8.toByteArray();
   }

   private static UiTextureAtlas.TexturePixels resize(UiTextureAtlas.TexturePixels var0, int var1, int var2) {
      UiTextureAtlas.TexturePixels var3 = var0;

      while (var3.width() / (2) >= var1 && var3.height() / (2) >= var2) {
         var3 = half(var3);
      }

      return var3.width() == var1 && var3.height() == var2 ? var3 : bilinear(var3, var1, var2);
   }

   private static UiTextureAtlas.TexturePixels half(UiTextureAtlas.TexturePixels var0) {
      int var1 = var0.width() / (2);
      int var2 = var0.height() / (2);
      int[] var3 = new int[var1 * var2];

      for (int var4 = 0; var4 < var2; var4++) {
         for (int var5 = 0; var5 < var1; var5++) {
            int[] var6 = var0.argb();
            int var7 = var4 * (2) * var0.width() + var5 * (2);
            var3[var4 * var1 + var5] = average(
               var6[var7], var6[var7 + (1)], var6[var7 + var0.width()], var6[var7 + var0.width() + (1)]
            );
         }
      }

      return new UiTextureAtlas.TexturePixels(var1, var2, var3);
   }

   private static int average(int var0, int var1, int var2, int var3) {
      int var4 = 0;

      for (int var5 = 0; var5 < (32); var5 += 8) {
         int var6 = (var0 >>> var5 & (255))
            + (var1 >>> var5 & (255))
            + (var2 >>> var5 & (255))
            + (var3 >>> var5 & (255));
         var4 |= (var6 + (2)) / (4) << var5;
      }

      return var4;
   }

   private static UiTextureAtlas.TexturePixels bilinear(UiTextureAtlas.TexturePixels var0, int var1, int var2) {
      int[] var3 = new int[var1 * var2];
      int var4 = var0.width();
      int var5 = var0.height();

      for (int var6 = 0; var6 < var2; var6++) {
         float var7 = Math.max(
            0.0F,
            ((float)var6 + 0.5F) * (float)var5 / (float)var2 - 0.5F
         );
         int var8 = Math.min(var5 - (1), (int)var7);
         int var9 = Math.min(var5 - (1), var8 + (1));
         float var10 = var7 - (float)var8;

         for (int var11 = 0; var11 < var1; var11++) {
            float var12 = Math.max(
               0.0F,
               ((float)var11 + 0.5F) * (float)var4 / (float)var1 - 0.5F
            );
            int var13 = Math.min(var4 - (1), (int)var12);
            int var14 = Math.min(var4 - (1), var13 + (1));
            float var15 = var12 - (float)var13;
            int[] var16 = var0.argb();
            int var17 = 0;

            for (int var18 = 0; var18 < (32); var18 += 8) {
               float var19 = (float)(var16[var8 * var4 + var13] >>> var18 & (255))
                     * (1.0F - var15)
                  + (float)(var16[var8 * var4 + var14] >>> var18 & (255)) * var15;
               float var20 = (float)(var16[var9 * var4 + var13] >>> var18 & (255)) * (1.0F - var15)
                  + (float)(var16[var9 * var4 + var14] >>> var18 & (255)) * var15;
               var17 |= Math.round(var19 * (1.0F - var10) + var20 * var10) << var18;
            }

            var3[var6 * var1 + var11] = var17;
         }
      }

      return new UiTextureAtlas.TexturePixels(var1, var2, var3);
   }

   private static int clamp(int var0, int var1, int var2) {
      return Math.max(var1, Math.min(var2, var0));
   }

   private static int pow2(int var0) {
      int var1 = 16;

      while (var1 < var0) {
         var1 <<= 1;
      }

      return var1;
   }
}
