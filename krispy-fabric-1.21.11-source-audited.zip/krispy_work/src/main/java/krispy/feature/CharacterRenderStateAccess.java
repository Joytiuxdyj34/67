package krispy.feature;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public interface CharacterRenderStateAccess {
   WornCharacterModel krispy$character();

   void krispy$setCharacter(WornCharacterModel var1);

   float krispy$seat();

   void krispy$setSeat(float var1);
}
