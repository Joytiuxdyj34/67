package krispy.feature;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import krispy.event.EventListener;
import krispy.event.events.TickEvent;
import krispy.module.Category;
import krispy.module.Module;
import krispy.module.setting.BooleanSetting;
import krispy.module.setting.NumberSetting;
import krispy.module.setting.Setting;
import krispy.module.setting.StringSetting;
import krispy.utils.EncryptedString;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.Vec3i;
import net.minecraft.util.math.BlockPos.Mutable;

public final class SpawnerOrderModule extends Module {
   private final StringSetting dropDelayMinutes;
   private final NumberSetting actionDelay;
   private final BooleanSetting notifications;
   private final NumberSetting pagesToProcess;
   private final List<BlockPos> spawners;
   private SpawnerOrderModule.OrderState state;
   private BlockPos target;
   private int actionTimer;
   private int page;
   private boolean secondPageClick;
   private long lastCycle;
   private boolean movingNotice;

   public SpawnerOrderModule() {
      super(EncryptedString.of("Spawner Order"),
            EncryptedString.of("Drops nearby spawner loot and sells bones and arrows"),
            -1, Category.DONUT);
      dropDelayMinutes = new StringSetting(EncryptedString.of("Drop Delay Minutes"), "5");
      actionDelay = new NumberSetting(EncryptedString.of("Action Delay Ticks"), 1.0, 200.0, 20.0, 1.0);
      notifications = new BooleanSetting(EncryptedString.of("Notifications"), true);
      pagesToProcess = new NumberSetting(EncryptedString.of("Spawner Pages"), 1.0, 10.0, 1.0, 1.0);
      spawners = new ArrayList<>();
      state = OrderState.INVENTORY_CHECK;
      addSettings(new Setting[]{dropDelayMinutes, actionDelay, notifications, pagesToProcess});
   }

   public void onEnable() {
      this.state = SpawnerOrderModule.OrderState.INVENTORY_CHECK;
      this.actionTimer = 0;
      this.page = 0;
      this.secondPageClick = false;
      this.target = null;
      this.spawners.clear();
      this.lastCycle = 0L;
      this.movingNotice = false;
      this.message("Spawner Order activated.");
      super.onEnable();
   }

   public void onDisable() {
      this.spawners.clear();
      this.target = null;
      super.onDisable();
   }

   @EventListener
   public void onTick(TickEvent var1) {
      if (this.mc.player != null && this.mc.world != null && this.mc.interactionManager != null && this.mc.getNetworkHandler() != null) {
         if (this.state == SpawnerOrderModule.OrderState.WAITING_CYCLE) {
            if (System.currentTimeMillis() - this.lastCycle
               < (long)this.delayMinutes() * (60000L)) {
               return;
            }

            this.state = SpawnerOrderModule.OrderState.INVENTORY_CHECK;
         }

         int var10000 = this.actionTimer;
         this.actionTimer -= 1;
         if (var10000 <= 0) {
            this.actionTimer = this.actionDelay.getIntValue();
            switch (this.state) {
               case INVENTORY_CHECK:
                  this.state = this.hasSellableInventory() ? SpawnerOrderModule.OrderState.OPENING_SELL : SpawnerOrderModule.OrderState.SCANNING;
                  break;
               case SCANNING:
                  this.scan();
                  break;
               case MOVING:
                  this.handleMoving();
                  break;
               case OPENING:
                  this.openSpawner();
                  break;
               case DROPPING:
                  this.dropPage();
                  break;
               case OPENING_SELL:
                  this.openSell();
                  break;
               case DEPOSITING:
                  this.depositOrConfirm();
               case WAITING_CYCLE:
            }
         }
      }
   }

   private void scan() {
      this.spawners.clear();
      BlockPos var1 = this.mc.player.getBlockPos();
      Mutable var2 = new Mutable();

      for (int var3 = -5; var3 <= (5); var3++) {
         for (int var4 = -5; var4 <= (5); var4++) {
            for (int var5 = -5; var5 <= (5); var5++) {
               var2.set(var1.getX() + var3, var1.getY() + var4, var1.getZ() + var5);
               if (this.mc.world.getBlockState(var2).isOf(Blocks.SPAWNER)) {
                  this.spawners.add(var2.toImmutable());
               }
            }
         }
      }

      this.spawners.sort(Comparator.comparingDouble(var1x -> this.mc.player.squaredDistanceTo(Vec3d.ofCenter(var1x))));
      if (this.spawners.isEmpty()) {
         this.message(
            "No nearby spawner found; waiting for the next cycle."
         );
         this.finishCycle();
      } else {
         this.target = this.spawners.get(0);
         this.state = SpawnerOrderModule.OrderState.MOVING;
         this.movingNotice = false;
      }
   }

   private void handleMoving() {
      if (this.target != null && this.mc.world.getBlockState(this.target).isOf(Blocks.SPAWNER)) {
         if (this.mc.player.squaredDistanceTo(Vec3d.ofCenter(this.target))
            <= 20.25) {
            this.state = SpawnerOrderModule.OrderState.OPENING;
         } else if (!this.movingNotice) {
            this.message(
               "Move within 4 blocks of the detected spawner."
            );
            this.movingNotice = true;
         }
      } else {
         this.state = SpawnerOrderModule.OrderState.SCANNING;
      }
   }

   private void openSpawner() {
      BlockHitResult var1 = new BlockHitResult(
         Vec3d.ofCenter(this.target), Direction.UP, this.target, false
      );
      this.mc.interactionManager.interactBlock(this.mc.player, Hand.MAIN_HAND, var1);
      this.page = 0;
      this.secondPageClick = false;
      this.state = SpawnerOrderModule.OrderState.DROPPING;
   }

   private void dropPage() {
      if (!(this.mc.player.currentScreenHandler instanceof GenericContainerScreenHandler var1) || var1.slots.size() <= (53)) {
         return;
      }

      if (!this.secondPageClick) {
         this.click(var1, 50, SlotActionType.PICKUP);
         this.secondPageClick = true;
      } else {
         this.click(var1, 53, SlotActionType.PICKUP);
         this.secondPageClick = false;
         if ((this.page += 1) >= this.pagesToProcess.getIntValue()) {
            this.mc.player.closeHandledScreen();
            this.state = SpawnerOrderModule.OrderState.OPENING_SELL;
         }
      }
   }

   private void openSell() {
      if (this.mc.player.currentScreenHandler instanceof GenericContainerScreenHandler) {
         this.mc.player.closeHandledScreen();
      }

      this.mc.getNetworkHandler().sendChatCommand("sell");
      this.state = SpawnerOrderModule.OrderState.DEPOSITING;
      this.actionTimer = Math.max(20, this.actionDelay.getIntValue());
   }

   private void depositOrConfirm() {
      if (this.mc.player.currentScreenHandler instanceof GenericContainerScreenHandler var1) {
         int var5 = var1.getRows() * (9);

         for (int var3 = var5; var3 < var1.slots.size(); var3++) {
            ItemStack var4 = var1.getSlot(var3).getStack();
            if (var4.isOf(Items.BONE) || var4.isOf(Items.ARROW)) {
               this.click(var1, var3, SlotActionType.QUICK_MOVE);
               return;
            }
         }

         for (int var6 = 0; var6 < var5; var6++) {
            ItemStack var7 = var1.getSlot(var6).getStack();
            if (var7.isOf(Items.LIME_STAINED_GLASS_PANE) || var7.isOf(Items.GREEN_STAINED_GLASS_PANE)) {
               this.click(var1, var6, SlotActionType.PICKUP);
               this.mc.player.closeHandledScreen();
               this.message("Cycle completed. Next cycle in " + this.delayMinutes() + " minutes.");
               this.finishCycle();
               return;
            }
         }

         this.mc.player.closeHandledScreen();
         this.finishCycle();
      }
   }

   private boolean hasSellableInventory() {
      for (ItemStack var2 : this.mc.player.getInventory().getMainStacks()) {
         if (var2.isOf(Items.BONE) || var2.isOf(Items.ARROW)) {
            return true;
         }
      }

      return false;
   }

   private int delayMinutes() {
      try {
         return Math.max(1, Integer.parseInt(this.dropDelayMinutes.getValue().trim()));
      } catch (NumberFormatException var2) {
         return 5;
      }
   }

   private void finishCycle() {
      this.lastCycle = System.currentTimeMillis();
      this.state = SpawnerOrderModule.OrderState.WAITING_CYCLE;
      this.target = null;
   }

   private void click(GenericContainerScreenHandler var1, int var2, SlotActionType var3) {
      this.mc.interactionManager.clickSlot(var1.syncId, var2, 0, var3, this.mc.player);
   }

   private void message(String var1) {
      if (this.notifications.getValue() && this.mc.player != null) {
         this.mc.player.sendMessage(Text.literal("§b[Spawner Order] §f" + var1), false);
      }
   }

   private static enum OrderState {
      INVENTORY_CHECK,
      SCANNING,
      MOVING,
      OPENING,
      DROPPING,
      OPENING_SELL,
      DEPOSITING,
      WAITING_CYCLE;
   }
}
