package krispy.feature;

import java.util.ArrayList;
import java.util.List;
import krispy.module.Category;
import krispy.module.Module;
import krispy.module.NewFeature;

public final class ModuleRecency {
   private ModuleRecency() {
   }

   public static List<Module> newFirst(List<Module> var0) {
      boolean var1 = false;
      boolean var2 = false;

      for (Module var4 : var0) {
         if (fresh(var4)) {
            if (var1) {
               var2 = true;
               break;
            }
         } else {
            var1 = true;
         }
      }

      if (!var2) {
         return var0;
      } else {
         ArrayList var6 = new ArrayList(var0.size());

         for (Module var5 : var0) {
            if (fresh(var5)) {
               var6.add(var5);
            }
         }

         for (Module var9 : var0) {
            if (!fresh(var9)) {
               var6.add(var9);
            }
         }

         return var6;
      }
   }

   private static boolean fresh(Module var0) {
      return var0 instanceof NewFeature && var0.getCategory() == Category.DONUT;
   }
}
