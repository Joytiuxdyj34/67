package krispy.feature;

import krispy.event.EventListener;
import krispy.event.events.TickEvent;
import krispy.module.Category;
import krispy.module.Module;
import krispy.module.setting.NumberSetting;
import krispy.module.setting.Setting;
import krispy.utils.EncryptedString;
import krispy.utils.InventoryUtil;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil.Type;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.Item.TooltipContext;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.item.tooltip.TooltipType.Default;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.Text;

public final class AutoSpawnerSellModule extends Module {
   private final NumberSetting dropDelay;
   private final NumberSetting pageAmount;
   private final NumberSetting pageSwitchDelay;
   private final NumberSetting delay;
   private int delayCounter;
   private int pageCounter;
   private boolean isProcessing;
   private boolean isSelling;
   private boolean isPageSwitching;

   public AutoSpawnerSellModule() {
      super(EncryptedString.of("Auto Spawner Sell"),
            EncryptedString.of("Automatically drops bones from spawner and sells them"), -1, Category.MISC);
      dropDelay = new NumberSetting(EncryptedString.of("Drop Delay"), 0.0, 120.0, 30.0, 1.0)
            .getValue(EncryptedString.of("How often it should start dropping bones in minutes"));
      pageAmount = new NumberSetting(EncryptedString.of("Page Amount"), 1.0, 10.0, 2.0, 1.0)
            .getValue(EncryptedString.of("How many pages should it drop before selling"));
      pageSwitchDelay = new NumberSetting(EncryptedString.of("Page Switch Delay"), 0.0, 720.0, 4.0, 1.0)
            .getValue(EncryptedString.of("How often it should switch pages in seconds"));
      delay = new NumberSetting(EncryptedString.of("delay"), 0.0, 20.0, 1.0, 1.0)
            .getValue(EncryptedString.of("What should be delay in ticks"));
      addSettings(new Setting[]{dropDelay, pageAmount, pageSwitchDelay, delay});
   }

   public void onEnable() {
      super.onEnable();
      this.delayCounter = 20;
      this.isProcessing = false;
   }

   public void onDisable() {
      super.onDisable();
   }

   @EventListener
   public void onTick(TickEvent var1) {
      if (this.delayCounter > 0) {
         this.delayCounter -= 1;
      } else if (this.mc.player != null) {
         if (this.pageCounter >= this.pageAmount.getIntValue()) {
            this.isSelling = true;
            this.pageCounter = 0;
            this.delayCounter = 40;
         } else if (!this.isSelling) {
            ScreenHandler var7 = this.mc.player.currentScreenHandler;
            if (!(this.mc.player.currentScreenHandler instanceof GenericContainerScreenHandler)) {
               KeyBinding.onKeyPressed(Type.MOUSE.createFromCode(1));
               this.delayCounter = 20;
               return;
            }

            if (var7.getSlot(15).getStack().isOf(Items.LIME_STAINED_GLASS_PANE)) {
               this.mc
                  .interactionManager
                  .clickSlot(
                     this.mc.player.currentScreenHandler.syncId, 15, 1, SlotActionType.QUICK_MOVE, this.mc.player
                  );
               this.delayCounter = 10;
               return;
            }

            if (this.mc.player.currentScreenHandler.getSlot(13).getStack().isOf(Items.SKELETON_SKULL)) {
               this.mc
                  .interactionManager
                  .clickSlot(
                     this.mc.player.currentScreenHandler.syncId, 11, 0, SlotActionType.PICKUP, this.mc.player
                  );
               this.delayCounter = 20;
               return;
            }

            if (!this.mc.player.currentScreenHandler.getSlot(53).getStack().isOf(Items.GOLD_INGOT)) {
               this.mc.player.closeHandledScreen();
               this.delayCounter = 20;
               return;
            }

            if (this.mc.player.currentScreenHandler.getSlot(48).getStack().isOf(Items.ARROW)) {
               this.mc
                  .interactionManager
                  .clickSlot(
                     this.mc.player.currentScreenHandler.syncId, 48, 0, SlotActionType.PICKUP, this.mc.player
                  );
               this.delayCounter = 20;
               return;
            }

            int var9 = 1;

            for (int var12 = 0; var12 < (45); var12++) {
               if (!this.mc.player.currentScreenHandler.getSlot(var12).getStack().isOf(Items.BONE)) {
                  var9 = 0;
                  break;
               }
            }

            if (var9 != 0) {
               this.mc
                  .interactionManager
                  .clickSlot(
                     this.mc.player.currentScreenHandler.syncId, 52, 1, SlotActionType.THROW, this.mc.player
                  );
               this.isProcessing = true;
               this.delayCounter = this.pageSwitchDelay.getIntValue() * (20);
               this.pageCounter += 1;
            } else if (this.isProcessing) {
               this.isProcessing = false;
               this.mc
                  .interactionManager
                  .clickSlot(
                     this.mc.player.currentScreenHandler.syncId, 50, 0, SlotActionType.PICKUP, this.mc.player
                  );
               this.delayCounter = 20;
            } else {
               this.isProcessing = false;
               if (this.pageCounter != 0) {
                  this.pageCounter = 0;
                  this.isSelling = true;
                  this.delayCounter = 40;
                  return;
               }

               this.mc
                  .interactionManager
                  .clickSlot(
                     this.mc.player.currentScreenHandler.syncId, 45, 1, SlotActionType.THROW, this.mc.player
                  );
               this.delayCounter = (1200) * this.dropDelay.getIntValue();
            }
         } else {
            ScreenHandler var2 = this.mc.player.currentScreenHandler;
            if (!(this.mc.player.currentScreenHandler instanceof GenericContainerScreenHandler)) {
               this.mc.getNetworkHandler().sendChatCommand("order " + this.getOrderCommand());
               this.delayCounter = 20;
               return;
            }

            if (((GenericContainerScreenHandler)var2).getRows() != (6)) {
               if (((GenericContainerScreenHandler)var2).getRows() == (4)) {
                  int var8 = InventoryUtil.getSlot(Items.AIR);
                  if (var8 <= 0) {
                     this.mc.player.closeHandledScreen();
                     this.delayCounter = 10;
                     return;
                  }

                  if (this.isPageSwitching && var8 == (36)) {
                     this.isPageSwitching = false;
                     this.mc.player.closeHandledScreen();
                     return;
                  }

                  Item var11 = this.getInventoryItem();

                  while (true) {
                     int var13 = 36;
                     Item var14 = ((ItemStack)this.mc.player.currentScreenHandler.getStacks().get(36)).getItem();
                     if (var14 != Items.AIR && var14 == var11) {
                        this.mc
                           .interactionManager
                           .clickSlot(
                              this.mc.player.currentScreenHandler.syncId,
                              36,
                              1,
                              SlotActionType.QUICK_MOVE,
                              this.mc.player
                           );
                        this.delayCounter = this.delay.getIntValue();
                        if (this.delay.getIntValue() != 0) {
                           break;
                        }
                     }
                  }
               } else if (((GenericContainerScreenHandler)var2).getRows() == (3)) {
                  this.mc
                     .interactionManager
                     .clickSlot(
                        this.mc.player.currentScreenHandler.syncId,
                        15,
                        1,
                        SlotActionType.QUICK_MOVE,
                        this.mc.player
                     );
                  this.isPageSwitching = true;
                  this.delayCounter = 10;
               }
            } else {
               ItemStack var3 = var2.getSlot(47).getStack();
               if (var3.isOf(Items.AIR)) {
                  this.delayCounter = 2;
                  this.mc.player.closeHandledScreen();
                  return;
               }

               for (Object var5 : var3.getTooltip(TooltipContext.create(this.mc.world), this.mc.player, TooltipType.BASIC)) {
                  String var6 = var5.toString();
                  if (var6.contains("Most Money Per Item")
                     && (
                        ((Text)var5).getStyle().toString().contains("white")
                           || var6.contains("white")
                     )) {
                     this.mc
                        .interactionManager
                        .clickSlot(
                           this.mc.player.currentScreenHandler.syncId,
                           47,
                           1,
                           SlotActionType.QUICK_MOVE,
                           this.mc.player
                        );
                     this.delayCounter = 5;
                     return;
                  }
               }

               for (int var10 = 0; var10 < (44); var10++) {
                  if (var2.getSlot(var10).getStack().isOf(this.getInventoryItem())) {
                     this.mc
                        .interactionManager
                        .clickSlot(this.mc.player.currentScreenHandler.syncId, var10, 1, SlotActionType.QUICK_MOVE, this.mc.player);
                     this.delayCounter = 10;
                     return;
                  }
               }

               this.delayCounter = 40;
               this.mc.player.closeHandledScreen();
            }
         }
      }
   }

   private Item getInventoryItem() {
      for (int var1 = 0; var1 < (35); var1++) {
         ItemStack var2 = this.mc.player.getInventory().getStack(var1);
         if (!var2.isOf(Items.AIR)) {
            return var2.getItem();
         }
      }

      return Items.AIR;
   }

   private String getOrderCommand() {
      Item var1 = this.getInventoryItem();
      return var1.equals(Items.BONE) ? "Bones" : var1.getName().getString();
   }

}
