package krispy.feature;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.pipeline.RenderPipeline.Builder;
import com.mojang.blaze3d.pipeline.RenderPipeline.Snippet;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.GpuDevice;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.FilterMode;
import com.mojang.blaze3d.textures.GpuTextureView;
import com.mojang.blaze3d.vertex.VertexFormat;
import com.mojang.blaze3d.vertex.VertexFormat.DrawMode;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.OptionalInt;
import java.util.Random;
import java.util.function.Supplier;
import krispy.utils.BytecodeException;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gl.GpuSampler;
import net.minecraft.client.gl.SamplerCache;
import net.minecraft.client.gl.SimpleFramebuffer;
import net.minecraft.client.gl.UniformType;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.util.Identifier;
import org.lwjgl.BufferUtils;


@Environment(EnvType.CLIENT)
final class HandAuraFramebuffer {
   private static final RenderPipeline CONSTANT_0063 = RenderPipeline.builder(new Snippet[0])
      .withLocation(
         Identifier.of(
            "krispy",
            "pipeline/aura_spread"
         )
      )
      .withVertexShader("core/screenquad")
      .withFragmentShader(
         Identifier.of(
            "krispy",
            "core/aura_spread"
         )
      )
      .withSampler("InSampler")
      .withUniform("AuraSpread", UniformType.UNIFORM_BUFFER)
      .withoutBlend()
      .withDepthWrite(false)
      .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
      .withVertexFormat(VertexFormats.EMPTY, DrawMode.TRIANGLES)
      .build();
   private static final int CONSTANT_0128 = 16;
   private static final float CONSTANT_0441 = 6.0F;
   private final String name;
   private final Supplier<String> passLabel;
   private SimpleFramebuffer across;
   private SimpleFramebuffer down;
   private GpuBuffer acrossConfig;
   private GpuBuffer downConfig;
   private GpuBufferSlice acrossSlice;
   private GpuBufferSlice downSlice;
   private ByteBuffer configData;

   HandAuraFramebuffer(String var1) {
      this.name = var1;
      this.passLabel = () -> var1 + " spread";
   }

   static boolean compiled(GpuDevice var0) {
      return var0.precompilePipeline(CONSTANT_0063).isValid();
   }

   GpuTextureView spread(CommandEncoder var1, GpuTextureView var2, int var3, int var4, float var5) {
      int var6 = Math.max(1, (var3 + (1)) / (2));
      int var7 = Math.max(1, (var4 + (1)) / (2));
      if (this.across == null) {
         this.allocate(var6, var7);
      } else if (this.across.textureWidth != var6 || this.across.textureHeight != var7) {
         this.across.resize(var6, var7);
         this.down.resize(var6, var7);
      }

      float var8 = Math.max(0.75F, var5 / 6.0F);
      this.run(
         var1, var2, this.across, this.acrossSlice, var8 / (float)var3, 0.0F
      );
      this.run(
         var1,
         this.across.getColorAttachmentView(),
         this.down,
         this.downSlice,
         0.0F,
         var8 / (float)var4
      );
      return this.down.getColorAttachmentView();
   }

   private void run(CommandEncoder var1, GpuTextureView var2, SimpleFramebuffer var3, GpuBufferSlice var4, float var5, float var6) {
      this.configData.putFloat(0, var5);
      this.configData.putFloat(4, var6);
      var1.writeToBuffer(var4, this.configData);
      RenderPass var7 = var1.createRenderPass(this.passLabel, var3.getColorAttachmentView(), OptionalInt.empty());

      try {
         var7.setPipeline(CONSTANT_0063);
         var7.setUniform("AuraSpread", var4);
         var7.bindTexture(
            "InSampler",
            var2,
            RenderSystem.getSamplerCache().get(FilterMode.LINEAR)
         );
         var7.draw(0, 3);
      } catch (Throwable var11) {
         if (var7 != null) {
            try {
               var7.close();
            } catch (Throwable var10) {
               var11.addSuppressed(var10);
            }
         }

         throw var11;
      }

      if (var7 != null) {
         var7.close();
      }
   }

   private void allocate(int var1, int var2) {
      GpuDevice var3 = RenderSystem.getDevice();
      this.across = new SimpleFramebuffer(this.name + " across", var1, var2, false);
      this.down = new SimpleFramebuffer(this.name + " down", var1, var2, false);
      this.acrossConfig = var3.createBuffer(
         () -> this.name + " across config", 136, 16L
      );
      this.downConfig = var3.createBuffer(() -> this.name + " down config", 136, 16L);
      this.acrossSlice = this.acrossConfig.slice();
      this.downSlice = this.downConfig.slice();
      this.configData = BufferUtils.createByteBuffer(16);
   }

   void release() {
      if (this.across != null) {
         this.across.delete();
         this.across = null;
      }

      if (this.down != null) {
         this.down.delete();
         this.down = null;
      }

      if (this.acrossConfig != null) {
         this.acrossConfig.close();
         this.acrossConfig = null;
      }

      if (this.downConfig != null) {
         this.downConfig.close();
         this.downConfig = null;
      }

      this.acrossSlice = null;
      this.downSlice = null;
      this.configData = null;
   }
}
