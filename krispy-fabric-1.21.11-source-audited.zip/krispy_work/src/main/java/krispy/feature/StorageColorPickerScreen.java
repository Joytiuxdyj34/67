package krispy.feature;

import java.awt.Color;
import java.util.Locale;
import krispy.module.setting.StorageBlocksSetting;
import krispy.utils.RenderUtils;
import krispy.utils.TextRenderer;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.input.CharInput;
import net.minecraft.client.input.KeyInput;
import net.minecraft.client.gui.Click;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import org.lwjgl.glfw.GLFW;

public final class StorageColorPickerScreen extends Screen {
   private static final int WIDTH = 275;
   private static final int HEIGHT = 425;
   private static final int TEXTURE_SIZE = 128;
   private static final Identifier SQUARE_TEXTURE_ID = Identifier.of("krispy", "runtime/storage_color_square");
   private static final Identifier HUE_TEXTURE_ID = Identifier.of("krispy", "runtime/storage_color_hue");
   private static NativeImageBackedTexture squareTexture;
   private static NativeImageBackedTexture hueTexture;
   private static float uploadedHue = -1.0F;
   private final Screen parent;
   private final StorageBlocksSetting.Entry entry;
   private final Color original;
   private float hue;
   private float saturation;
   private float brightness;
   private boolean draggingSquare;
   private boolean draggingHue;
   private boolean editingHex;
   private boolean selectAllHex;
   private String hexValue;

   public StorageColorPickerScreen(ColorListEditorScreen var1, StorageBlocksSetting.Entry var2) {
      this((Screen)var1, var2);
   }

   public StorageColorPickerScreen(Screen var1, StorageBlocksSetting.Entry var2) {
      super(Text.empty());
      this.parent = var1;
      this.entry = var2;
      this.original = var2.color();
      float[] var3 = Color.RGBtoHSB(this.original.getRed(), this.original.getGreen(), this.original.getBlue(), null);
      this.hue = var3[0];
      this.saturation = var3[1];
      this.brightness = var3[2];
      this.hexValue = toHex(this.original);
   }

   public void render(DrawContext var1, int var2, int var3, float var4) {
      RenderUtils.setContext(var1);
      RenderUtils.unscaledProjection();
      int var5 = MinecraftClient.getInstance().getWindow().getWidth();
      int var6 = MinecraftClient.getInstance().getWindow().getHeight();
      var1.fill(0, 0, var5, var6, new Color(0, 0, 0, 70).getRGB());
      int var7 = (var5 - 275) / 2;
      int var8 = (var6 - 425) / 2;
      RenderUtils.renderRoundedQuad(
         var1.getMatrices(), new Color(31, 31, 38, 250), (double)var7, (double)var8, (double)(var7 + 275), (double)(var8 + 425), 9.0, 9.0, 9.0, 9.0, 20.0
      );
      TextRenderer.drawCenteredString("COLOR: " + this.entry.displayName().toUpperCase(Locale.ROOT), var1, var7 + 137, var8 + 10, Color.WHITE.getRGB());
      int var9 = var7 + 20;
      int var10 = var8 + 44;
      short var11 = 200;
      this.ensureTextures();
      var1.drawTexture(RenderPipelines.GUI_TEXTURED, SQUARE_TEXTURE_ID, var9, var10, 0.0F, 0.0F, var11, var11, 128, 128, 128, 128, -1);
      int var12 = var9 + Math.round(this.saturation * (float)var11);
      int var13 = var10 + Math.round((1.0F - this.brightness) * (float)var11);
      RenderUtils.renderCircle(var1.getMatrices(), Color.BLACK, (double)var12, (double)var13, 6.0, 18);
      RenderUtils.renderCircle(var1.getMatrices(), Color.WHITE, (double)var12, (double)var13, 4.0, 18);
      int var14 = var9 + var11 + 14;
      var1.drawTexture(RenderPipelines.GUI_TEXTURED, HUE_TEXTURE_ID, var14, var10, 0.0F, 0.0F, 20, var11, 1, 128, 1, 128, -1);
      int var15 = var10 + Math.round(this.hue * (float)var11);
      var1.fill(var14 - 2, var15 - 2, var14 + 22, var15 + 2, Color.WHITE.getRGB());
      var1.fill(var14 - 1, var15 - 1, var14 + 21, var15 + 1, Color.BLACK.getRGB());
      Color var16 = this.chosenColor();
      int var17 = var8 + 258;
      RenderUtils.renderRoundedQuad(
         var1.getMatrices(), this.original, (double)var9, (double)var17, (double)(var9 + 110), (double)(var17 + 30), 4.0, 4.0, 4.0, 4.0, 20.0
      );
      RenderUtils.renderRoundedQuad(
         var1.getMatrices(), var16, (double)(var9 + 125), (double)var17, (double)(var9 + 235), (double)(var17 + 30), 4.0, 4.0, 4.0, 4.0, 20.0
      );
      TextRenderer.drawCenteredString("ORIGINAL", var1, var9 + 55, var17 + 38, new Color(160, 160, 165).getRGB());
      TextRenderer.drawCenteredString("NEW", var1, var9 + 180, var17 + 38, new Color(160, 160, 165).getRGB());
      int var18 = var8 + 318;
      int var19 = var7 + 65;
      boolean var20 = isValidHex(this.hexValue);
      TextRenderer.drawString("HEX", var1, var7 + 20, var18 + 8, new Color(190, 190, 198).getRGB());
      RenderUtils.renderRoundedQuad(
         var1.getMatrices(), new Color(18, 18, 23), (double)var19, (double)var18, (double)(var7 + 275 - 20), (double)(var18 + 30), 5.0, 5.0, 5.0, 5.0, 20.0
      );
      RenderUtils.renderRoundedOutline(
         var1,
         !var20 ? new Color(255, 95, 95) : (this.editingHex ? new Color(120, 190, 255) : new Color(65, 65, 72)),
         (double)var19,
         (double)var18,
         (double)(var7 + 275 - 20),
         (double)(var18 + 30),
         5.0,
         5.0,
         5.0,
         5.0,
         1.0,
         20.0
      );
      int var21 = var20 ? new Color(235, 235, 240).getRGB() : new Color(255, 105, 105).getRGB();
      int var22 = TextRenderer.getWidth(this.hexValue);
      if (this.editingHex && this.selectAllHex && !this.hexValue.isEmpty()) {
         var1.fill(var19 + 8, var18 + 5, var19 + 12 + var22, var18 + 24, new Color(65, 125, 190, 120).getRGB());
      }

      TextRenderer.drawString(this.hexValue, var1, var19 + 10, var18 + 8, var21);
      if (this.editingHex && System.currentTimeMillis() % 1000L < 500L) {
         int var23 = var19 + 10 + var22;
         var1.fill(var23, var18 + 6, var23 + 1, var18 + 23, Color.WHITE.getRGB());
      }

      int var24 = var8 + 425 - 45;
      RenderUtils.renderRoundedQuad(
         var1.getMatrices(), new Color(38, 38, 44), (double)(var7 + 107), (double)var24, (double)(var7 + 177), (double)(var24 + 30), 5.0, 5.0, 5.0, 5.0, 20.0
      );
      TextRenderer.drawCenteredString("CANCEL", var1, var7 + 142, var24 + 8, new Color(255, 105, 105).getRGB());
      RenderUtils.renderRoundedQuad(
         var1.getMatrices(), new Color(38, 38, 44), (double)(var7 + 186), (double)var24, (double)(var7 + 256), (double)(var24 + 30), 5.0, 5.0, 5.0, 5.0, 20.0
      );
      TextRenderer.drawCenteredString("OK", var1, var7 + 221, var24 + 8, new Color(120, 190, 255).getRGB());
      RenderUtils.scaledProjection();
   }

   public boolean mouseClicked(double var1, double var3, int var5) {
      if (var5 != 0) {
         return false;
      } else {
         int var6 = physical(var1);
         int var7 = physical(var3);
         int var8 = MinecraftClient.getInstance().getWindow().getWidth();
         int var9 = MinecraftClient.getInstance().getWindow().getHeight();
         int var10 = (var8 - 275) / 2;
         int var11 = (var9 - 425) / 2;
         int var12 = var10 + 20;
         int var13 = var11 + 44;
         int var14 = var11 + 318;
         int var15 = var10 + 65;
         if (inside((double)var6, (double)var7, var15, var14, 190, 30)) {
            this.editingHex = true;
            this.selectAllHex = true;
            return true;
         } else {
            this.editingHex = false;
            this.selectAllHex = false;
            if (inside((double)var6, (double)var7, var12, var13, 200, 200)) {
               this.draggingSquare = true;
               this.updateSquare(var6, var7, var12, var13);
               return true;
            } else if (inside((double)var6, (double)var7, var12 + 214, var13, 20, 200)) {
               this.draggingHue = true;
               this.updateHue(var7, var13);
               return true;
            } else {
               int var16 = var11 + 425 - 45;
               if (inside((double)var6, (double)var7, var10 + 107, var16, 70, 30)) {
                  MinecraftClient.getInstance().setScreen(this.parent);
                  return true;
               } else if (inside((double)var6, (double)var7, var10 + 186, var16, 70, 30)) {
                  Color var17 = parseHex(this.hexValue);
                  if (var17 == null) {
                     this.editingHex = true;
                     return true;
                  } else {
                     this.entry.setColor(var17);
                     MinecraftClient.getInstance().setScreen(this.parent);
                     return true;
                  }
               } else {
                  return false;
               }
            }
         }
      }
   }

   public boolean mouseDragged(double var1, double var3, int var5, double var6, double var8) {
      int var10 = physical(var1);
      int var11 = physical(var3);
      int var12 = (MinecraftClient.getInstance().getWindow().getWidth() - 275) / 2;
      int var13 = (MinecraftClient.getInstance().getWindow().getHeight() - 425) / 2;
      if (this.draggingSquare) {
         this.updateSquare(var10, var11, var12 + 20, var13 + 44);
         return true;
      } else if (this.draggingHue) {
         this.updateHue(var11, var13 + 44);
         return true;
      } else {
         return false;
      }
   }

   public boolean mouseReleased(double var1, double var3, int var5) {
      this.draggingSquare = false;
      this.draggingHue = false;
      return true;
   }

   public boolean keyPressed(int var1, int var2, int var3) {
      if (var1 == 256) {
         MinecraftClient.getInstance().setScreen(this.parent);
         return true;
      } else if (!this.editingHex) {
         return false;
      } else if (var1 == 65 && hasControlDown()) {
         this.selectAllHex = true;
         return true;
      } else if (var1 == 67 && hasControlDown()) {
         GLFW.glfwSetClipboardString(MinecraftClient.getInstance().getWindow().getHandle(), this.hexValue);
         return true;
      } else if (var1 == 88 && hasControlDown()) {
         GLFW.glfwSetClipboardString(MinecraftClient.getInstance().getWindow().getHandle(), this.hexValue);
         this.hexValue = "";
         this.selectAllHex = false;
         return true;
      } else if (var1 == 259 && this.selectAllHex) {
         this.hexValue = "";
         this.selectAllHex = false;
         return true;
      } else if (var1 == 259 && !this.hexValue.isEmpty()) {
         this.hexValue = this.hexValue.substring(0, this.hexValue.length() - 1);
         this.applyHexIfValid();
         return true;
      } else if (var1 == 86 && hasControlDown()) {
         String var4 = MinecraftClient.getInstance().keyboard.getClipboard().trim();
         if (var4.matches("(?i)#?[0-9a-f]{6}")) {
            this.hexValue = (var4.startsWith("#") ? var4 : "#" + var4).toUpperCase(Locale.ROOT);
            this.selectAllHex = false;
            this.applyHexIfValid();
         }

         return true;
      } else if (var1 == 257) {
         this.applyHexIfValid();
         this.editingHex = false;
         this.selectAllHex = false;
         return true;
      } else {
         return false;
      }
   }

   public boolean charTyped(char var1, int var2) {
      if (!this.editingHex) {
         return false;
      } else {
         if (this.selectAllHex) {
            this.hexValue = "";
            this.selectAllHex = false;
         }

         if (var1 == '#' && this.hexValue.isEmpty()) {
            this.hexValue = "#";
         } else if (Character.digit(var1, 16) >= 0 && this.hexValue.length() < 7) {
            if (this.hexValue.isEmpty()) {
               this.hexValue = "#";
            }

            this.hexValue = this.hexValue + Character.toUpperCase(var1);
         }

         this.applyHexIfValid();
         return true;
      }
   }

   public boolean mouseClicked(Click var1, boolean var2) {
      return this.mouseClicked(var1.x(), var1.y(), var1.button());
   }

   public boolean mouseDragged(Click var1, double var2, double var4) {
      return this.mouseDragged(var1.x(), var1.y(), var1.button(), var2, var4);
   }

   public boolean mouseReleased(Click var1) {
      return this.mouseReleased(var1.x(), var1.y(), var1.button());
   }

   public boolean keyPressed(KeyInput var1) {
      return this.keyPressed(var1.key(), var1.scancode(), var1.modifiers());
   }

   public boolean charTyped(CharInput var1) {
      return var1.isValidChar() && this.charTyped((char)var1.codepoint(), var1.modifiers());
   }

   public void renderBackground(DrawContext var1, int var2, int var3, float var4) {
   }

   public boolean shouldCloseOnEsc() {
      return false;
   }

   public boolean shouldPause() {
      return false;
   }

   private void updateSquare(int var1, int var2, int var3, int var4) {
      this.saturation = clamp((float)(var1 - var3) / 200.0F);
      this.brightness = 1.0F - clamp((float)(var2 - var4) / 200.0F);
      this.selectAllHex = false;
      this.hexValue = toHex(this.chosenColor());
   }

   private void updateHue(int var1, int var2) {
      this.hue = clamp((float)(var1 - var2) / 200.0F);
      this.selectAllHex = false;
      this.hexValue = toHex(this.chosenColor());
   }

   private void ensureTextures() {
      MinecraftClient var1 = MinecraftClient.getInstance();
      if (hueTexture == null) {
         NativeImage var2 = new NativeImage(1, 128, false);

         for (int var3 = 0; var3 < 128; var3++) {
            var2.setColorArgb(0, var3, 0xFF000000 | Color.HSBtoRGB((float)var3 / 127.0F, 1.0F, 1.0F) & 16777215);
         }

         hueTexture = new NativeImageBackedTexture(() -> "Krispy storage hue", var2);
         var1.getTextureManager().registerTexture(HUE_TEXTURE_ID, hueTexture);
      }

      if (squareTexture == null) {
         NativeImage var4 = new NativeImage(128, 128, false);
         this.fillSquare(var4);
         squareTexture = new NativeImageBackedTexture(() -> "Krispy storage color square", var4);
         var1.getTextureManager().registerTexture(SQUARE_TEXTURE_ID, squareTexture);
         uploadedHue = this.hue;
      } else if (Math.abs(uploadedHue - this.hue) > 1.0E-4F) {
         this.fillSquare(squareTexture.getImage());
         squareTexture.upload();
         uploadedHue = this.hue;
      }
   }

   private void fillSquare(NativeImage var1) {
      for (int var2 = 0; var2 < 128; var2++) {
         float var3 = 1.0F - (float)var2 / 127.0F;

         for (int var4 = 0; var4 < 128; var4++) {
            float var5 = (float)var4 / 127.0F;
            var1.setColorArgb(var4, var2, 0xFF000000 | Color.HSBtoRGB(this.hue, var5, var3) & 16777215);
         }
      }
   }

   private Color chosenColor() {
      return new Color(Color.HSBtoRGB(this.hue, this.saturation, this.brightness));
   }

   private void applyHexIfValid() {
      Color var1 = parseHex(this.hexValue);
      if (var1 != null) {
         float[] var2 = Color.RGBtoHSB(var1.getRed(), var1.getGreen(), var1.getBlue(), null);
         this.hue = var2[0];
         this.saturation = var2[1];
         this.brightness = var2[2];
      }
   }

   private static String toHex(Color var0) {
      return String.format(Locale.ROOT, "#%02X%02X%02X", var0.getRed(), var0.getGreen(), var0.getBlue());
   }

   private static boolean isValidHex(String var0) {
      return var0 != null && var0.matches("(?i)#[0-9a-f]{6}");
   }

   private static Color parseHex(String var0) {
      if (!isValidHex(var0)) {
         return null;
      } else {
         try {
            return new Color(Integer.parseInt(var0.substring(1), 16));
         } catch (NumberFormatException var2) {
            return null;
         }
      }
   }

   private static boolean hasControlDown() {
      long var0 = MinecraftClient.getInstance().getWindow().getHandle();
      return GLFW.glfwGetKey(var0, 341) == 1 || GLFW.glfwGetKey(var0, 345) == 1;
   }

   private static float clamp(float var0) {
      return Math.max(0.0F, Math.min(1.0F, var0));
   }

   private static int physical(double var0) {
      return (int)Math.round(var0 * (double)MinecraftClient.getInstance().getWindow().getScaleFactor());
   }

   private static boolean inside(double var0, double var2, int var4, int var5, int var6, int var7) {
      return var0 >= (double)var4 && var0 <= (double)(var4 + var6) && var2 >= (double)var5 && var2 <= (double)(var5 + var7);
   }
}
