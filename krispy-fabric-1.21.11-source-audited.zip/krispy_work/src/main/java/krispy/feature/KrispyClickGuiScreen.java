package krispy.feature;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import krispy.Krispy;
import krispy.halloween.Halloween;
import krispy.halloween.HalloweenMusic;
import krispy.module.Module;
import krispy.module.setting.ItemSetting;
import krispy.module.setting.StorageBlocksSetting;
import krispy.utils.KeyUtils;
import krispy.utils.RenderUtils;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.util.Window;
import net.minecraft.client.input.CharInput;
import net.minecraft.client.input.KeyInput;
import net.minecraft.client.gui.Click;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.text.Text;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.sound.SoundCategory;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.registry.Registries;

public final class KrispyClickGuiScreen extends Screen implements KrispyUiController.UiDataSource {
   private final KrispyUiController ui = new KrispyUiController(this);
   private boolean freshOpen = true;
   private boolean inEditor;
   private boolean finishPending;
   private Runnable afterClose;
   private List<Item> items;

   public KrispyClickGuiScreen() {
      super(Text.empty());
   }

   public void prepareOpen() {
      if (Krispy.mc != null && Krispy.mc.currentScreen == this) {
         this.ui.onOpen(false);
         this.freshOpen = false;
      } else {
         this.freshOpen = true;
      }
   }

   protected void init() {
      this.ui.onOpen(this.freshOpen);
      this.freshOpen = false;
      this.inEditor = false;
      this.afterClose = null;
      this.syncAmbience();
   }

   private boolean ambienceWanted() {
      Screen var1 = Krispy.mc == null ? null : Krispy.mc.currentScreen;
      return var1 == this ? !this.ui.isClosing() : this.inEditor && (var1 instanceof ColorListEditorScreen || var1 instanceof StorageColorPickerScreen);
   }

   public boolean showing() {
      return this.ambienceWanted();
   }

   @Override
   public float beat() {
      return HalloweenMusic.beat();
   }

   @Override
   public float shakeStrength() {
      return krispy.module.modules.client.Krispy.beatShake.getValue() ? (float)(krispy.module.modules.client.Krispy.shakeStrength.getValue() / 100.0) : 0.0F;
   }

   public void syncAmbience() {
      try {
         if (Krispy.mc != null && Krispy.mc.options != null) {
            UiAudio.setMaster(Krispy.mc.options.getSoundVolume(SoundCategory.MASTER));
         }
      } catch (Throwable var2) {
      }
   }

   public static int blurRadius(int var0) {
      try {
         KrispyClickGuiScreen var1 = Krispy.INSTANCE.GUI;
         if (var1 != null && Krispy.mc != null && Krispy.mc.currentScreen == var1) {
            return Math.round((float)var0 * var1.ui.visibility());
         }
      } catch (Throwable var2) {
      }

      return var0;
   }

   public boolean isTyping() {
      return this.ui.isTyping();
   }

   public void requestClose() {
      this.ui.requestClose();
      UiAudio.setAmbience(false);
   }

   public void close() {
      this.requestClose();
   }

   public boolean shouldPause() {
      return false;
   }

   public void render(DrawContext var1, int var2, int var3, float var4) {
      if (this.client != null && this.client.getWindow() != null) {
         Window var5 = this.client.getWindow();
         int var6 = var5.getFramebufferWidth();
         int var7 = var5.getFramebufferHeight();
         if (var6 > 0 && var7 > 0) {
            RenderUtils.setContext(var1);
            if (Halloween.guiLocked() && !this.ui.isClosing()) {
               this.requestClose();
            }

            this.syncAmbience();
            if (Krispy.INSTANCE.screen != null && Krispy.INSTANCE.screen != this) {
               Krispy.INSTANCE.screen.render(var1, 0, 0, var4);
            }

            if (blurRadius(this.client.options.getMenuBackgroundBlurrinessValue()) > 0) {
               try {
                  var1.applyBlur();
               } catch (Throwable var18) {
               }
            }

            float var8 = (float)var5.getScaleFactor();
            double var9 = this.client.mouse.getX() * (double)var6 / (double)Math.max(1, var5.getWidth());
            double var11 = this.client.mouse.getY() * (double)var7 / (double)Math.max(1, var5.getHeight());
            var1.getMatrices().pushMatrix();
            var1.getMatrices().scale(1.0F / var8, 1.0F / var8);

            try {
               float var13 = (float)(krispy.module.modules.client.Krispy.guiSize.getValue() / 100.0);
               this.ui.render(new MinecraftUiRenderer(var1, var8), var6, var7, var9, var11, var13);
            } finally {
               var1.getMatrices().popMatrix();
            }

            if (this.finishPending) {
               this.finishPending = false;
               this.finishClose();
            }
         }
      }
   }

   private void finishClose() {
      Module var1 = Krispy.INSTANCE.getModuleManager().getModuleByClass(krispy.module.modules.client.Krispy.class);
      if (var1 != null) {
         var1.setEnabled(false);
      }

      try {
         Krispy.INSTANCE.getSettingsManager().saveNow();
      } catch (Throwable var3) {
         var3.printStackTrace(System.err);
      }

      Runnable var2 = this.afterClose;
      this.afterClose = null;
      if (this.client != null && this.client.currentScreen == this) {
         if (var2 != null) {
            var2.run();
         } else {
            this.client.setScreen(Krispy.INSTANCE.screen);
         }
      }
   }

   private double sx(double var1) {
      return var1 * (this.client == null ? 1.0 : (double)this.client.getWindow().getScaleFactor());
   }

   public boolean mouseClicked(Click var1, boolean var2) {
      return this.ui.mouseClicked(this.sx(var1.x()), this.sx(var1.y()), var1.button());
   }

   public boolean mouseReleased(Click var1) {
      this.ui.mouseReleased(this.sx(var1.x()), this.sx(var1.y()), var1.button());
      return true;
   }

   public boolean mouseDragged(Click var1, double var2, double var4) {
      this.ui.mouseDragged(this.sx(var1.x()), this.sx(var1.y()));
      return true;
   }

   public boolean mouseScrolled(double var1, double var3, double var5, double var7) {
      this.ui.mouseScrolled(this.sx(var1), this.sx(var3), var7);
      return true;
   }

   public boolean keyPressed(KeyInput var1) {
      return this.ui.keyPressed(var1.key(), var1.modifiers());
   }

   public boolean charTyped(CharInput var1) {
      return var1.isValidChar() && this.ui.charTyped((char)var1.codepoint());
   }

   @Override
   public String playerName() {
      String var1;
      try {
         var1 = this.client.getSession().getUsername();
      } catch (Throwable var3) {
         return NameProtectModule.displayName("Player");
      }

      return NameProtectModule.displayName(var1);
   }

   @Override
   public String serverLine() {
      try {
         if (this.client.world == null) {
            return "Main menu";
         } else if (this.client.isInSingleplayer()) {
            return "Singleplayer";
         } else {
            String var1 = this.client.getCurrentServerEntry() != null ? this.client.getCurrentServerEntry().address : "Multiplayer";
            if (this.client.player != null && this.client.getNetworkHandler() != null) {
               PlayerListEntry var2 = this.client.getNetworkHandler().getPlayerListEntry(this.client.player.getUuid());
               if (var2 != null) {
                  return var1 + "  ·  " + var2.getLatency() + " ms";
               }
            }

            return var1;
         }
      } catch (Throwable var3) {
         return "";
      }
   }

   @Override
   public boolean inWorld() {
      return this.client != null && this.client.player != null && this.client.world != null;
   }

   @Override
   public String keyName(int var1) {
      try {
         CharSequence var2 = KeyUtils.getKey(var1);
         return var2 == null ? null : var2.toString();
      } catch (Throwable var3) {
         return null;
      }
   }

   @Override
   public void openStorage(StorageBlocksSetting var1) {
      this.inEditor = true;
      if (var1.isColorOnly() && !var1.entries().isEmpty()) {
         this.client.setScreen(new StorageColorPickerScreen(this, var1.entries().get(0)));
      } else {
         this.client.setScreen(new ColorListEditorScreen(var1));
      }
   }

   @Override
   public void openHudEditor() {
      if (this.inWorld()) {
         this.afterClose = () -> this.client.setScreen(new ChatScreen("", false));
         this.ui.requestClose();
      }
   }

   @Override
   public void closeNow() {
      this.finishPending = true;
   }

   @Override
   public List<?> items() {
      if (this.items == null) {
         this.items = new ArrayList<>();

         for (Item var2 : Registries.ITEM) {
            if (var2 != Items.AIR) {
               this.items.add(var2);
            }
         }
      }

      return this.items;
   }

   @Override
   public String itemName(Object var1) {
      try {
         return var1 instanceof Item var2 ? var2.getName().getString() : "None";
      } catch (Throwable var3) {
         return "Item";
      }
   }

   @Override
   public Object itemOf(ItemSetting var1) {
      return var1.getItem();
   }

   @Override
   public void setItem(ItemSetting var1, Object var2) {
      if (var2 instanceof Item var3) {
         var1.setItem(var3);
      }
   }

   @Override
   public Path stateFile() {
      try {
         return FabricLoader.getInstance().getConfigDir().resolve("krispy-gui-position.txt");
      } catch (Throwable var2) {
         return null;
      }
   }
}
