package krispy.feature;

import java.awt.Color;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import krispy.event.EventListener;
import krispy.event.events.ChunkDataEvent;
import krispy.event.events.Render3DEvent;
import krispy.event.events.TickEvent;
import krispy.module.Category;
import krispy.module.Module;
import krispy.module.setting.BooleanSetting;
import krispy.module.setting.ModeSetting;
import krispy.module.setting.NumberSetting;
import krispy.module.setting.Setting;
import krispy.module.setting.StorageBlocksSetting;
import krispy.module.setting.StorageBlocksSetting.Entry;
import krispy.utils.BlockUtil;
import krispy.utils.EncryptedString;
import krispy.utils.RenderUtils;
import krispy.utils.RenderVisibility;
import krispy.utils.RenderUtils.ColoredBox;
import krispy.utils.RenderUtils.ColoredLine;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.chunk.WorldChunk;

public final class BedrockEspModule extends Module {
   private static final List<Integer> OVERWORLD_LEVELS = List.of(-64, -63, -62, -61, -60);
   private static final List<Integer> NETHER_LEVELS = List.of(0, 1, 2, 3, 4, 123, 124, 125, 126, 127);
   private final NumberSetting minimumSize;
   private final NumberSetting alpha;
   private final ModeSetting<BedrockEspModule.EspStyle> renderMode;
   private final StorageBlocksSetting color;
   private final BooleanSetting tracers;
   private final BooleanSetting chatFeedback;
   private final Set<BlockPos> voidBlocks;
   private final Map<Long, Set<BlockPos>> voidsByChunk;
   private final Set<BlockPos> announcedGroups;
   private final Queue<Long> scanQueue;
   private final Set<Long> queuedChunks;
   private final Set<Long> scannedChunks;
   private final List<ColoredBox> renderBoxes;
   private final List<ColoredLine> renderLines;
   private Object scannedWorld;
   private int ticks;

   public BedrockEspModule() {
      super(EncryptedString.of("Bedrock ESP"),
            EncryptedString.of("Finds enclosed gaps in the overworld and nether bedrock layers"),
            -1, Category.RENDER);
      minimumSize = new NumberSetting(EncryptedString.of("Minimum Void Size"), 1.0, 50.0, 2.0, 1.0);
      alpha = new NumberSetting(EncryptedString.of("Alpha"), 0.0, 255.0, 100.0, 1.0);
      renderMode = new ModeSetting<>(EncryptedString.of("Render Mode"), EspStyle.Box, EspStyle.class)
            .setDescription(EncryptedString.of("Filled box, outline only, or both"));
      color = new StorageBlocksSetting(EncryptedString.of("Color"))
            .add("void", "Void", Items.BEDROCK, true, new Color(240, 85, 80)).colorOnly();
      tracers = new BooleanSetting(EncryptedString.of("Tracers"), false);
      chatFeedback = new BooleanSetting(EncryptedString.of("Chat Feedback"), true);
      voidBlocks = new HashSet<>();
      voidsByChunk = new HashMap<>();
      announcedGroups = new HashSet<>();
      scanQueue = new ArrayDeque<>();
      queuedChunks = new HashSet<>();
      scannedChunks = new HashSet<>();
      renderBoxes = new ArrayList<>();
      renderLines = new ArrayList<>();
      addSettings(new Setting[]{minimumSize, alpha, renderMode, color, tracers, chatFeedback});
   }

   public void onEnable() {
      this.reset();
      this.scannedWorld = this.mc.world;
      this.enqueueLoadedChunks();
      super.onEnable();
   }

   public void onDisable() {
      this.reset();
      super.onDisable();
   }

   private void reset() {
      this.voidBlocks.clear();
      this.voidsByChunk.clear();
      this.announcedGroups.clear();
      this.scanQueue.clear();
      this.queuedChunks.clear();
      this.scannedChunks.clear();
      this.renderBoxes.clear();
      this.renderLines.clear();
      this.scannedWorld = null;
      this.ticks = 0;
   }

   @EventListener
   public void onChunkData(ChunkDataEvent var1) {
      this.enqueue(var1.packet.getChunkX(), var1.packet.getChunkZ());
   }

   @EventListener
   public void onTick(TickEvent var1) {
      if (this.mc.world != null && this.mc.player != null) {
         if (this.scannedWorld != this.mc.world) {
            this.voidBlocks.clear();
            this.voidsByChunk.clear();
            this.announcedGroups.clear();
            this.scanQueue.clear();
            this.queuedChunks.clear();
            this.scannedChunks.clear();
            this.scannedWorld = this.mc.world;
            this.ticks = 0;
         }

         this.ticks += 1;
         if (this.ticks % (20) == (1)) {
            this.enqueueLoadedChunks();
         }

         if (this.ticks % (200) == 0 && this.scanQueue.isEmpty()) {
            this.scannedChunks.clear();
            this.enqueueLoadedChunks();
         }

         this.scanNextChunk();
         if (this.ticks % (40) == 0) {
            this.pruneUnloadedChunks();
         }
      } else {
         this.reset();
      }
   }

   private void enqueueLoadedChunks() {
      if (this.mc.world != null && this.mc.player != null) {
         ChunkPos var1 = this.mc.player.getChunkPos();
          List<WorldChunk> var2 = BlockUtil.getLoadedChunksList();
         var2.sort(
            Comparator.comparingInt(
               var1x -> Math.max(Math.abs(var1x.getPos().x - var1.x), Math.abs(var1x.getPos().z - var1.z))
            )
         );

         for (Object var4Object : var2) { WorldChunk var4 = (WorldChunk)var4Object;
            this.enqueue(var4.getPos().x, var4.getPos().z);
         }
      }
   }

   private void enqueue(int var1, int var2) {
      long var3 = ChunkPos.toLong(var1, var2);
      if (!this.scannedChunks.contains(var3) && this.queuedChunks.add(var3)) {
         this.scanQueue.offer(var3);
      }
   }

   private void scanNextChunk() {
      Long var1 = this.scanQueue.poll();
      if (var1 != null) {
         this.queuedChunks.remove(var1);
         this.scannedChunks.add(var1);
         int var2 = ChunkPos.getPackedX(var1);
         int var3 = ChunkPos.getPackedZ(var1);
         if (!this.mc.world.isChunkLoaded(var2, var3)) {
            this.removeChunk(var1);
         } else {
            this.scanChunk(this.mc.world.getChunk(var2, var3), var1);
         }
      }
   }

   private void scanChunk(WorldChunk var1, long var2) {
      Set var4 = this.voidsByChunk.remove(var2);
      if (var4 != null) {
         this.voidBlocks.removeAll(var4);
      }

      List var5 = this.levelsForDimension();
      if (!var5.isEmpty()) {
         HashSet var6 = new HashSet();
         int var7 = var1.getPos().getStartX();
         int var8 = var1.getPos().getStartZ();

         for (Object var10Object : var5) { int var10 = (Integer)var10Object;
            for (int var11 = 0; var11 < (16); var11++) {
               for (int var12 = 0; var12 < (16); var12++) {
                  BlockPos var13 = new BlockPos(var7 + var11, var10, var8 + var12);
                  if (var1.getBlockState(var13).getBlock() != Blocks.BEDROCK) {
                     var6.add(var13);
                  }
               }
            }
         }

         HashSet var21 = new HashSet();
         HashSet var22 = new HashSet();

         for (Object var24Object : var6) { BlockPos var24 = (BlockPos)var24Object;
            if (var22.add(var24)) {
               HashSet var25 = new HashSet();
               ArrayDeque var14 = new ArrayDeque();
               var14.add(var24);

               while (!var14.isEmpty() && var25.size() < (200)) {
                  BlockPos var15 = (BlockPos)var14.remove();
                  var25.add(var15);
                  Direction[] var16 = Direction.values();
                  int var17 = var16.length;

                  for (int var18 = 0; var18 < var17; var18++) {
                     Direction var19 = var16[var18];
                     BlockPos var20 = var15.offset(var19);
                     if (var6.contains(var20) && var22.add(var20)) {
                        var14.add(var20);
                     }
                  }
               }

               if (var14.isEmpty() && var25.size() >= this.minimumSize.getIntValue() && this.isEnclosed(var25)) {
                  var21.addAll(var25);
                  BlockPos var26 = (BlockPos)var25.iterator().next();
                  if (this.chatFeedback.getValue() && this.announcedGroups.add(var26)) {
                     this.mc
                        .player
                        .sendMessage(
                           Text.literal("§d[Bedrock ESP] §fVoid found: " + var25.size() + " blocks at " + var26.toShortString()),
                           false
                        );
                  }
               }
            }
         }

         if (!var21.isEmpty()) {
            this.voidsByChunk.put(var2, Set.copyOf(var21));
         }

         this.voidBlocks.addAll(var21);
         this.announcedGroups.retainAll(this.voidBlocks);
      }
   }

   private boolean isEnclosed(Set<BlockPos> var1) {
      for (BlockPos var3 : var1) {
         Direction[] var4 = Direction.values();
         int var5 = var4.length;

         for (int var6 = 0; var6 < var5; var6++) {
            Direction var7 = var4[var6];
            BlockPos var8 = var3.offset(var7);
            if (!var1.contains(var8) && this.mc.world.getBlockState(var8).getBlock() != Blocks.BEDROCK) {
               return false;
            }
         }
      }

      return true;
   }

   private void pruneUnloadedChunks() {
      for (Long var2 : new ArrayList<>(this.voidsByChunk.keySet())) {
         int var3 = ChunkPos.getPackedX(var2);
         int var4 = ChunkPos.getPackedZ(var2);
         if (!this.mc.world.isChunkLoaded(var3, var4)) {
            this.removeChunk(var2);
         }
      }
   }

   private void removeChunk(long var1) {
      Set var3 = this.voidsByChunk.remove(var1);
      if (var3 != null) {
         this.voidBlocks.removeAll(var3);
      }

      this.scannedChunks.remove(var1);
      this.queuedChunks.remove(var1);
   }

   private List<Integer> levelsForDimension() {
      String var1 = this.mc.world.getRegistryKey().getValue().toString();
      if (var1.equals("minecraft:overworld")) {
         return OVERWORLD_LEVELS;
      } else {
         return var1.equals("minecraft:the_nether")
            ? NETHER_LEVELS
            : List.of();
      }
   }

   @EventListener
   public void onRender3D(Render3DEvent event) {
      if (mc.world == null || voidBlocks.isEmpty()) {
         return;
      }
      Camera camera = RenderUtils.getCamera();
      if (camera == null || !camera.isReady()) {
         return;
      }
      MatrixStack matrices = event.matrixStack;
      matrices.push();
      RenderUtils.applyCameraTransform(matrices, camera);
      Color base = color.entries().get(0).color();
      Color fill = new Color(base.getRed(), base.getGreen(), base.getBlue(), alpha.getIntValue());
      Color line = new Color(Math.min(255, base.getRed() + 15),
            Math.min(255, base.getGreen() + 15), Math.min(255, base.getBlue() + 15),
            Math.max(160, alpha.getIntValue()));
      boolean drawFill = !renderMode.isMode(EspStyle.Outline);
      boolean drawOutline = !renderMode.isMode(EspStyle.Box);
      renderBoxes.clear();
      renderLines.clear();
      Vec3d tracerOrigin = RenderUtils.getTracerStart(camera);
      for (BlockPos pos : voidBlocks) {
         double x0 = pos.getX() + 0.03;
         double y0 = pos.getY() + 0.03;
         double z0 = pos.getZ() + 0.03;
         double x1 = pos.getX() + 0.97;
         double y1 = pos.getY() + 0.97;
         double z1 = pos.getZ() + 0.97;
         if (!tracers.getValue() && !RenderVisibility.box(x0, y0, z0, x1, y1, z1)) {
            continue;
         }
         if (drawFill && alpha.getIntValue() > 0) {
            renderBoxes.add(new ColoredBox(x0, y0, z0, x1, y1, z1, fill));
         }
         if (drawOutline) {
            RenderUtils.addBoxOutline(renderLines, x0, y0, z0, x1, y1, z1, line, 1.5F);
         }
         if (tracers.getValue()) {
            renderLines.add(new ColoredLine(tracerOrigin, Vec3d.ofCenter(pos), line, 1.5F));
         }
      }
      RenderUtils.renderFilledBoxes(matrices, renderBoxes);
      RenderUtils.renderLines(matrices, renderLines);
      matrices.pop();
   }

   public static enum EspStyle {
      Box,
      Outline,
      Both;
   }
}
