package krispy.feature;

import krispy.module.Category;
import krispy.module.Module;
import krispy.module.NewFeature;
import krispy.module.setting.BooleanSetting;
import krispy.module.setting.ModeSetting;
import krispy.module.setting.NumberSetting;
import krispy.utils.EncryptedString;
import krispy.halloween.Halloween;
import krispy.module.setting.ButtonSetting;

public final class HalloweenModule extends Module implements NewFeature {
   public static final NumberSetting darkness = new NumberSetting(
      EncryptedString.of("Halloween Darkness"), 0.0, 100.0, 60.0, 1.0
   ).getValue(EncryptedString.of("How dark the Halloween night gets (fullbright is overridden)"));
   public static final NumberSetting fogDensity = new NumberSetting(
      EncryptedString.of("Fog Density"), 0.0, 100.0, 55.0, 1.0
   ).getValue(EncryptedString.of("How thick the Halloween fog and ground mist are"));
   public static final NumberSetting eventVolume = new NumberSetting(
      EncryptedString.of("Event Music Volume"), 0.0, 100.0, 60.0, 1.0
   ).getValue(EncryptedString.of("Volume of the Halloween event song"));

   private final ButtonSetting replay;

   public HalloweenModule() {
      super(EncryptedString.of("Halloween"),
         EncryptedString.of("A Krispy Halloween night: darkness, fog, a haunted sky and a visitor on a broom"),
         -1, Category.RENDER);
      replay = new ButtonSetting(EncryptedString.of("Replay Intro"), Halloween::replayIntro);
      replay.setDescription(EncryptedString.of("Plays the Halloween welcome event again"));
      addSettings(darkness, fogDensity, eventVolume, replay);
   }

   @Override
   public void onEnable() {
      Halloween.onModuleEnabled();
      super.onEnable();
   }

   @Override
   public void onDisable() {
      Halloween.onModuleDisabled();
      super.onDisable();
   }
}
