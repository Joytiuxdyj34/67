package krispy.feature;

import krispy.Krispy;
import krispy.event.EventListener;
import krispy.event.events.TickEvent;
import krispy.module.Category;
import krispy.module.Module;
import krispy.module.setting.NumberSetting;
import krispy.utils.EncryptedString;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;

public final class AutoTotemModule extends Module {
   private final NumberSetting delay;
   private int delayCounter;

   public AutoTotemModule() {
      super(
         EncryptedString.of("Auto Totem"),
         EncryptedString.of("Automatically holds totem in your off hand"),
         -1,
         Category.COMBAT
      );
      this.delay = new NumberSetting(EncryptedString.of("Delay"), 0.0, 5.0, 1.0, 1.0);
      this.addSettings(this.delay);
   }

   @Override
   public void onEnable() {
      super.onEnable();
   }

   @Override
   public void onDisable() {
      super.onDisable();
   }

   @EventListener
   public void onTick(TickEvent event) {
      if (this.mc.player == null) {
         return;
      }
      RtpBaseFinderModule rtpFinder = (RtpBaseFinderModule)Krispy.INSTANCE.MODULE_MANAGER.getModuleByClass(RtpBaseFinderModule.class);
      if (rtpFinder.isEnabled() && rtpFinder.isRepairingActive()) {
         return;
      }
      TunnelBaseFinderModule tunnelFinder = (TunnelBaseFinderModule)Krispy.INSTANCE.MODULE_MANAGER.getModuleByClass(TunnelBaseFinderModule.class);
      if (tunnelFinder.isEnabled() && tunnelFinder.isDigging()) {
         return;
      }

      if (this.mc.player.getInventory().getStack(40).getItem() == Items.TOTEM_OF_UNDYING) {
         this.delayCounter = this.delay.getIntValue();
      } else if (this.delayCounter > 0) {
         this.delayCounter--;
      } else {
         int slot = this.findItemSlot(Items.TOTEM_OF_UNDYING);
         if (slot != -1) {
            this.mc.interactionManager.clickSlot(
               this.mc.player.currentScreenHandler.syncId,
               convertSlotIndex(slot),
               40,
               SlotActionType.SWAP,
               this.mc.player
            );
            this.delayCounter = this.delay.getIntValue();
         }
      }
   }

   public int findItemSlot(Item item) {
      if (this.mc.player == null) {
         return -1;
      }
      for (int slot = 0; slot < 36; slot++) {
         if (this.mc.player.getInventory().getStack(slot).isOf(item)) {
            return slot;
         }
      }
      return -1;
   }

   private static int convertSlotIndex(int slot) {
      return slot < 9 ? slot + 36 : slot;
   }
}
