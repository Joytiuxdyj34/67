package krispy.feature;

import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.toast.Toast;
import net.minecraft.client.toast.ToastManager;
import net.minecraft.client.toast.Toast.Visibility;

public final class ChunkFinderToast implements Toast {
   private static final Identifier TEXTURE = Identifier.ofVanilla("toast/advancement");
   private static final long DISPLAY_TIME_MS = 5000L;
   private static final int PURPLE = -43521;
   private static final int WHITE = -1;
   private static final ItemStack ICON = new ItemStack(Items.CHEST);
   private final Text coordinates;
   private Visibility visibility = Visibility.SHOW;

   public ChunkFinderToast(int x, int z) {
      this.coordinates = Text.literal("X: " + x + " Z: " + z);
   }

   public Visibility getVisibility() {
      return this.visibility;
   }

   public void update(ToastManager manager, long time) {
      this.visibility = (double)time >= 5000.0 * manager.getNotificationDisplayTimeMultiplier() ? Visibility.HIDE : Visibility.SHOW;
   }

   public void draw(DrawContext context, TextRenderer textRenderer, long time) {
      context.drawGuiTexture(RenderPipelines.GUI_TEXTURED, TEXTURE, 0, 0, this.getWidth(), this.getHeight());
      context.drawText(textRenderer, Text.literal("Chunk Finder"), 30, 7, -43521, false);
      context.drawText(textRenderer, this.coordinates, 30, 18, -1, false);
      context.drawItemWithoutEntity(ICON, 8, 8);
   }
}
