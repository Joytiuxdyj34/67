package krispy.feature;

import java.awt.Color;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.function.Predicate;
import krispy.event.EventListener;
import krispy.event.events.Render3DEvent;
import krispy.event.events.TickEvent;
import krispy.mixin.MobSpawnerLogicAccessor;
import krispy.module.Category;
import krispy.module.Module;
import krispy.module.setting.BooleanSetting;
import krispy.module.setting.NumberSetting;
import krispy.module.setting.Setting;
import krispy.utils.BlockUtil;
import krispy.utils.EncryptedString;
import krispy.utils.RenderUtils;
import krispy.utils.RenderVisibility;
import krispy.utils.RenderUtils.ColoredBox;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.MobSpawnerBlockEntity;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.EntityType;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.registry.Registries;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import net.minecraft.world.chunk.WorldChunk;

public final class SpawnerNotifyModule extends Module {
   private final NumberSetting range;
   private final BooleanSetting pillar;
   private final NumberSetting pillarAlpha;
   private final BooleanSetting spawnerBox;
   private final NumberSetting boxAlpha;
   private final BooleanSetting chatAlerts;
   private final BooleanSetting soundAlerts;
   private final Map<BlockPos, String> trackedSpawners;
   private final Set<Long> alertedSpawners;
   private final List<ColoredBox> renderBoxes;
   private ClientWorld trackedWorld;
   private int scanDelay;

   public SpawnerNotifyModule() {
      super(EncryptedString.of("Spawner Notify"),
            EncryptedString.of("Highlights nearby spawners and alerts when one is found"), -1, Category.RENDER);
      range = new NumberSetting(EncryptedString.of("Range"), 8.0, 512.0, 256.0, 8.0);
      pillar = new BooleanSetting(EncryptedString.of("3x3 Pillar"), true);
      pillarAlpha = new NumberSetting(EncryptedString.of("Pillar Alpha"), 0.0, 255.0, 80.0, 1.0);
      spawnerBox = new BooleanSetting(EncryptedString.of("Spawner Box"), true);
      boxAlpha = new NumberSetting(EncryptedString.of("Box Alpha"), 0.0, 255.0, 150.0, 1.0);
      chatAlerts = new BooleanSetting(EncryptedString.of("Chat Alerts"), true);
      soundAlerts = new BooleanSetting(EncryptedString.of("Sound Alerts"), true);
      trackedSpawners = new HashMap<>();
      alertedSpawners = new HashSet<>();
      renderBoxes = new ArrayList<>();
      addSettings(new Setting[]{range, pillar, pillarAlpha, spawnerBox, boxAlpha, chatAlerts, soundAlerts});
   }

   public void onEnable() {
      this.reset();
      super.onEnable();
   }

   public void onDisable() {
      this.reset();
      super.onDisable();
   }

   private void reset() {
      this.trackedSpawners.clear();
      this.alertedSpawners.clear();
      this.renderBoxes.clear();
      this.trackedWorld = null;
      this.scanDelay = 0;
   }

   @EventListener
   public void onTick(TickEvent var1) {
      if (this.mc.world != null && this.mc.player != null) {
         if (this.trackedWorld != this.mc.world) {
            this.trackedWorld = this.mc.world;
            this.trackedSpawners.clear();
            this.alertedSpawners.clear();
            this.scanDelay = 0;
         }

         int var10000 = this.scanDelay;
         this.scanDelay += 1;
         if (var10000 <= 0 || this.scanDelay >= (40)) {
            this.scanDelay = 0;
            this.scanLoadedSpawners();
         }
      } else {
         this.reset();
      }
   }

   private void scanLoadedSpawners() {
      double var1 = this.range.getValue() * this.range.getValue();
      HashMap var3 = new HashMap();
      HashSet var4 = new HashSet();

      for (WorldChunk var6 : BlockUtil.getLoadedChunksList()) {
         for (BlockPos var8 : var6.getBlockEntityPositions()) {
            BlockEntity var9 = this.mc.world.getBlockEntity(var8);
            if (var9 instanceof MobSpawnerBlockEntity) {
               MobSpawnerBlockEntity var10 = (MobSpawnerBlockEntity)var9;
               if (!var9.isRemoved() && var9.getWorld() == this.mc.world && !(this.mc.player.squaredDistanceTo(Vec3d.ofCenter(var8)) > var1)) {
                  BlockPos var11 = var8.toImmutable();
                  String var12 = this.readSpawnerType(var10);
                  var3.put(var11, var12);
                  var4.add(var11.asLong());
                  if (this.alertedSpawners.add(var11.asLong())) {
                     this.alert(var12, var11);
                  }
               }
            }
         }
      }

      this.alertedSpawners.removeIf(var1x -> ((!var4.contains(var1x))));
      this.trackedSpawners.clear();
      this.trackedSpawners.putAll(var3);
   }

   private String readSpawnerType(MobSpawnerBlockEntity var1) {
      try {
         String var2 = ((MobSpawnerLogicAccessor)var1.getLogic())
            .getSpawnEntry()
            .getNbt()
            .getString("id")
            .orElse("");
         Identifier var3 = Identifier.tryParse(var2);
         if (var3 != null) {
            EntityType var4 = (EntityType)Registries.ENTITY_TYPE.get(var3);
            if (var4 != null) {
               return var4.getName().getString();
            }
         }

         if (!var2.isBlank()) {
            int var7 = var2.indexOf(58);
            String var5 = var7 >= 0 ? var2.substring(var7 + (1)) : var2;
            return Character.toUpperCase(var5.charAt(0))
               + var5.substring(1).replace((char)(95), (char)(32));
         }
      } catch (RuntimeException var6) {
      }

      return "Unknown";
   }

   private void alert(String var1, BlockPos var2) {
      if (this.soundAlerts.getValue()) {
         this.mc
            .player
            .playSound(
               (SoundEvent)SoundEvents.BLOCK_NOTE_BLOCK_BELL.value(), 1.0F, 0.800000011920929F
            );
      }

      if (this.chatAlerts.getValue()) {
         this.mc
            .player
            .sendMessage(
               Text.literal(
                  "§c[Spawner Notify] §f" + var1 + " Spawner at X: " + var2.getX() + " Y: " + var2.getY() + " Z: " + var2.getZ()
               ),
               false
            );
      }
   }

   @EventListener
   public void onRender3D(Render3DEvent event) {
      if (mc.world == null || mc.player == null || trackedSpawners.isEmpty()) {
         return;
      }
      Camera camera = RenderUtils.getCamera();
      if (camera == null || !camera.isReady()) {
         return;
      }

      MatrixStack matrices = event.matrixStack;
      matrices.push();
      RenderUtils.applyCameraTransform(matrices, camera);
      renderBoxes.clear();
      double bottomY = mc.world.getBottomY();
      double topY = mc.world.getTopYInclusive() + 1.0;
      Color pillarColor = new Color(255, 0, 0, pillarAlpha.getIntValue());
      Color boxColor = new Color(255, 0, 0, boxAlpha.getIntValue());

      for (BlockPos pos : trackedSpawners.keySet()) {
         double x = pos.getX();
         double y = pos.getY();
         double z = pos.getZ();
         if (pillar.getValue() && pillarAlpha.getIntValue() > 0
               && RenderVisibility.box(x - 1.0, bottomY, z - 1.0, x + 2.0, topY, z + 2.0)) {
            renderBoxes.add(new ColoredBox(x - 1.0, bottomY, z - 1.0, x + 2.0, topY, z + 2.0, pillarColor));
         }
         if (spawnerBox.getValue() && boxAlpha.getIntValue() > 0
               && RenderVisibility.box(x, y, z, x + 1.0, y + 1.0, z + 1.0)) {
            renderBoxes.add(new ColoredBox(x, y, z, x + 1.0, y + 1.0, z + 1.0, boxColor));
         }
      }
      RenderUtils.renderFilledBoxes(matrices, renderBoxes);
      matrices.pop();
   }

}
