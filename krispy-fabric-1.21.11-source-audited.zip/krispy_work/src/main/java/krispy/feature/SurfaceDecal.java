package krispy.feature;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public final class SurfaceDecal {
   final PixelCanvas canvas;
   final boolean wrap;
   final float cx;
   final float cy;
   final float cz;
   final float dx;
   final float dy;
   final float dz;
   final float ux;
   final float uy;
   final float uz;
   final float rx;
   final float ry;
   final float rz;
   final float width;
   final float height;
   float near = -Float.MAX_VALUE;
   float far = Float.MAX_VALUE;
   float cosLimit = (float)Math.cos(Math.toRadians(78.0));
   float offset = 0.035F;
   boolean glow;
   float flat = Float.NaN;
   float occlusion = 1.0F;

   private SurfaceDecal(
      PixelCanvas canvas, boolean wrap,
      float centerX, float centerY, float centerZ,
      float directionX, float directionY, float directionZ,
      float upX, float upY, float upZ,
      float width, float height
   ) {
      if (canvas == null) {
         throw new IllegalArgumentException("decal needs a canvas");
      }
      if (width <= 0.0F || height <= 0.0F) {
         throw new IllegalArgumentException("decal size must be positive");
      }
      this.canvas = canvas;
      this.wrap = wrap;
      cx = centerX;
      cy = centerY;
      cz = centerZ;

      float directionLength = (float)Math.sqrt(
         directionX * directionX + directionY * directionY + directionZ * directionZ
      );
      if (directionLength < 1.0E-6F) {
         throw new IllegalArgumentException("decal direction must not be zero");
      }
      dx = directionX / directionLength;
      dy = directionY / directionLength;
      dz = directionZ / directionLength;

      float alongDirection = upX * dx + upY * dy + upZ * dz;
      float projectedX = upX - alongDirection * dx;
      float projectedY = upY - alongDirection * dy;
      float projectedZ = upZ - alongDirection * dz;
      float upLength = (float)Math.sqrt(
         projectedX * projectedX + projectedY * projectedY + projectedZ * projectedZ
      );
      if (upLength < 1.0E-6F) {
         throw new IllegalArgumentException("decal up/front direction must not be parallel to its axis");
      }
      ux = projectedX / upLength;
      uy = projectedY / upLength;
      uz = projectedZ / upLength;

      if (wrap) {
         rx = dy * uz - dz * uy;
         ry = dz * ux - dx * uz;
         rz = dx * uy - dy * ux;
      } else {
         rx = uy * dz - uz * dy;
         ry = uz * dx - ux * dz;
         rz = ux * dy - uy * dx;
      }
      this.width = width;
      this.height = height;
   }

   public static SurfaceDecal front(PixelCanvas canvas, float x, float y, float z, float width, float height) {
      return new SurfaceDecal(canvas, false, x, y, z, 0.0F, 0.0F, 1.0F, 0.0F, 1.0F, 0.0F, width, height);
   }

   public static SurfaceDecal back(PixelCanvas canvas, float x, float y, float z, float width, float height) {
      return new SurfaceDecal(canvas, false, x, y, z, 0.0F, 0.0F, -1.0F, 0.0F, 1.0F, 0.0F, width, height);
   }

   public static SurfaceDecal left(PixelCanvas canvas, float x, float y, float z, float width, float height) {
      return new SurfaceDecal(canvas, false, x, y, z, 1.0F, 0.0F, 0.0F, 0.0F, 1.0F, 0.0F, width, height);
   }

   public static SurfaceDecal right(PixelCanvas canvas, float x, float y, float z, float width, float height) {
      return new SurfaceDecal(canvas, false, x, y, z, -1.0F, 0.0F, 0.0F, 0.0F, 1.0F, 0.0F, width, height);
   }

   public static SurfaceDecal top(PixelCanvas canvas, float x, float y, float z, float width, float height) {
      return new SurfaceDecal(canvas, false, x, y, z, 0.0F, 1.0F, 0.0F, 0.0F, 0.0F, -1.0F, width, height);
   }

   public static SurfaceDecal project(
      PixelCanvas canvas, float x, float y, float z,
      float directionX, float directionY, float directionZ,
      float upX, float upY, float upZ, float width, float height
   ) {
      return new SurfaceDecal(
         canvas, false, x, y, z,
         directionX, directionY, directionZ, upX, upY, upZ, width, height
      );
   }

   public static SurfaceDecal wrap(
      PixelCanvas canvas, float x, float y, float z,
      float directionX, float directionY, float directionZ,
      float upX, float upY, float upZ, float width, float height
   ) {
      return new SurfaceDecal(
         canvas, true, x, y, z,
         directionX, directionY, directionZ, upX, upY, upZ, Math.min(360.0F, width), height
      );
   }

   public SurfaceDecal depth(float near, float far) {
      this.near = Math.abs(near);
      this.far = Math.abs(far);
      return this;
   }

   public SurfaceDecal radius(float near, float far) {
      this.near = near;
      this.far = far;
      return this;
   }

   public SurfaceDecal maxAngle(float angleDegrees) {
      cosLimit = (float)Math.cos(Math.toRadians(Math.max(1.0F, Math.min(89.5F, angleDegrees))));
      return this;
   }

   public SurfaceDecal offset(float value) {
      offset = value;
      return this;
   }

   public SurfaceDecal glow() {
      glow = true;
      return this;
   }

   public SurfaceDecal flatLight(float value) {
      flat = Math.max(0.0F, Math.min(1.0F, value));
      return this;
   }

   public SurfaceDecal occlusion(float value) {
      occlusion = Math.max(0.0F, Math.min(1.0F, value));
      return this;
   }

   SurfaceDecal mirrored() {
      SurfaceDecal copy = new SurfaceDecal(
         canvas.mirrored(), wrap, cx, cy, cz, dx, dy, dz, ux, uy, uz, width, height
      );
      copy.near = near;
      copy.far = far;
      copy.cosLimit = cosLimit;
      copy.offset = offset;
      copy.glow = glow;
      copy.flat = flat;
      copy.occlusion = occlusion;
      return copy;
   }
}
