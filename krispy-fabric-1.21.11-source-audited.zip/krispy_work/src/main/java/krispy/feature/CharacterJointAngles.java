package krispy.feature;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.entity.model.BipedEntityModel.ArmPose;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.util.Arm;
import net.minecraft.util.SwingAnimationType;
import net.minecraft.util.math.MathHelper;

@Environment(EnvType.CLIENT)
final class CharacterJointAngles {
   static final float CROUCH_HIP = 0.5F;
   static final float SADDLE_KNEE = 1.35F;
   static final float SEAT_KNEE = 0.3F;
   private static final float CROUCH_KNEE = 0.62F;
   private static final float CROUCH_ELBOW = 0.2F;
   private static final float MAX_KNEE = 1.7F;
   private static final float MAX_ELBOW = 1.6F;

   private CharacterJointAngles() {
   }

   static float angle(PlayerEntityRenderState state, CharacterBone bone, float armMovement) {
      float movement = state.isGliding || state.usingRiptide
            ? 0.0F : 1.0F - state.leaningPitch * 0.8F;
      if (movement <= 0.0F) {
         return 0.0F;
      }
      if (bone.leg()) {
         return knee(state, bone) * movement;
      }
      return bone.arm() ? elbow(state, bone, armMovement) * movement : 0.0F;
   }

   private static float knee(PlayerEntityRenderState state, CharacterBone bone) {
      if (state.hasVehicle) {
         return Character3dModule.seat(state);
      }
      float gait = Math.min(1.0F, state.limbSwingAmplitude / state.limbAmplitudeInverse);
      float phase = state.limbSwingAnimationProgress * 0.6662F
            + (bone == CharacterBone.LEFT_LEG ? (float) Math.PI : 0.0F);
      float angle = gait * (0.85F * Math.max(0.0F, MathHelper.sin(phase)) + 0.1F);
      if (state.isInSneakingPose) {
         angle += CROUCH_KNEE;
      }
      return Math.min(MAX_KNEE, angle);
   }

   private static float elbow(PlayerEntityRenderState state, CharacterBone bone, float armMovement) {
      boolean right = bone == CharacterBone.RIGHT_ARM;
      ArmPose pose = right ? state.rightArmPose : state.leftArmPose;
      ArmPose oppositePose = right ? state.leftArmPose : state.rightArmPose;
      if (oppositePose.isTwoHanded()) {
         return 0.0F;
      }

      float gait = Math.min(1.0F, state.limbSwingAmplitude / state.limbAmplitudeInverse);
      float angle = switch (pose) {
         case EMPTY -> 0.16F + 0.45F * Math.max(0.0F, armMovement) + 0.3F * gait;
         case ITEM -> 0.3F + 0.2F * gait;
         case BLOCK -> 0.55F;
         case BRUSH -> 0.4F;
         default -> 0.0F;
      };
      if (angle <= 0.0F) {
         return 0.0F;
      }
      if (state.isInSneakingPose) {
         angle += CROUCH_ELBOW;
      }
      Arm arm = right ? Arm.RIGHT : Arm.LEFT;
      if (state.handSwingProgress > 0.0F
            && state.preferredArm == arm
            && state.swingAnimationType == SwingAnimationType.WHACK) {
         angle += 0.6F * MathHelper.sin(state.handSwingProgress * (float) Math.PI);
      }
      return Math.min(MAX_ELBOW, angle);
   }
}
