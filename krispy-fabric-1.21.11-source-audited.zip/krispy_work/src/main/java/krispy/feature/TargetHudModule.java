package krispy.feature;

import java.awt.Color;
import krispy.event.EventListener;
import krispy.event.events.PacketSendEvent;
import krispy.event.events.Render2DEvent;
import krispy.module.Category;
import krispy.module.Module;
import krispy.module.setting.BooleanSetting;
import krispy.module.setting.NumberSetting;
import krispy.module.setting.Setting;
import krispy.utils.ColorUtil;
import krispy.utils.EncryptedString;
import krispy.utils.MathUtil;
import krispy.utils.RenderUtils;
import krispy.utils.TextRenderer;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.PlayerSkinDrawer;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.SkinTextures;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.PlayerInteractEntityC2SPacket;
import net.minecraft.util.Hand;
import org.joml.Matrix3x2fStack;

public final class TargetHudModule extends Module {
   private final NumberSetting xPosition;
   private final NumberSetting yPosition;
   private final BooleanSetting timeoutEnabled;
   private final NumberSetting fadeSpeed;
   private final Color primaryColor;
   private final Color backgroundColor;
   private long lastAttackTime;
   public static float fadeProgress = 1.0F;
   private float currentHealth;
   private TargetHudModule.AttackPacketDetector hudHandler;

   public TargetHudModule() {
      super(EncryptedString.of("Target HUD"),
            EncryptedString.of("Displays detailed information about your target with style"),
            -1, Category.RENDER);
      xPosition = new NumberSetting(EncryptedString.of("X"), 0.0, 1920.0, 500.0, 1.0);
      yPosition = new NumberSetting(EncryptedString.of("Y"), 0.0, 1080.0, 500.0, 1.0);
      timeoutEnabled = new BooleanSetting(EncryptedString.of("Timeout"), true)
            .setDescription(EncryptedString.of("Target hud will disappear after 10 seconds"));
      fadeSpeed = new NumberSetting(EncryptedString.of("Fade Speed"), 5.0, 30.0, 15.0, 1.0)
            .getValue(EncryptedString.of("Speed of animations"));
      primaryColor = new Color(255, 50, 100);
      backgroundColor = new Color(0, 0, 0, 175);
      addSettings(new Setting[]{xPosition, yPosition, timeoutEnabled, fadeSpeed});
   }

   public void onEnable() {
      super.onEnable();
   }

   public void onDisable() {
      super.onDisable();
   }

   @EventListener
   public void onRender2D(Render2DEvent var1) {
      DrawContext var2 = var1.context;
      int var3 = this.xPosition.getIntValue();
      int var4 = this.yPosition.getIntValue();
      float var5 = this.fadeSpeed.getFloatValue();
      Color var6 = this.primaryColor;
      Color var7 = this.backgroundColor;
      RenderUtils.unscaledProjection();
      int var8 = this.mc.player.getAttacking() != null
            && this.mc.player.getAttacking() instanceof PlayerEntity
            && this.mc.player.getAttacking().isAlive()
         ? 1
         : 0;
      int var9 = this.timeoutEnabled.getValue()
            && System.currentTimeMillis() - this.lastAttackTime > (10000L)
         ? 0
         : 1;
      float var10;
      if (var8 != 0 && var9 != 0) {
         var10 = 0.0F;
      } else {
         var10 = 1.0F;
      }

      fadeProgress = RenderUtils.fast(fadeProgress, var10, var5);
      if (fadeProgress < 0.9900000095367432F && var8 != 0) {
         LivingEntity var11 = this.mc.player.getAttacking();
         PlayerListEntry var12 = this.mc.getNetworkHandler().getPlayerListEntry(var11.getUuid());
         Matrix3x2fStack var13 = var2.getMatrices();
         var13.pushMatrix();
         float var14 = 1.0F - fadeProgress;
         float var15 = 0.800000011920929F + 0.20000000298023224F * var14;
         var13.translate((float)var3, (float)var4);
         var13.scale(var15, var15);
         var13.translate((float)(-var3), (float)(-var4));
         this.currentHealth = RenderUtils.fast(
            this.currentHealth, var11.getHealth() + var11.getAbsorptionAmount(), var5 * 0.5F
         );
         this.drawHud(var2, var3, var4, (PlayerEntity)var11, var12, var14, var6, var7);
         var13.popMatrix();
      }

      RenderUtils.scaledProjection();
   }

   private void drawHud(DrawContext var1, int var2, int var3, PlayerEntity var4, PlayerListEntry var5, float var6, Color var7, Color var8) {
      Matrix3x2fStack var9 = var1.getMatrices();
      RenderUtils.renderRoundedQuad(
         var9,
         new Color(var7.getRed(), var7.getGreen(), var7.getBlue(), (int)(50.0F * var6)),
         (double)(var2 - (5)),
         (double)(var3 - (5)),
         (double)(var2 + (300) + (5)),
         (double)(var3 + (180) + (5)),
         15.0,
         15.0,
         15.0,
         15.0,
         30.0
      );
      RenderUtils.renderRoundedQuad(
         var9,
         new Color(var8.getRed(), var8.getGreen(), var8.getBlue(), (int)((float)var8.getAlpha() * var6)),
         (double)var2,
         (double)var3,
         (double)(var2 + (300)),
         (double)(var3 + (180)),
         10.0,
         10.0,
         10.0,
         10.0,
         20.0
      );
      Color var10 = new Color(var7.getRed(), var7.getGreen(), var7.getBlue(), (int)((float)var7.getAlpha() * var6));
      RenderUtils.renderRoundedQuad(
         var9,
         var10,
         (double)(var2 + (20)),
         (double)var3,
         (double)(var2 + (300) - (20)),
         (double)(var3 + (3)),
         0.0,
         0.0,
         0.0,
         0.0,
         10.0
      );
      RenderUtils.renderRoundedQuad(
         var9,
         var10,
         (double)(var2 + (20)),
         (double)(var3 + (180) - (3)),
         (double)(var2 + (300) - (20)),
         (double)(var3 + (180)),
         0.0,
         0.0,
         0.0,
         0.0,
         10.0
      );
      if (var5 != null) {
         RenderUtils.renderRoundedQuad(
            var9,
            new Color(30, 30, 30, (int)(200.0F * var6)),
            (double)(var2 + (15)),
            (double)(var3 + (15)),
            (double)(var2 + (85)),
            (double)(var3 + (85)),
            5.0,
            5.0,
            5.0,
            5.0,
            10.0
         );
         PlayerSkinDrawer.draw(var1, var5.getSkinTextures(), var2 + (25), var3 + (25), 50);
         TextRenderer.drawString(
            var4.getName().getString(),
            var1,
            var2 + (100),
            var3 + (25),
            ColorUtil.a(
                  (int)((float)(System.currentTimeMillis() % (1000L)) / 1000.0F),
                  255
               )
               .getRGB()
         );
         TextRenderer.drawString(
            MathUtil.roundToNearest(
                  (double)var4.distanceTo(this.mc.player), 1.0
               )
               + " blocks away",
            var1,
            var2 + (100),
            var3 + (45),
            Color.WHITE.getRGB()
         );
         RenderUtils.renderRoundedQuad(
            var9,
            new Color(60, 60, 60, (int)(200.0F * var6)),
            (double)(var2 + (15)),
            (double)(var3 + (95)),
            (double)(var2 + (300) - (15)),
            (double)(var3 + (110)),
            5.0,
            5.0,
            5.0,
            5.0,
            10.0
         );
         float var11 = this.currentHealth / var4.getMaxHealth();
         float var12 = 270.0F * Math.min(1.0F, var11);
         RenderUtils.renderRoundedQuad(
            var9,
            this.healthColor(
               var11
                  * (float)(
                     0.800000011920929
                        + 0.20000000298023224
                           * Math.sin((double)System.currentTimeMillis() / 300.0)
                  ),
               var6
            ),
            (double)(var2 + (15)),
            (double)(var3 + (95)),
            (double)(var2 + (15) + (int)var12),
            (double)(var3 + (110)),
            5.0,
            5.0,
            5.0,
            5.0,
            10.0
         );
         String var13 = Math.round(this.currentHealth) + "/" + Math.round(var4.getMaxHealth()) + " HP";
         TextRenderer.drawString(
            var13,
            var1,
            var2 + (15) + (int)var12 / (2) - TextRenderer.getWidth(var13) / (2),
            var3 + (95),
            Color.WHITE.getRGB()
         );
         int var14 = var3 + (120);
         this.drawStat(
            var1,
            var2 + (15),
            var14,
            80,
            45,
            "PING",
            var5.getLatency() + "ms",
            this.latencyColor(var5.getLatency(), var6),
            var10,
            var6
         );
         String var15;
         if (var5 != null) {
            var15 = "PLAYER";
         } else {
            var15 = "BOT";
         }

         Color var16;
         if (var5 != null) {
            var16 = new Color(
               100, 255, 100, (int)(255.0F * var6)
            );
         } else {
            var16 = new Color(
               255, 100, 100, (int)(255.0F * var6)
            );
         }

         this.drawStat(
            var1,
            var2 + (100) + (5),
            var14,
            80,
            45,
            "TYPE",
            var15,
            var16,
            var10,
            var6
         );
         if (var4.hurtTime > 0) {
            this.drawStat(
               var1,
               var2 + (200) + (5),
               var14,
               80,
               45,
               "HURT",
               var4.hurtTime + "",
               this.hurtColor(var4.hurtTime, var6),
               var10,
               var6
            );
         } else {
            this.drawStat(
               var1,
               var2 + (200) + (5),
               var14,
               80,
               45,
               "HURT",
               "No",
               new Color(
                  150, 150, 150, (int)(255.0F * var6)
               ),
               var10,
               var6
            );
         }
      } else {
         TextRenderer.drawString(
            "BOT DETECTED",
            var1,
            var2
               + (150)
               - TextRenderer.getWidth("BOT DETECTED")
                  / (2),
            var3 + (90),
            new Color(255, 50, 50).getRGB()
         );
      }
   }

   private void drawStat(DrawContext var1, int var2, int var3, int var4, int var5, String var6, String var7, Color var8, Color var9, float var10) {
      Matrix3x2fStack var11 = var1.getMatrices();
      RenderUtils.renderRoundedQuad(
         var11,
         var9,
         (double)var2,
         (double)var3,
         (double)(var2 + var4),
         (double)(var3 + (3)),
         3.0,
         3.0,
         0.0,
         0.0,
         6.0
      );
      RenderUtils.renderRoundedQuad(
         var11,
         new Color(30, 30, 30, (int)(200.0F * var10)),
         (double)var2,
         (double)(var3 + (3)),
         (double)(var2 + var4),
         (double)(var3 + var5),
         0.0,
         0.0,
         3.0,
         3.0,
         6.0
      );
      TextRenderer.drawString(
         var6,
         var1,
         var2 + var4 / (2) - TextRenderer.getWidth(var6) / (2),
         var3 + (5),
         new Color(200, 200, 200, (int)(255.0F * var10)).getRGB()
      );
      TextRenderer.drawString(
         var7,
         var1,
         var2 + var4 / (2) - TextRenderer.getWidth(var7) / (2),
         var3 + var5 - (17),
         var8.getRGB()
      );
   }

   private Color healthColor(float var1, float var2) {
      Color var3;
      if (var1 > 0.75F) {
         var3 = ColorUtil.a(
            new Color(100, 255, 100),
            new Color(255, 255, 100),
            (1.0F - var1) * 4.0F
         );
      } else if (var1 > 0.25F) {
         var3 = ColorUtil.a(
            new Color(255, 255, 100),
            new Color(255, 100, 100),
            (0.75F - var1) * 2.0F
         );
      } else {
         float var4;
         if (var1 < 0.10000000149011612F) {
            var4 = (float)(
               0.699999988079071
                  + 0.30000001192092896
                     * Math.sin((double)System.currentTimeMillis() / 200.0)
            );
         } else {
            var4 = 1.0F;
         }

         var3 = new Color(
            (int)(255.0F * var4),
            (int)(100.0F * var4),
            (int)(100.0F * var4)
         );
      }

      return new Color(var3.getRed(), var3.getGreen(), var3.getBlue(), (int)((float)var3.getAlpha() * var2));
   }

   private Color latencyColor(int var1, float var2) {
      Color var3;
      if (var1 < (50)) {
         var3 = new Color(100, 255, 100);
      } else if (var1 < (100)) {
         var3 = ColorUtil.a(
            new Color(100, 255, 100),
            new Color(255, 255, 100),
            (float)(var1 - (50)) / 50.0F
         );
      } else if (var1 < (200)) {
         var3 = ColorUtil.a(
            new Color(255, 255, 100),
            new Color(255, 150, 50),
            (float)(var1 - (100)) / 100.0F
         );
      } else {
         var3 = ColorUtil.a(
            new Color(255, 150, 50),
            new Color(255, 80, 80),
            Math.min(1.0F, (float)(var1 - (200)) / 300.0F)
         );
      }

      return new Color(var3.getRed(), var3.getGreen(), var3.getBlue(), (int)((float)var3.getAlpha() * var2));
   }

   private Color hurtColor(int var1, float var2) {
      double var3 = 0.699999988079071
         + 0.30000001192092896
            * Math.sin((double)System.currentTimeMillis() / 150.0);
      float var5 = Math.min(1.0F, (float)var1 / 10.0F);
      Color var6 = new Color(
         255,
         (int)(
            50.0F
               + 100.0F * (1.0F - var5)
         ),
         (int)(
            50.0F
               + 100.0F * (1.0F - var5)
         )
      );
      return new Color(
         (int)((float)var6.getRed() * (float)var3),
         (int)((float)var6.getGreen() * (float)var3),
         (int)((float)var6.getBlue() * (float)var3),
         (int)(255.0F * var2)
      );
   }

   @EventListener
   public void onPacketSend(PacketSendEvent var1) {
      if (var1.packet instanceof PlayerInteractEntityC2SPacket var2) {
         if (this.hudHandler == null) {
            this.hudHandler = new AttackPacketDetector(this);
         }

         if (this.hudHandler.isAttackPacket(var2)) {
            this.lastAttackTime = System.currentTimeMillis();
         }
      }
   }

   public static class AttackPacketDetector {
      public static final MinecraftClient MC = MinecraftClient.getInstance();

      AttackPacketDetector(TargetHudModule module) {
      }

      private boolean hasPlayerTarget() {
         return MC.player != null && MC.player.getAttacking() instanceof PlayerEntity;
      }

      public boolean isAttackPacket(PlayerInteractEntityC2SPacket packet) {
         String description;
         try {
            description = packet.toString();
            if (description.contains("ATTACK")) {
               return true;
            }
         } catch (Exception ignored) {
            return hasPlayerTarget();
         }

         try {
            if (!hasPlayerTarget()) {
               return false;
            }
            if (description.contains(Hand.MAIN_HAND.toString()) && description.contains("INTERACT_AT")) {
               return true;
            }
         } catch (Exception ignored) {
            return hasPlayerTarget();
         }

         try {
            return MC.player.handSwinging && MC.player.getAttacking() != null;
         } catch (Exception ignored) {
            return hasPlayerTarget();
         }
      }
   }
}
