package krispy.feature;

import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Random;
import krispy.event.EventListener;
import krispy.event.events.TickEvent;
import krispy.module.Category;
import krispy.module.Module;
import krispy.module.setting.NumberSetting;
import krispy.module.setting.Setting;
import krispy.utils.BlockUtil;
import krispy.utils.EncryptedString;
import krispy.utils.InventoryUtil;
import krispy.utils.KeyUtils;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.component.ComponentMap;
import net.minecraft.component.ComponentType;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.ShieldItem;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import org.lwjgl.glfw.GLFW;


public final class AnchorMacroModule extends Module {
   private final NumberSetting switchDelay = new NumberSetting(
      EncryptedString.of("Switch Delay"),
      0.0,
      20.0,
      0.0,
      1.0
   );
   private final NumberSetting glowstoneDelay = new NumberSetting(
      EncryptedString.of("Glowstone Delay"),
      0.0,
      20.0,
      0.0,
      1.0
   );
   private final NumberSetting explodeDelay = new NumberSetting(
      EncryptedString.of("Explode Delay"),
      0.0,
      20.0,
      0.0,
      1.0
   );
   private final NumberSetting totemSlot = new NumberSetting(
      EncryptedString.of("Totem Slot"),
      1.0,
      9.0,
      1.0,
      1.0
   );
   private int keybind = 0;
   private int glowstoneDelayCounter = 0;
   private int explodeDelayCounter = 0;

   public AnchorMacroModule() {
      super(
         EncryptedString.of("Anchor Macro"),
         EncryptedString.of(
            "Automatically blows up respawn anchors for you"
         ),
         -1,
         Category.COMBAT
      );
      Setting[] var10001 = new Setting[4];
      var10001[0] = this.switchDelay;
      var10001[1] = this.glowstoneDelay;
      var10001[2] = this.explodeDelay;
      var10001[3] = this.totemSlot;
      this.addSettings(var10001);
   }

   @Override
   public void onEnable() {
      this.resetCounters();
      super.onEnable();
   }

   @Override
   public void onDisable() {
      super.onDisable();
   }

   @EventListener
   public void onTick(TickEvent var1) {
      if (this.mc.currentScreen == null && !this.isShieldOrFoodActive() && KeyUtils.isKeyPressed(1)) {
         this.handleAnchorInteraction();
      }
   }

   private boolean isShieldOrFoodActive() {
      int var1 = !this.mc.player.getMainHandStack().getItem().getComponents().contains(DataComponentTypes.FOOD)
            && !this.mc.player.getOffHandStack().getItem().getComponents().contains(DataComponentTypes.FOOD)
         ? 0
         : 1;
      int var2 = !(this.mc.player.getMainHandStack().getItem() instanceof ShieldItem)
            && !(this.mc.player.getOffHandStack().getItem() instanceof ShieldItem)
         ? 0
         : 1;
      int var3 = GLFW.glfwGetMouseButton(this.mc.getWindow().getHandle(), 1) == (1)
         ? 1
         : 0;
      return (((var1 != 0 || var2 != 0) && var3 != 0));
   }

   private void handleAnchorInteraction() {
      if (this.mc.crosshairTarget instanceof BlockHitResult var1 && BlockUtil.isBlockAtPosition(var1.getBlockPos(), Blocks.RESPAWN_ANCHOR)) {
         this.mc.options.useKey.setPressed(false);
         if (BlockUtil.isRespawnAnchorUncharged(var1.getBlockPos())) {
            this.placeGlowstone(var1);
         } else if (BlockUtil.isRespawnAnchorCharged(var1.getBlockPos())) {
            this.explodeAnchor(var1);
         }
      }
   }

   private void placeGlowstone(BlockHitResult var1) {
      if (!this.mc.player.getMainHandStack().isOf(Items.GLOWSTONE)) {
         if (this.keybind < this.switchDelay.getIntValue()) {
            this.keybind += 1;
            return;
         }

         this.keybind = 0;
         InventoryUtil.swap(Items.GLOWSTONE);
      }

      if (this.mc.player.getMainHandStack().isOf(Items.GLOWSTONE)) {
         if (this.glowstoneDelayCounter < this.glowstoneDelay.getIntValue()) {
            this.glowstoneDelayCounter += 1;
            return;
         }

         this.glowstoneDelayCounter = 0;
         BlockUtil.interactWithBlock(var1, true);
      }
   }

   private void explodeAnchor(BlockHitResult var1) {
      int var2 = this.totemSlot.getIntValue() - (1);
      if (this.mc.player.getInventory().getSelectedSlot() != var2) {
         if (this.keybind < this.switchDelay.getIntValue()) {
            this.keybind += 1;
            return;
         }

         this.keybind = 0;
         this.mc.player.getInventory().setSelectedSlot(var2);
      }

      if (this.mc.player.getInventory().getSelectedSlot() == var2) {
         if (this.explodeDelayCounter < this.explodeDelay.getIntValue()) {
            this.explodeDelayCounter += 1;
            return;
         }

         this.explodeDelayCounter = 0;
         BlockUtil.interactWithBlock(var1, true);
      }
   }

   private void resetCounters() {
      this.keybind = 0;
      this.glowstoneDelayCounter = 0;
      this.explodeDelayCounter = 0;
   }
}
