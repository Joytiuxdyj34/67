package krispy.feature;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.entity.feature.FeatureRenderer;
import net.minecraft.client.render.entity.feature.FeatureRendererContext;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Arm;

@Environment(EnvType.CLIENT)
public final class CharacterFeatureRenderer extends FeatureRenderer<PlayerEntityRenderState, PlayerEntityModel> {
   public CharacterFeatureRenderer(FeatureRendererContext<PlayerEntityRenderState, PlayerEntityModel> context) {
      super(context);
   }

   @Override
   public void render(MatrixStack matrices, OrderedRenderCommandQueue commands, int light,
                      PlayerEntityRenderState state, float animationProgress, float headYaw) {
      this.renderCharacter(matrices, commands, light, state, animationProgress, headYaw);
   }

   public void renderCharacter(MatrixStack matrices, OrderedRenderCommandQueue commands, int light,
                               PlayerEntityRenderState state, float animationProgress, float headYaw) {
      WornCharacterModel worn = Character3dModule.worn(state);
      if (worn == null || state.invisible && state.invisibleToPlayer) {
         return;
      }
      CharacterMeshRenderer.submit(worn, this.getContextModel(), matrices, commands, light, state);
   }

   public static boolean firstPersonHand(PlayerEntityModel model, MatrixStack matrices,
                                         OrderedRenderCommandQueue commands, int light, ModelPart hand) {
      return CharacterMeshRenderer.firstPersonHand(model, matrices, commands, light, hand);
   }

   public static boolean translateToHand(PlayerEntityModel model, PlayerEntityRenderState state,
                                         Arm arm, MatrixStack matrices) {
      return CharacterMeshRenderer.translateToHand(model, state, arm, matrices);
   }
}
