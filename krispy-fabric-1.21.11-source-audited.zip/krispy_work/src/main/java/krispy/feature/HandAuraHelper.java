package krispy.feature;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.pipeline.RenderPipeline.Builder;
import com.mojang.blaze3d.pipeline.RenderPipeline.Snippet;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.GpuDevice;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.FilterMode;
import com.mojang.blaze3d.textures.GpuTexture;
import com.mojang.blaze3d.textures.GpuTextureView;
import com.mojang.blaze3d.vertex.VertexFormat;
import com.mojang.blaze3d.vertex.VertexFormat.DrawMode;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.OptionalInt;
import java.util.Random;
import java.util.function.Supplier;
import krispy.utils.BytecodeException;
import krispy.utils.ext.ShaderOverlay;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.Framebuffer;
import net.minecraft.client.gl.GpuSampler;
import net.minecraft.client.gl.SamplerCache;
import net.minecraft.client.gl.SimpleFramebuffer;
import net.minecraft.client.gl.UniformType;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.util.Identifier;
import org.lwjgl.BufferUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


@Environment(EnvType.CLIENT)
final class HandAuraHelper {
   private static final Logger CONSTANT_0292 = LoggerFactory.getLogger(
      "Krispy"
   );
   private static final RenderPipeline CONSTANT_0368 = RenderPipeline.builder(new Snippet[0])
      .withLocation(
         Identifier.of(
            "krispy",
            "pipeline/hand_aura"
         )
      )
      .withVertexShader("core/screenquad")
      .withFragmentShader(
         Identifier.of(
            "krispy",
            "core/hand_aura"
         )
      )
      .withSampler("CaptureSampler")
      .withSampler("HaloSampler")
      .withUniform("HandAuraConfig", UniformType.UNIFORM_BUFFER)
      .withBlend(BlendFunction.TRANSLUCENT_PREMULTIPLIED_ALPHA)
      .withColorWrite(true, false)
      .withDepthWrite(false)
      .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
      .withVertexFormat(VertexFormats.EMPTY, DrawMode.TRIANGLES)
      .build();
   private static final Supplier<String> CONSTANT_0313 = () -> "Krispy hand aura";
   private static final Supplier<String> CONSTANT_0274 = () -> "Krispy hand aura config";
   private static final int CONSTANT_0459 = 48;
   private static SimpleFramebuffer hand;
   private static HandAuraFramebuffer cachedValue0023;
   private static GpuBuffer cachedValue0013;
   private static GpuBufferSlice cachedValue0018;
   private static ByteBuffer cachedValue0002;
   private static boolean stateFlag0001;
   private static boolean stateFlag0014;

   private HandAuraHelper() {
   }

   static boolean begin() {
      if (!stateFlag0001 && RenderSystem.outputColorTextureOverride == null && RenderSystem.outputDepthTextureOverride == null) {
         MinecraftClient var0 = MinecraftClient.getInstance();
         Framebuffer var1 = var0.getFramebuffer();
         if (var0.world != null
            && !var0.gameRenderer.isRenderingPanorama()
            && var1.getColorAttachment() != null
            && var1.textureWidth > 0
            && var1.textureHeight > 0
            && !ShaderOverlay.shaderPackInUse()) {
            GpuDevice var2 = RenderSystem.getDevice();
            if (!shaderReady(var2)) {
               return false;
            } else {
               if (hand == null) {
                  allocate(var1.textureWidth, var1.textureHeight);
               } else if (hand.textureWidth != var1.textureWidth || hand.textureHeight != var1.textureHeight) {
                  hand.resize(var1.textureWidth, var1.textureHeight);
               }

               var2.createCommandEncoder()
                  .clearColorAndDepthTextures(
                     hand.getColorAttachment(), 0, hand.getDepthAttachment(), 1.0
                  );
               RenderSystem.outputColorTextureOverride = hand.getColorAttachmentView();
               RenderSystem.outputDepthTextureOverride = hand.getDepthAttachmentView();
               stateFlag0001 = true;
               return true;
            }
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   static boolean end() {
      if (!stateFlag0001) {
         return false;
      } else {
         stateFlag0001 = false;
         RenderSystem.outputColorTextureOverride = null;
         RenderSystem.outputDepthTextureOverride = null;
         return true;
      }
   }

   static void compose(int var0, float var1, float var2, float var3, float var4, int var5, float var6, float var7) {
      Framebuffer var8 = MinecraftClient.getInstance().getFramebuffer();
      CommandEncoder var9 = RenderSystem.getDevice().createCommandEncoder();
      GpuTextureView var10 = var1 > 0.0F
         ? cachedValue0023.spread(var9, hand.getColorAttachmentView(), hand.textureWidth, hand.textureHeight, var2)
         : hand.getColorAttachmentView();
      putColor(0, var0, var1);
      putColor(16, var5, var6);
      cachedValue0002.putFloat(32, var3);
      cachedValue0002.putFloat(36, var4);
      cachedValue0002.putFloat(40, var7);
      cachedValue0002.putFloat(44, 0.0F);
      var9.writeToBuffer(cachedValue0018, cachedValue0002);
      RenderPass var11 = var9.createRenderPass(CONSTANT_0313, var8.getColorAttachmentView(), OptionalInt.empty());

      try {
         var11.setPipeline(CONSTANT_0368);
         var11.setUniform("HandAuraConfig", cachedValue0018);
         var11.bindTexture(
            "CaptureSampler",
            hand.getColorAttachmentView(),
            RenderSystem.getSamplerCache().get(FilterMode.LINEAR)
         );
         var11.bindTexture(
            "HaloSampler",
            var10,
            RenderSystem.getSamplerCache().get(FilterMode.LINEAR)
         );
         var11.draw(0, 3);
      } catch (Throwable var15) {
         if (var11 != null) {
            try {
               var11.close();
            } catch (Throwable var14) {
               var15.addSuppressed(var14);
            }
         }

         throw var15;
      }

      if (var11 != null) {
         var11.close();
      }
   }

   private static void putColor(int var0, int var1, float var2) {
      cachedValue0002.putFloat(
         var0, (float)(var1 >> (16) & (255)) / 255.0F
      );
      cachedValue0002.putFloat(
         var0 + (4),
         (float)(var1 >> (8) & (255)) / 255.0F
      );
      cachedValue0002.putFloat(
         var0 + (8), (float)(var1 & (255)) / 255.0F
      );
      cachedValue0002.putFloat(var0 + (12), var2);
   }

   private static boolean shaderReady(GpuDevice var0) {
      if (var0.precompilePipeline(CONSTANT_0368).isValid() && HandAuraFramebuffer.compiled(var0)) {
         stateFlag0014 = false;
         return true;
      } else {
         if (!stateFlag0014) {
            stateFlag0014 = true;
            CONSTANT_0292.warn(
               "Hand Aura shaders did not compile; the hand is drawn as usual"
            );
         }

         return false;
      }
   }

   private static void allocate(int var0, int var1) {
      hand = new SimpleFramebuffer(
         "Krispy hand aura", var0, var1, true
      );
      cachedValue0023 = new HandAuraFramebuffer("Krispy hand aura");
      cachedValue0013 = RenderSystem.getDevice()
         .createBuffer(CONSTANT_0274, 136, 48L);
      cachedValue0018 = cachedValue0013.slice();
      cachedValue0002 = BufferUtils.createByteBuffer(48);
   }

   static void release() {
      if (stateFlag0001) {
         end();
      }

      if (hand != null) {
         hand.delete();
         hand = null;
      }

      if (cachedValue0023 != null) {
         cachedValue0023.release();
         cachedValue0023 = null;
      }

      if (cachedValue0013 != null) {
         cachedValue0013.close();
         cachedValue0013 = null;
      }

      cachedValue0018 = null;
      cachedValue0002 = null;
   }
}
