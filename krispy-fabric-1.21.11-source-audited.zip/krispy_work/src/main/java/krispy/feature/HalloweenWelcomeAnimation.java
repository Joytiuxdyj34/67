package krispy.feature;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public final class HalloweenWelcomeAnimation {
   public static final float CONTINUE_DELAY = 3.0F;
   private static final float WELCOME_IN = 0.45F;
   private static final float BRAND_IN = 0.9F;
   private static final float LANDED = 2.1F;
   private final Random rnd = new Random();
   private final List<HalloweenWelcomeAnimation.WelcomeParticle> motes = new ArrayList<>();
   private final float[] button = new float[4];
   private float buttonShown;
   private float hover;
   private float press;
   private float spawn;
   private float flicker = 1.0F;

   public static float continueAt() {
      return 5.1F;
   }

   public boolean overContinue(double var1, double var3) {
      return this.buttonShown > 0.6F
         && var1 >= (double)this.button[0]
         && var3 >= (double)this.button[1]
         && var1 < (double)(this.button[0] + this.button[2])
         && var3 < (double)(this.button[1] + this.button[3]);
   }

   public boolean continueVisible() {
      return this.buttonShown > 0.6F;
   }

   public void pressed() {
      this.press = 1.0F;
   }

   private static float expoOut(float var0) {
      var0 = UiEasing.clamp(var0, 0.0F, 1.0F);
      return var0 >= 1.0F ? 1.0F : 1.0F - (float)Math.pow(2.0, -10.0 * (double)var0);
   }

   private static float smooth(float var0) {
      var0 = UiEasing.clamp(var0, 0.0F, 1.0F);
      return var0 * var0 * (3.0F - 2.0F * var0);
   }

   private static int argb(float var0, int var1) {
      return Math.round(UiEasing.clamp(var0, 0.0F, 1.0F) * 255.0F) << 24 | var1 & 16777215;
   }

   public void render(UiRenderer var1, int var2, int var3, float var4, float var5, float var6, double var7, double var9) {
      float var11 = UiEasing.inOut(var6);
      float var12 = 1.0F - var11;
      float var13 = (float)var3 / 1080.0F;
      float var14 = (float)var2 / 2.0F;
      float var15 = (float)var3 * 0.42F;
      float var16 = 0.86F
         + 0.08F * (float)Math.sin((double)(var4 * 7.1F)) * (float)Math.sin((double)(var4 * 2.3F + 1.0F))
         + 0.06F * (float)Math.sin((double)(var4 * 13.7F));
      this.flicker = this.flicker + (var16 - this.flicker) * (1.0F - (float)Math.exp((double)(-var5 * 12.0F)));
      float var17 = smooth((var4 - 0.2F) / 1.4F) * var12;
      var1.glow(var14, var15, (float)var3 * 0.7F, UiRenderer.argb(0.38F * var17, 6, 2, 8));
      int var18 = Math.max(18, Math.round(96.0F * var13));
      HalloweenFonts.GlyphLayers var19 = HalloweenFonts.title("KRISPY CLIENT", var18, 0.02F);
      float var20 = expoOut((var4 - 0.9F) / 1.25F);
      float var21 = smooth((var4 - 0.9F) / 0.7F) * var12;
      float var22 = (1.0F + 0.1F * (1.0F - var20)) * (1.0F + 0.04F * var11);
      float var23 = (float)var19.w * var22;
      float var24 = (float)var19.h * var22;
      float var25 = var14 - var23 / 2.0F;
      float var26 = var15 - var24 / 2.0F + 14.0F * var13 * (1.0F - var20) - 8.0F * var13 * var11;
      float var27 = (float)Math.exp((double)(-Math.max(0.0F, var4 - 0.9F - 0.55F) * 2.2F)) * smooth((var4 - 0.9F - 0.15F) / 0.45F);
      if (var21 > 0.002F) {
         float var28 = (0.3F + 0.4F * var27) * this.flicker;
         var1.texture(var19.glow, var25, var26 + 6.0F * var13 * var22, var23, var24, argb(var28 * var21, 16742942));
         var1.texture(var19.glow, var25, var26, var23, var24, argb(0.22F * var21 * this.flicker, 16762218));
         var1.texture(var19.stroke, var25, var26 + 5.0F * var13 * var22, var23, var24, argb(0.55F * var21, 656134));
         var1.texture(var19.stroke, var25, var26, var23, var24, argb(0.92F * var21, 1509129));
         int var29 = UiEasing.mix(-1648952, -1, this.flicker * 0.9F + var27 * 0.4F);
         var1.texture(var19.fill, var25, var26, var23, var24, var29 & 16777215 | Math.round(255.0F * var21) << 24);
         float var30 = (var4 - 2.1F - 0.2F) / 2.2F;
         if (var30 > 0.0F && var30 < 1.0F) {
            float var31 = var25 + var23 * (var30 * 1.25F - 0.12F);
            var1.pushClip(var31 - var23 * 0.05F, var26, var23 * 0.1F, var24);
            var1.texture(var19.stroke, var25, var26, var23, var24, argb(0.3F * var21 * (float)Math.sin(Math.PI * (double)var30), 16774368));
            var1.popClip();
         }
      }

      float var57 = expoOut((var4 - 0.45F) / 1.4F);
      float var58 = smooth((var4 - 0.45F) / 0.8F) * var12;
      int var59 = Math.max(10, Math.round(22.0F * var13));
      float var60 = var26 + (float)var19.pad * var22 - 12.0F * var13;
      float var32 = var60 - (float)var59 * 1.9F - (1.0F - var57) * 10.0F * var13 - var11 * 6.0F * var13;
      if (var58 > 0.002F) {
         String var33 = "WELCOME TO";
         float var34 = (float)var59 * (0.95F - 0.5F * var57);
         float var35 = 0.0F;

         for (int var36 = 0; var36 < var33.length(); var36++) {
            var35 += HalloweenFonts.glyph(var33.charAt(var36), var59).advance + (var36 + 1 < var33.length() ? var34 : 0.0F);
         }

         float var66 = var14 - var35 / 2.0F;
         int var37 = 15984338;

         for (int var38 = 0; var38 < var33.length(); var38++) {
            HalloweenFonts.GlyphMask var39 = HalloweenFonts.glyph(var33.charAt(var38), var59);
            float var40 = smooth((var4 - 0.45F - (float)var38 * 0.035F) / 0.6F) * var12;
            var1.texture(
               var39.mask,
               var66 - (float)var39.pad,
               var32 - (float)var39.pad + 3.0F * var13 * (1.0F - var40),
               (float)var39.mask.w,
               (float)var39.mask.h,
               argb(0.9F * var40 * var58, var37)
            );
            var66 += var39.advance + var34;
         }

         float var69 = smooth((var4 - 0.45F - 0.3F) / 1.0F) * var58;
         float var71 = var32 + (float)var59 * 0.38F;
         float var73 = 22.0F * var13;
         float var41 = 150.0F * var13 * var69;
         var1.pushTransform(var14 - var35 / 2.0F - var73 - var41, var71, 1.0F);
         hRule(var1, var41, Math.max(1.0F, 1.4F * var13), argb(0.65F * var69, var37), false);
         var1.popTransform();
         var1.pushTransform(var14 + var35 / 2.0F + var73, var71, 1.0F);
         hRule(var1, var41, Math.max(1.0F, 1.4F * var13), argb(0.65F * var69, var37), true);
         var1.popTransform();
      }

      float var61 = smooth((var4 - 0.9F - 0.6F) / 1.1F) * var12;
      if (var61 > 0.002F) {
         float var62 = var26 + var24 - (float)var19.pad * var22 + 22.0F * var13;
         float var64 = 210.0F * var13 * var61;
         var1.pushTransform(var14 - var64 - 16.0F * var13, var62, 1.0F);
         hRule(var1, var64, Math.max(1.0F, 1.4F * var13), argb(0.55F * var61, 15980980), false);
         var1.popTransform();
         var1.pushTransform(var14 + 16.0F * var13, var62, 1.0F);
         hRule(var1, var64, Math.max(1.0F, 1.4F * var13), argb(0.55F * var61, 15980980), true);
         var1.popTransform();
         HalloweenGhostOverlay.lantern(var1, var14 - 12.0F * var13, var62 - 13.0F * var13, 24.0F * var13, var4, var61);
      }

      this.motes(var1, (float)var2, (float)var3, var14, var15, var23, var24, var4, var5, var12 * smooth((var4 - 0.9F) / 1.6F));
      float var63 = expoOut((var4 - continueAt()) / 0.9F);
      this.buttonShown = smooth((var4 - continueAt()) / 0.6F) * var12;
      if (this.buttonShown > 0.002F) {
         float var65 = 236.0F * var13;
         float var67 = 54.0F * var13;
         float var68 = (float)var3 * 0.665F;
         boolean var70 = this.buttonShown > 0.6F
            && var7 >= (double)(var14 - var65 / 2.0F)
            && var7 < (double)(var14 + var65 / 2.0F)
            && var9 >= (double)var68
            && var9 < (double)(var68 + var67);
         this.hover = this.hover + ((var70 ? 1.0F : 0.0F) - this.hover) * (1.0F - (float)Math.exp((double)(-14.0F * var5)));
         this.press = Math.max(0.0F, this.press - var5 * 3.0F);
         float var72 = (1.0F - var63) * 20.0F * var13 + this.hover * 2.0F * var13;
         float var74 = (0.95F + 0.05F * var63) * (1.0F - 0.03F * this.press);
         float var75 = var65 * var74;
         float var42 = var67 * var74;
         float var43 = var14 - var75 / 2.0F;
         float var44 = var68 - var72 + (var67 - var42) / 2.0F;
         this.button[0] = var14 - var65 / 2.0F;
         this.button[1] = var68;
         this.button[2] = var65;
         this.button[3] = var67;
         var1.pushAlpha(this.buttonShown);
         float var45 = (var4 - continueAt()) % 2.6F / 2.6F;
         if (var63 > 0.98F) {
            float var46 = var45 * 10.0F * var13;
            var1.outline(
               var43 - var46,
               var44 - var46,
               var75 + var46 * 2.0F,
               var42 + var46 * 2.0F,
               var42 / 2.0F + var46,
               Math.max(1.0F, var13),
               argb(0.2F * (1.0F - var45), 16756832)
            );
         }

         var1.shadow(var43, var44, var75, var42, var42 / 2.0F, 22.0F * var13, UiRenderer.argb(0.5F, 0, 0, 0));
         var1.glow(var43 + var75 / 2.0F, var44 + var42 / 2.0F, var75 * 0.75F, argb(0.05F + 0.1F * this.hover, 16747066));
         var1.round(var43, var44, var75, var42, var42 / 2.0F, UiRenderer.argb(0.7F, 20, 12, 14));
         var1.roundGradient(var43, var44, var75, var42 * 0.55F, var42 / 2.0F, UiRenderer.white(0.06F + 0.04F * this.hover), UiRenderer.white(0.0F));
         var1.round(var43, var44, var75, var42, var42 / 2.0F, argb(0.1F * this.hover + 0.18F * this.press, 16751176));
         var1.outline(
            var43, var44, var75, var42, var42 / 2.0F, Math.max(1.0F, 1.2F * var13), UiEasing.mix(argb(0.22F, 15984338), argb(0.8F, 16757862), this.hover)
         );
         int var76 = Math.max(8, Math.round(15.0F * var13));
         String var47 = "CONTINUE";
         float var48 = (float)var76 * 0.28F;
         float var49 = 0.0F;

         for (int var50 = 0; var50 < var47.length(); var50++) {
            var49 += HalloweenFonts.glyph(var47.charAt(var50), var76).advance + (var50 + 1 < var47.length() ? var48 : 0.0F);
         }

         float var77 = 16.0F * var13;
         float var51 = 10.0F * var13;
         float var52 = var43 + (var75 - var49 - var51 - var77) / 2.0F;
         float var53 = var44 + (var42 - (float)var76) / 2.0F - (float)var76 * 0.08F;
         int var54 = UiEasing.mix(-792878, -7492, this.hover);

         for (int var55 = 0; var55 < var47.length(); var55++) {
            HalloweenFonts.GlyphMask var56 = HalloweenFonts.glyph(var47.charAt(var55), var76);
            var1.texture(var56.mask, var52 - (float)var56.pad, var53 - (float)var56.pad, (float)var56.mask.w, (float)var56.mask.h, var54);
            var52 += var56.advance + var48;
         }

         var1.icon(
            UiIcon.CHEVRON_RIGHT,
            var52 - var48 + var51 + this.hover * 3.0F * var13,
            var44 + (var42 - var77) / 2.0F,
            var77,
            UiEasing.mix(UiRenderer.white(0.75F), argb(1.0F, 16757862), this.hover)
         );
         var1.popAlpha();
      }
   }

   private static void hRule(UiRenderer var0, float var1, float var2, int var3, boolean var4) {
      byte var5 = 12;
      float var6 = var1 / (float)var5;

      for (int var7 = 0; var7 < var5; var7++) {
         float var8 = ((float)var7 + 0.5F) / (float)var5;
         float var9 = var4 ? 1.0F - var8 : var8;
         int var10 = Math.round((float)(var3 >>> 24) * var9 * var9) << 24 | var3 & 16777215;
         var0.rect((float)var7 * var6, 0.0F, var6 + 0.5F, var2, var10);
      }
   }

   private void motes(UiRenderer var1, float var2, float var3, float var4, float var5, float var6, float var7, float var8, float var9, float var10) {
      if (!(var10 <= 0.002F)) {
         this.spawn += var9 * 16.0F;

         while (this.spawn >= 1.0F && this.motes.size() < 56) {
            this.spawn--;
            HalloweenWelcomeAnimation.WelcomeParticle var11 = new HalloweenWelcomeAnimation.WelcomeParticle();
            var11.kind = this.rnd.nextFloat() < 0.72F ? 0 : 1;
            var11.x = var4 + (this.rnd.nextFloat() - 0.5F) * var6 * 1.25F;
            var11.y = var5 + var7 * (0.25F + this.rnd.nextFloat() * 0.9F);
            var11.vx = (this.rnd.nextFloat() - 0.5F) * var3 * 0.01F;
            var11.vy = -var3 * (0.03F + this.rnd.nextFloat() * 0.04F) * (var11.kind == 1 ? 0.35F : 1.0F);
            var11.life = 2.4F + this.rnd.nextFloat() * 2.6F;
            var11.size = var3 * (var11.kind == 0 ? 0.0012F + this.rnd.nextFloat() * 0.0018F : 8.0E-4F + this.rnd.nextFloat() * 0.001F);
            var11.seed = this.rnd.nextFloat() * 50.0F;
            this.motes.add(var11);
         }

         for (int var20 = this.motes.size() - 1; var20 >= 0; var20--) {
            HalloweenWelcomeAnimation.WelcomeParticle var12 = this.motes.get(var20);
            var12.age += var9;
            if (var12.age >= var12.life) {
               this.motes.remove(var20);
            } else {
               float var13 = 1.0F - var12.age / var12.life;
               var12.x = var12.x
                  + (var12.vx + (float)Math.sin((double)(var12.age * 2.1F + var12.seed)) * var3 * 0.012F * (var12.kind == 0 ? 1.0F : 0.4F)) * var9;
               var12.y = var12.y + var12.vy * var9 * (0.5F + 0.5F * var13);
               float var14 = var12.age / var12.life;
               float var15 = (float)Math.sin(Math.PI * (double)Math.min(1.0F, var14 * 1.2F)) * var10;
               float var16 = (var12.x - var4) / (var6 * 0.52F);
               float var17 = (var12.y - var5) / (var7 * 0.42F);
               var15 *= UiEasing.clamp((var16 * var16 + var17 * var17 - 0.7F) / 0.6F, 0.12F, 1.0F);
               if (var12.kind == 0) {
                  float var18 = 0.65F + 0.35F * (float)Math.sin((double)(var12.age * 19.0F + var12.seed));
                  int var19 = UiEasing.mix(-8032, -38368, var14);
                  var1.glow(var12.x, var12.y, var12.size * 8.0F, argb(0.16F * var15 * var18, 16738842));
                  var1.glow(var12.x, var12.y, var12.size * 2.0F, argb(0.95F * var15 * var18, var19));
               } else {
                  var1.glow(var12.x, var12.y, var12.size * 3.0F, argb(0.35F * var15, 15984338));
               }
            }
         }
      }
   }

   private static final class WelcomeParticle {
      float x;
      float y;
      float vx;
      float vy;
      float life;
      float age;
      float size;
      float seed;
      int kind;
   }
}
