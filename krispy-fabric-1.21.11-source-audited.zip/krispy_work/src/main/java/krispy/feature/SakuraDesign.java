package krispy.feature;

import java.util.ArrayList;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public final class SakuraDesign extends CharacterDefinition {
   private static final int SKIN = -9016;
   private static final int SKIN_SHADE = -1331558;
   private static final int SKIN_LINE = -5740452;
   private static final int HAIR_ROOT = -2592100;
   private static final int HAIR = -677434;
   private static final int HAIR_TIP = -12321;
   private static final int HAIR_SHADE = -3908470;
   private static final int HAIR_LINE = -6864801;
   private static final int SHINE = -855643406;
   private static final int WHITE = -263689;
   private static final int WHITE_SHADE = -2305053;
   private static final int SLEEVE_IN = -2502430;
   private static final int CLOTH_LINE = -7568744;
   private static final int RED = -2674372;
   private static final int RED_DARK = -5955793;
   private static final int RED_IN = -10087904;
   private static final int RED_LINE = -8514270;
   private static final int CORD = -1816774;
   private static final int GOLD = -1459895;
   private static final int BEAD = -2608577;
   private static final int STRAW = -1320012;
   private static final int SOLE = -10600144;
   private static final int PETAL = -8984;
   private static final int PETAL_CORE = -2078596;
   private static final float HAKAMA_TOP = 20.0F;
   private static final float HAKAMA_HEM = 2.5F;
   private static final float HS = 1.12F;
   private static final float DROP = 0.4F;
   private static final float HX = 0.0F;
   private static final float HY = 28.9F;
   private static final float HZ = -0.3F;
   private static final float PPU = 56.88889F;
   private static final float FACE_TOP = 29.95F;
   private static final float[] PLEATS;
   private static final float[][] LOCKS;
   private static final Sdf2D SLEEVE_SIDE;

   public SakuraDesign() {
      super("sakura", "Sakura");
   }

   protected void define(CharacterRig var1) {
      var1.scale(1.0F)
         .outline(-11914176, 0.11999999731779099F)
         .occlusion(0.30000001192092896F)
         .flatLight(0.550000011920929F);
      float[][] var2 = lockPaths();
      SurfacePaint var3 = hairPaint();
      head(var1, var2);
      hair(var1, var3);
      fringe(var1, var2);
      kanzashi(var1);
      body(var1);
      hakama(var1);
      arms(var1);
      legs(var1);
   }

   private static Sdf3D up(Sdf3D var0) {
      return var0.scale(
            1.1200000047683716F,
            0.0F,
            24.600000381469727F,
            -0.20000000298023224F
         )
         .move(0.0F, -0.4000000059604645F, 0.0F);
   }

   private static float tx(float var0) {
      return var0 * 1.1200000047683716F;
   }

   private static float ty(float var0) {
      return 24.600000381469727F
         + (var0 - 24.600000381469727F) * 1.1200000047683716F
         - 0.4000000059604645F;
   }

   private static float tz(float var0) {
      return -0.20000000298023224F
         + (var0 + 0.20000000298023224F) * 1.1200000047683716F;
   }

   private static Sdf3D headBase() {
      float var10000 = 0.8500000238418579F;
      Sdf3D[] var10001 = new Sdf3D[3];
      var10001[0] = SdfShapes.ellipsoid(
         0.0F,
         28.719999313354492F,
         -0.15000000596046448F,
         2.2799999713897705F,
         2.4000000953674316F,
         2.3499999046325684F
      );
      var10001[1] = SdfShapes.ellipsoid(
         0.0F,
         27.75F,
         0.550000011920929F,
         2.049999952316284F,
         1.2999999523162842F,
         1.75F
      );
      var10001[2] = SdfShapes.cone(
         0.0F,
         27.299999237060547F,
         0.6200000047683716F,
         1.350000023841858F,
         0.0F,
         26.049999237060547F,
         1.2000000476837158F,
         0.30000001192092896F
      );
      return SdfShapes.blend(var10000, var10001);
   }

   private static void head(CharacterRig var0, float[][] var1) {
      Sdf3D var2 = SdfShapes.capsule(
         0.0F,
         23.299999237060547F,
         -0.44999998807907104F,
         0.0F,
         25.899999618530273F,
         -0.30000001192092896F,
         0.6000000238418579F
      );
      float var3 = ty(25.81999969482422F);
      float var4 = tz(1.2000000476837158F);
      SurfacePaint var5 = SurfacePaint.field(
         (var2x, var3x, var4x) -> {
            float var5x = var3 + Math.max(0.0F, var4 - var4x) * 0.6200000047683716F;
            float var6x = smooth(var5x + 0.05000000074505806F, var5x - 0.20000000298023224F, var3x)
               * (
                  0.6000000238418579F
                     + 0.4000000059604645F
                        * smooth(23.399999618530273F, 24.799999237060547F, var3x)
               );
            return ArgbColors.mix(-9016, -1331558, var6x);
         }
      );
      Sdf3D var6 = up(
         headBase().intersect(SdfShapes.below(30.200000762939453F))
      );
      CharacterPartBuilder var10000 = var0.part(CharacterBone.HEAD)
         .pivot(0.0F, 24.600000381469727F, -0.20000000298023224F);
      float var10001 = 0.44999998807907104F;
      Sdf3D[] var10002 = new Sdf3D[2];
      var10002[0] = var6;
      var10002[1] = var2;
      var10000.shape(SdfShapes.blend(var10001, var10002).paint(var5))
         .detail(2.0F)
         .flatLight(1.0F)
         .occlusion(0.2199999988079071F)
         .outline(-5740452, 0.10000000149011612F)
         .decal(face(var1));
   }

   private static float[][] lockPaths() {
      Sdf3D var0 = headBase();
      float[][] var1 = new float[LOCKS.length][];

      for (int var2 = 0; var2 < LOCKS.length; var2++) {
         float[] var3 = LOCKS[var2];
         float[] var4 = onHead(
            36.0F, var3[2], -0.15000000596046448F
         );
         float[] var5 = onHead(
            58.0F, var3[2], 0.05000000074505806F
         );
         float var6 = var5[0]
            + (var3[0] - var5[0]) * 0.75F;
         float var7 = var3[1] + 0.6800000071525574F;
         float var8 = var3[0] - Math.signum(var3[0]) * var3[4];
         float[] var10002 = new float[13];
         var10002[0] = var4[0];
         var10002[1] = var4[1];
         var10002[2] = var4[2];
         var10002[3] = var5[0];
         var10002[4] = var5[1];
         var10002[5] = var5[2];
         var10002[6] = var6;
         var10002[7] = var7;
         var10002[8] = frontZ(var0, var6, var7) + var3[5];
         var10002[9] = var8;
         var10002[10] = var3[1];
         var10002[11] = frontZ(var0, var8, var3[1])
            + 0.2199999988079071F;
         var10002[12] = var3[3];
         var1[var2] = var10002;
      }

      return var1;
   }

   private static float frontZ(Sdf3D var0, float var1, float var2) {
      float var3 = 3.5F;

      while (var3 > -1.0F && var0.distance(var1, var2, var3) > 0.0F) {
         var3 -= 0.019999999552965164F;
      }

      return var3;
   }

   private static void fringe(CharacterRig var0, float[][] var1) {
      Sdf3D[] var2 = new Sdf3D[var1.length];
      Sdf3D[] var3 = new Sdf3D[var1.length];

      for (int var4 = 0; var4 < var1.length; var4++) {
         float[] var5 = var1[var4];
         float var6 = var5[12];
         float[] var10000 = new float[16];
         var10000[0] = var5[0];
         var10000[1] = var5[1];
         var10000[2] = var5[2];
         var10000[3] = 0.8999999761581421F * var6;
         var10000[4] = var5[3];
         var10000[5] = var5[4];
         var10000[6] = var5[5];
         var10000[7] = 1.149999976158142F * var6;
         var10000[8] = var5[6];
         var10000[9] = var5[7];
         var10000[10] = var5[8];
         var10000[11] = 0.949999988079071F * var6;
         var10000[12] = var5[9];
         var10000[13] = var5[10];
         var10000[14] = var5[11];
         var10000[15] = 0.11999999731779099F;
         TaperedTubeSdf3D var7 = SdfShapes.tube(var10000)
            .flattenFrom(
               3.0F,
               0.0F,
               28.700000762939453F,
               -0.15000000596046448F
            );
         var3[var4] = SdfShapes.extrude(
            Sdf2D.polygon(blade(var5)),
            5.0F,
            0.0F
         );
         var2[var4] = SdfShapes.intersect(var7, var3[var4]);
      }

      Sdf3D var8 = SdfShapes.intersect(
         SdfShapes.blend(0.15000000596046448F, var2), SdfShapes.union(var3)
      );
      Sdf3D var9 = headBase();
      SurfacePaint var10 = SurfacePaint.field(
         (var1x, var2x, var3x) -> {
            int var4x = ArgbColors.mix(
               ArgbColors.mix(-2592100, -677434, 0.44999998807907104F),
               -677434,
               smooth(30.899999618530273F, 29.700000762939453F, var2x)
            );
            var4x = ArgbColors.mix(
               var4x,
               -12321,
               0.5F
                  * smooth(29.5F, 28.5F, var2x)
            );
            return ArgbColors.mix(
               var4x,
               -3908470,
               0.6000000238418579F
                  * (
                     1.0F
                        - smooth(
                           0.11999999731779099F, 0.41999998688697815F, var9.distance(var1x, var2x, var3x)
                        )
                  )
            );
         }
      );
      var0.extra("fringe", CharacterBone.HEAD)
         .shape(up(var8.paint(var10)))
         .resolution(0.44999998807907104F)
         .detail(1.0499999523162842F)
         .flatLight(0.699999988079071F)
         .occlusion(0.10000000149011612F)
         .outline(-6864801, 0.09000000357627869F)
         .decal(shine());
   }

   private static float[] blade(float[] var0) {
      float var1 = var0[12];
      int var2 = var0[9] < 0.0F ? 1 : 0;
      float var3 = var0[3];
      float var4 = 31.600000381469727F;
      float var5 = var0[6];
      float var6 = var0[7];
      float var7 = var0[9];
      float var8 = var0[10];
      int var9 = 12;
      float[] var10 = new float[((2) * var9 + (1)) * (2)];

      for (int var11 = 0; var11 <= var9; var11++) {
         float var12 = (float)var11 / (float)var9;
         float var13 = 1.0F - var12;
         float var14 = var13 * var13 * var3 + 2.0F * var13 * var12 * var5 + var12 * var12 * var7;
         float var15 = var13 * var13 * var4 + 2.0F * var13 * var12 * var6 + var12 * var12 * var8;
         float var16 = var13 * (var5 - var3) + var12 * (var7 - var5);
         float var17 = var13 * (var6 - var4) + var12 * (var8 - var6);
         float var18 = (float)Math.sqrt((double)(var16 * var16 + var17 * var17));
         float var19 = -var17 / var18;
         float var20 = var16 / var18;
         if ((var19 > 0.0F ? 1 : 0) != var2) {
            var19 = -var19;
            var20 = -var20;
         }

         float var21 = var1
            * (
               1.0F
                  - smooth(0.6000000238418579F, 1.0F, var12)
            );
         float var22 = var1
            * (
               1.0F
                  - (float)Math.pow(
                     (double)smooth(0.30000001192092896F, 1.0F, var12),
                     0.75
                  )
            );
         var10[var11 * (2)] = var14 + var19 * var21;
         var10[var11 * (2) + (1)] = var15 + var20 * var21;
         if (var11 < var9) {
            var10[((2) * var9 - var11) * (2)] = var14 - var19 * var22;
            var10[((2) * var9 - var11) * (2) + (1)] = var15 - var20 * var22;
         }
      }

      return var10;
   }

   private static SurfaceDecal shine() {
      PixelCanvas var0 = new PixelCanvas(280, 22);
      float[][] var10000 = new float[5][];
      int var10002 = 0;
      float[] var10003 = new float[2];
      var10003[0] = -68.0F;
      var10003[1] = -54.0F;
      var10000[var10002] = var10003;
      var10002 = 1;
      var10003 = new float[2];
      var10003[0] = -45.0F;
      var10003[1] = -25.0F;
      var10000[var10002] = var10003;
      var10002 = 2;
      var10003 = new float[2];
      var10003[0] = -13.0F;
      var10003[1] = 9.0F;
      var10000[var10002] = var10003;
      var10002 = 3;
      var10003 = new float[2];
      var10003[0] = 20.0F;
      var10003[1] = 38.0F;
      var10000[var10002] = var10003;
      var10002 = 4;
      var10003 = new float[2];
      var10003[0] = 48.0F;
      var10003[1] = 64.0F;
      var10000[var10002] = var10003;
      float[][] var1 = var10000;
      float[][] var2 = var1;
      int var3 = var1.length;

      for (int var4 = 0; var4 < var3; var4++) {
         float[] var5 = var2[var4];
         float var6 = var5[0];
         float var7 = var5[1];
         float var8 = (var6 + var7) * 0.5F;
         float var9 = 6.5F - Math.abs(var8) * 0.02500000037252903F;
         var0.fill(
            Sdf2D.curve(
               140.0F + var6 * 2.0F,
               ringY(var6),
               140.0F + var6 + var8,
               ringY((var6 + var8) * 0.5F),
               140.0F + var8 * 2.0F,
               ringY(var8),
               1.0F,
               var9
            ),
            -855643406
         );
         var0.fill(
            Sdf2D.curve(
               140.0F + var8 * 2.0F,
               ringY(var8),
               140.0F + var8 + var7,
               ringY((var8 + var7) * 0.5F),
               140.0F + var7 * 2.0F,
               ringY(var7),
               var9,
               1.0F
            ),
            -855643406
         );
      }

      return SurfaceDecal.wrap(
            var0,
            0.0F,
            ty(30.15999984741211F),
            tz(-0.30000001192092896F),
            0.0F,
            1.0F,
            0.0F,
            0.0F,
            0.0F,
            1.0F,
            140.0F,
            0.6272000074386597F
         )
         .radius(1.2000000476837158F, 3.799999952316284F)
         .offset(0.029999999329447746F);
   }

   private static float ringY(float var0) {
      float var1 = 30.399999618530273F
         - 0.36000001430511475F * (1.0F - (float)Math.cos(Math.toRadians((double)var0)));
      return (30.440000534057617F - var1) * 40.0F;
   }

   private static void hair(CharacterRig var0, SurfacePaint var1) {
      ArrayList var2 = new ArrayList();
      var2.add(
         SdfShapes.ellipsoid(
            0.0F,
            28.899999618530273F,
            -0.30000001192092896F,
            2.5799999237060547F,
            2.619999885559082F,
            2.700000047683716F
         )
      );
      float[] var10000 = new float[4];
      var10000[0] = 64.0F;
      var10000[1] = 88.0F;
      var10000[2] = 272.0F;
      var10000[3] = 296.0F;
      float[] var3 = var10000;
      int var4 = var3.length;

      for (int var5 = 0; var5 < var4; var5++) {
         float var6 = var3[var5];
         var2.add(
            capLock(
               var6,
               5.0F,
               98.0F,
               0.800000011920929F,
               0.6200000047683716F
            )
         );
      }

      Sdf3D var12 = SdfShapes.box(
         0.0F,
         26.299999237060547F,
         2.299999952316284F,
         2.950000047683716F,
         3.299999952316284F,
         2.799999952316284F,
         0.8999999761581421F
      );
      float var16 = 0.30000001192092896F;
      Sdf3D[] var10001 = new Sdf3D[2];
      int var10003 = 0;
      float var10004 = 0.6200000047683716F;
      float var10005 = 0.4399999976158142F;
      float[] var10006 = new float[9];
      var10006[0] = -2.299999952316284F;
      var10006[1] = 29.600000381469727F;
      var10006[2] = -0.05000000074505806F;
      var10006[3] = -2.4800000190734863F;
      var10006[4] = 28.100000381469727F;
      var10006[5] = -0.11999999731779099F;
      var10006[6] = -2.450000047683716F;
      var10006[7] = 26.5F;
      var10006[8] = -0.2199999988079071F;
      var10001[var10003] = SdfShapes.strand(var10004, var10005, var10006)
         .flatten(
            1.600000023841858F,
            1.0F,
            0.0F,
            0.0F
         );
      var10003 = 1;
      var10004 = 0.6800000071525574F;
      var10005 = 0.4399999976158142F;
      var10006 = new float[9];
      var10006[0] = -2.25F;
      var10006[1] = 29.5F;
      var10006[2] = -0.949999988079071F;
      var10006[3] = -2.4600000381469727F;
      var10006[4] = 27.899999618530273F;
      var10006[5] = -1.0499999523162842F;
      var10006[6] = -2.450000047683716F;
      var10006[7] = 26.299999237060547F;
      var10006[8] = -1.1200000047683716F;
      var10001[var10003] = SdfShapes.strand(var10004, var10005, var10006)
         .flatten(
            1.600000023841858F,
            1.0F,
            0.0F,
            0.0F
         );
      Sdf3D var13 = SdfShapes.blend(var16, var10001).mirrorX();
      float var17 = 0.25F;
      var10001 = new Sdf3D[2];
      var10001[0] = SdfShapes.subtract(
            SdfShapes.blend(0.30000001192092896F, ((Sdf3D[]) var2.toArray(new Sdf3D[0]))),
            var12
         )
         .paint(var1);
      var10001[1] = var13.paint(var1.occlusion(0.3499999940395355F));
      Sdf3D var14 = SdfShapes.blend(var17, var10001);
      var0.extra("hair", CharacterBone.HEAD)
         .shape(up(var14))
         .detail(1.100000023841858F)
         .flatLight(0.550000011920929F)
         .occlusion(0.2199999988079071F)
         .outline(-6864801, 0.09000000357627869F)
         .decal(shine());
      var10000 = new float[24];
      var10000[0] = -1.9500000476837158F;
      var10000[1] = 30.399999618530273F;
      var10000[2] = 0.9200000166893005F;
      var10000[3] = 0.550000011920929F;
      var10000[4] = -2.299999952316284F;
      var10000[5] = 29.299999237060547F;
      var10000[6] = 1.1200000047683716F;
      var10000[7] = 0.6000000238418579F;
      var10000[8] = -2.4200000762939453F;
      var10000[9] = 27.799999237060547F;
      var10000[10] = 1.0F;
      var10000[11] = 0.550000011920929F;
      var10000[12] = -2.4100000858306885F;
      var10000[13] = 25.899999618530273F;
      var10000[14] = 0.7200000286102295F;
      var10000[15] = 0.30000001192092896F;
      var10000[16] = -2.299999952316284F;
      var10000[17] = 25.100000381469727F;
      var10000[18] = 0.7400000095367432F;
      var10000[19] = 0.36000001430511475F;
      var10000[20] = -2.119999885559082F;
      var10000[21] = 24.700000762939453F;
      var10000[22] = 0.7799999713897705F;
      var10000[23] = 0.3199999928474426F;
      TaperedTubeSdf3D var15 = SdfShapes.tube(var10000)
         .flatten(
            1.7999999523162842F,
            1.0F,
            0.0F,
            0.30000001192092896F
         );
      var10000 = new float[24];
      var10000[0] = -2.200000047683716F;
      var10000[1] = 30.200000762939453F;
      var10000[2] = 0.10000000149011612F;
      var10000[3] = 0.5799999833106995F;
      var10000[4] = -2.5199999809265137F;
      var10000[5] = 28.899999618530273F;
      var10000[6] = 0.23999999463558197F;
      var10000[7] = 0.6200000047683716F;
      var10000[8] = -2.5799999237060547F;
      var10000[9] = 27.299999237060547F;
      var10000[10] = 0.3199999928474426F;
      var10000[11] = 0.550000011920929F;
      var10000[12] = -2.4100000858306885F;
      var10000[13] = 25.899999618530273F;
      var10000[14] = 0.5600000023841858F;
      var10000[15] = 0.30000001192092896F;
      var10000[16] = -2.2799999713897705F;
      var10000[17] = 25.0F;
      var10000[18] = 0.5400000214576721F;
      var10000[19] = 0.36000001430511475F;
      var10000[20] = -2.200000047683716F;
      var10000[21] = 24.350000381469727F;
      var10000[22] = 0.5600000023841858F;
      var10000[23] = 0.3199999928474426F;
      TaperedTubeSdf3D var7 = SdfShapes.tube(var10000)
         .flatten(
            1.7999999523162842F,
            1.0F,
            0.0F,
            0.15000000596046448F
         );
      Sdf3D var8 = SdfShapes.cylinder(
            -2.4100000858306885F,
            25.3799991607666F,
            0.6399999856948853F,
            -2.4100000858306885F,
            25.940000534057617F,
            0.6399999856948853F,
            0.5F,
            0.11999999731779099F
         )
         .color(-263689);
      Sdf3D[] var20 = new Sdf3D[2];
      int var10002 = 0;
      float var23 = 0.25F;
      Sdf3D[] var25 = new Sdf3D[2];
      var25[0] = var15;
      var25[1] = var7;
      var20[var10002] = SdfShapes.blend(var23, var25).paint(var1);
      var20[1] = var8;
      Sdf3D var9 = SdfShapes.union(var20);
      BoneMotionProfile var10 = new BoneMotionProfile()
         .idle(
            1.5F,
            0.0F,
            0.6000000238418579F,
            0.3499999940395355F
         )
         .walk(
            3.0F,
            0.0F,
            1.0F,
            2.0F
         )
         .drag(8.0F)
         .hang(0.6000000238418579F)
         .spring(60.0F, 8.0F)
         .bend(1.399999976158142F);
      CharacterPartBuilder var11 = var0.extra(
            "sidelock_r", CharacterBone.HEAD
         )
         .pivot(
            tx(-2.299999952316284F),
            ty(30.0F),
            tz(0.6000000238418579F)
         )
         .shape(up(var9))
         .motion(var10)
         .resolution(0.699999988079071F)
         .detail(0.6000000238418579F)
         .flatLight(0.5F)
         .occlusion(0.3499999940395355F)
         .outline(-6864801, 0.09000000357627869F)
         .decal(tieCord());
      var0.extra("sidelock_l", CharacterBone.HEAD).mirrorOf(var11);
      backHair(var0, var1);
   }

   private static SurfaceDecal tieCord() {
      PixelCanvas var0 = new PixelCanvas(40, 20);
      var0.fill(
         Sdf2D.box(
            20.0F,
            10.0F,
            20.0F,
            2.799999952316284F,
            0.0F
         ),
         -1816774
      );
      var0.fill(
         Sdf2D.ellipse(
            20.0F,
            10.0F,
            4.0F,
            5.0F
         ),
         -1816774
      );
      return SurfaceDecal.wrap(
            var0,
            tx(-2.4100000858306885F),
            ty(25.670000076293945F),
            tz(0.6299999952316284F),
            0.0F,
            1.0F,
            0.0F,
            -1.0F,
            0.0F,
            0.44999998807907104F,
            220.0F,
            0.5600000023841858F
         )
         .radius(0.20000000298023224F, 0.8999999761581421F);
   }

   private static void backHair(CharacterRig var0, SurfacePaint var1) {
      ArrayList var2 = new ArrayList();
      ArrayList var3 = new ArrayList();

      for (int var4 = 0; var4 < (7); var4++) {
         float var5 = ((float)var4 - 3.0F) / 3.0F;
         float var6 = 180.0F - var5 * 72.0F;
         float var7 = var4 % (2) == 0 ? 0.10000000149011612F : 0.0F;
         float[] var8 = onHead(26.0F, var6, -0.019999999552965164F);
         float[] var9 = onHead(60.0F, var6, 0.2199999988079071F + var7);
         float[] var10 = onHead(88.0F, var6, 0.3400000035762787F + var7);
         float[] var11 = onHead(114.0F, var6, 0.20000000298023224F + var7);
         float var10001 = 0.7799999713897705F;
         float var10002 = 0.7200000286102295F;
         float[] var10003 = new float[12];
         var10003[0] = var8[0];
         var10003[1] = var8[1];
         var10003[2] = var8[2];
         var10003[3] = var9[0];
         var10003[4] = var9[1];
         var10003[5] = var9[2];
         var10003[6] = var10[0];
         var10003[7] = var10[1];
         var10003[8] = var10[2];
         var10003[9] = var11[0];
         var10003[10] = var11[1];
         var10003[11] = var11[2];
         var2.add(
            SdfShapes.strand(var10001, var10002, var10003)
               .flattenFrom(
                  2.4000000953674316F,
                  0.0F,
                  28.899999618530273F,
                  -0.30000001192092896F
               )
         );
         float[] var12 = onHead(104.0F, var6, 0.3199999928474426F);
         var10001 = 0.800000011920929F;
         var10002 = 0.6399999856948853F;
         var10003 = new float[9];
         var10003[0] = var12[0];
         var10003[1] = var12[1];
         var10003[2] = var12[2];
         var10003[3] = var5 * 2.8499999046325684F;
         var10003[4] = 25.0F;
         var10003[5] = -2.5199999809265137F
            - 0.30000001192092896F * (1.0F - var5 * var5);
         var10003[6] = var5 * 1.0199999809265137F;
         var10003[7] = 21.899999618530273F;
         var10003[8] = -2.799999952316284F;
         var3.add(
            SdfShapes.strand(var10001, var10002, var10003)
               .flatten(
                  2.0F,
                  0.0F,
                  0.0F,
                  1.0F
               )
         );
      }

      ArrayList var13 = new ArrayList();
      float[] var10000 = new float[5];
      var10000[0] = 14.100000381469727F;
      var10000[1] = 13.720000267028809F;
      var10000[2] = 13.579999923706055F;
      var10000[3] = 13.779999732971191F;
      var10000[4] = 14.15999984741211F;
      float[] var14 = var10000;

      for (int var15 = 0; var15 < (5); var15++) {
         float var17 = ((float)var15 - 2.0F) / 2.0F;
         float var29 = 0.800000011920929F;
         float var33 = 0.14000000059604645F;
         float[] var36 = new float[12];
         var36[0] = var17 * 0.7200000286102295F;
         var36[1] = 22.299999237060547F;
         var36[2] = -2.8499999046325684F;
         var36[3] = var17 * 1.0199999809265137F;
         var36[4] = 18.899999618530273F;
         var36[5] = -3.0799999237060547F;
         var36[6] = var17 * 0.8399999737739563F;
         var36[7] = 16.0F;
         var36[8] = -3.25F;
         var36[9] = var17 * 0.20000000298023224F;
         var36[10] = var14[var15];
         var36[11] = -3.319999933242798F;
         var13.add(
            SdfShapes.strand(var29, var33, var36)
               .flatten(
                  1.600000023841858F,
                  0.0F,
                  0.0F,
                  1.0F
               )
         );
      }

      Sdf3D[] var24 = new Sdf3D[3];
      var24[0] = SdfShapes.blend(
         0.10000000149011612F, ((Sdf3D[]) var2.toArray(new Sdf3D[0]))
      );
      var24[1] = SdfShapes.blend(
         0.20000000298023224F, ((Sdf3D[]) var3.toArray(new Sdf3D[0]))
      );
      var24[2] = SdfShapes.blend(
         0.15000000596046448F, ((Sdf3D[]) var13.toArray(new Sdf3D[0]))
      );
      Sdf3D var16 = SdfShapes.union(var24).paint(var1);
      Sdf3D var18 = SdfShapes.box(
            0.0F,
            21.899999618530273F,
            -2.819999933242798F,
            1.4199999570846558F,
            0.44999998807907104F,
            0.6200000047683716F,
            0.3199999928474426F
         )
         .color(-263689);
      Sdf3D var19 = SdfShapes.box(
            0.0F,
            21.899999618530273F,
            -2.819999933242798F,
            1.5F,
            0.20000000298023224F,
            0.699999988079071F,
            0.17000000178813934F
         )
         .color(-1816774);
      Sdf3D var20 = SdfShapes.ellipsoid(
            -1.399999976158142F,
            22.200000762939453F,
            -3.5F,
            1.2000000476837158F,
            0.6600000262260437F,
            0.3799999952316284F
         )
         .paint(
            SurfacePaint.radial(
               -2305053,
               -0.30000001192092896F,
               22.0F,
               -3.5999999046325684F,
               1.600000023841858F,
               -263689
            )
         )
         .rotate(
            0.0F,
            0.0F,
            -16.0F,
            -1.399999976158142F,
            22.200000762939453F,
            -3.5F
         );
      Sdf3D var21 = SdfShapes.ellipsoid(
            0.0F,
            22.0F,
            -3.5799999237060547F,
            0.47999998927116394F,
            0.5199999809265137F,
            0.36000001430511475F
         )
         .color(-1816774);
      float var25 = 0.4399999976158142F;
      float var30 = 0.3799999952316284F;
      float[] var34 = new float[9];
      var34[0] = -0.30000001192092896F;
      var34[1] = 21.600000381469727F;
      var34[2] = -3.5F;
      var34[3] = -0.800000011920929F;
      var34[4] = 20.5F;
      var34[5] = -3.450000047683716F;
      var34[6] = -1.2000000476837158F;
      var34[7] = 19.399999618530273F;
      var34[8] = -3.4000000953674316F;
      Sdf3D var22 = SdfShapes.strand(var25, var30, var34)
         .flatten(
            2.200000047683716F,
            0.0F,
            0.0F,
            1.0F
         )
         .color(-263689);
      Sdf3D[] var26 = new Sdf3D[7];
      var26[0] = var18;
      var26[1] = var19;
      var26[2] = var20;
      var26[3] = var20.mirrored();
      var26[4] = var21;
      var26[5] = var22;
      var26[6] = var22.mirrored();
      Sdf3D var23 = SdfShapes.union(var26);
      CharacterPartBuilder var27 = var0.extra(
            "hair_back", CharacterBone.HEAD
         )
         .pivot(
            0.0F,
            ty(29.0F),
            tz(-1.600000023841858F)
         );
      Sdf3D[] var31 = new Sdf3D[2];
      var31[0] = var16;
      var31[1] = var23;
      var27.shape(up(SdfShapes.union(var31)))
         .motion(
            BoneMotionProfile.hair()
               .hang(0.0F)
               .follow(CharacterBone.BODY, 0.8500000238418579F)
               .drag(12.0F)
         )
         .detail(0.5799999833106995F)
         .flatLight(0.5F)
         .occlusion(0.3499999940395355F)
         .outline(-6864801, 0.09000000357627869F)
         .decal(tailLines());
   }

   private static SurfaceDecal tailLines() {
      PixelCanvas var0 = new PixelCanvas(48, 108);
      float var1 = 12.0F;
      float var2 = 22.0F;
      int var3 = 1890076012;

      for (int var4 = 0; var4 < (4); var4++) {
         float var5 = ((float)var4 - 1.5F) / 2.0F;
         float var6 = var5 * 0.7200000286102295F;
         float var7 = var5 * 1.0199999809265137F;
         float var8 = var5 * 0.8399999737739563F;
         float var9 = var5 * 0.20000000298023224F;
         float var10 = (var7 + var8) * 0.5F;
         float var11 = 14.600000381469727F + Math.abs(var5) * 0.4000000059604645F;
         var0.fill(
            Sdf2D.curve(
               24.0F - var1 * var6,
               (var2 - 21.399999618530273F) * var1,
               24.0F - var1 * var7,
               (var2 - 18.899999618530273F) * var1,
               24.0F - var1 * var10,
               (var2 - 17.450000762939453F) * var1,
               0.4000000059604645F,
               1.5F
            ),
            var3
         );
         var0.fill(
            Sdf2D.curve(
               24.0F - var1 * var10,
               (var2 - 17.450000762939453F) * var1,
               24.0F - var1 * var8,
               (var2 - 16.0F) * var1,
               24.0F - var1 * var9,
               (var2 - var11) * var1,
               1.5F,
               0.30000001192092896F
            ),
            var3
         );
      }

      return SurfaceDecal.back(
            var0,
            0.0F,
            ty(var2 - 54.0F / var1),
            tz(-3.4000000953674316F),
            4.480000019073486F,
            10.079999923706055F
         )
         .depth(0.8999999761581421F, 1.0F)
         .maxAngle(70.0F);
   }

   private static void kanzashi(CharacterRig var0) {
      Sdf3D[] var10000 = new Sdf3D[2];
      var10000[0] = blossom(1.600000023841858F)
         .rotate(-22.0F, 42.0F, 0.0F)
         .move(2.0799999237060547F, 30.899999618530273F, 1.1799999475479126F);
      var10000[1] = blossom(0.949999988079071F)
         .rotate(
            -12.0F, 70.0F, 0.0F
         )
         .move(2.6600000858306885F, 30.020000457763672F, 0.11999999731779099F);
      Sdf3D var1 = SdfShapes.union(var10000);
      var0.extra("kanzashi", CharacterBone.HEAD)
         .shape(up(var1))
         .resolution(0.41999998688697815F)
         .detail(0.5F)
         .flatLight(0.4000000059604645F)
         .outline(-6669732, 0.07999999821186066F);
      ArrayList var2 = new ArrayList();
      float[][] var12 = new float[2][];
      int var10002 = 0;
      float[] var10003 = new float[4];
      var10003[0] = 2.859999895095825F;
      var10003[1] = 29.84000015258789F;
      var10003[2] = 1.059999942779541F;
      var10003[3] = 2.0F;
      var12[var10002] = var10003;
      var10002 = 1;
      var10003 = new float[4];
      var10003[0] = 3.200000047683716F;
      var10003[1] = 29.739999771118164F;
      var10003[2] = 0.5199999809265137F;
      var10003[3] = 3.0F;
      var12[var10002] = var10003;
      float[][] var3 = var12;

      for (int var4 = 0; var4 < var3.length; var4++) {
         float var5 = var3[var4][0];
         float var6 = var3[var4][1];
         float var7 = var3[var4][2];
         int var8 = (int)var3[var4][3];
         float var9 = var6 - 0.550000011920929F * (float)var8;
         var2.add(
            SdfShapes.capsule(
                  var5,
                  var6 + 0.05000000074505806F,
                  var7,
                  var5 + 0.029999999329447746F,
                  var9,
                  var7 + 0.019999999552965164F,
                  0.07000000029802322F
               )
               .color(-1459895)
         );

         for (int var10 = 0; var10 < var8; var10++) {
            float var11 = var10 == var8 - (1) ? 0.23000000417232513F : 0.17000000178813934F;
            var2.add(
               SdfShapes.sphere(
                     var5 + 0.009999999776482582F * (float)var10,
                     var6 - 0.550000011920929F * (float)(var10 + (1)),
                     var7,
                     var11
                  )
                  .color((var10 + var4) % (2) == 0 ? -2608577 : -1459895)
            );
         }
      }

      var0.extra("bira", CharacterBone.HEAD)
         .pivot(
            tx(3.0799999237060547F),
            ty(29.860000610351562F),
            tz(0.800000011920929F)
         )
         .shape(up(SdfShapes.union(((Sdf3D[]) var2.toArray(new Sdf3D[0])))))
         .motion(
            BoneMotionProfile.hair()
               .hang(1.0F)
               .spring(60.0F, 6.0F)
         )
         .resolution(0.4000000059604645F)
         .detail(1.5F)
         .flatLight(0.5F)
         .outline(-8767416, 0.05000000074505806F);
   }

   private static Sdf3D blossom(float var0) {
      ArrayList var1 = new ArrayList();

      for (int var2 = 0; var2 < (5); var2++) {
         float var3 = 90.0F + 72.0F * (float)var2;
         double var4 = Math.toRadians((double)var3);
         float var6 = (float)Math.cos(var4);
         float var7 = (float)Math.sin(var4);
         float var8 = var6 * 0.4699999988079071F * var0;
         float var9 = var7 * 0.4699999988079071F * var0;
         Sdf3D var10 = SdfShapes.ellipsoid(
               var8,
               var9,
               0.0F,
               0.30000001192092896F * var0,
               0.4399999976158142F * var0,
               0.20000000298023224F
            )
            .rotate(
               0.0F,
               0.0F,
               var3 - 90.0F,
               var8,
               var9,
               0.0F
            );
         var1.add(
            SdfShapes.subtract(
               var10,
               SdfShapes.sphere(
                  var6 * 0.9300000071525574F * var0,
                  var7 * 0.9300000071525574F * var0,
                  0.0F,
                  0.11999999731779099F * var0
               )
            )
         );
      }

      Sdf3D var11 = SdfShapes.union(((Sdf3D[]) var1.toArray(new Sdf3D[0])))
         .paint(
            SurfacePaint.radial(
               -2078596,
               0.0F,
               0.0F,
               0.10000000149011612F,
               0.4000000059604645F * var0,
               -8984
            )
         );
      Sdf3D[] var10000 = new Sdf3D[2];
      var10000[0] = var11;
      var10000[1] = SdfShapes.sphere(
            0.0F,
            0.0F,
            0.1599999964237213F,
            0.15000000596046448F * var0
         )
         .color(-1459895);
      return SdfShapes.union(var10000);
   }

   private static Sdf3D capLock(float var0, float var1, float var2, float var3, float var4) {
      float[] var5 = new float[15];

      for (int var6 = 0; var6 < (5); var6++) {
         float[] var7 = onHead(
            var1 + (var2 - var1) * (float)var6 / 4.0F, var0, 0.019999999552965164F
         );
         System.arraycopy(var7, 0, var5, var6 * (3), 3);
      }

      return SdfShapes.strand(var3, var4, var5)
         .flattenFrom(
            2.799999952316284F,
            0.0F,
            28.899999618530273F,
            -0.30000001192092896F
         );
   }

   private static float[] onHead(float var0, float var1, float var2) {
      double var3 = Math.toRadians((double)var0);
      double var5 = Math.toRadians((double)var1);
      float var7 = (float)Math.cos(var3);
      float var8 = (float)Math.sin(var3);
      float var9 = (float)Math.cos(var5);
      float var10 = (float)Math.sin(var5);
      float var11 = var10 * var8;
      float var12 = 0.9700000286102295F * var7 + 0.23999999463558197F * var9 * var8;
      float var13 = -0.23999999463558197F * var7 + 0.9700000286102295F * var9 * var8;
      float var14 = 1.0F
            / (float)Math.sqrt(
               (double)(
                  var11 * var11 / 7.39840030670166F
                     + var12 * var12 / 7.39840030670166F
                     + var13 * var13 / 8.06559944152832F
               )
            )
         + var2;
      float[] var10000 = new float[3];
      var10000[0] = 0.0F + var11 * var14;
      var10000[1] = 28.899999618530273F + var12 * var14;
      var10000[2] = -0.30000001192092896F + var13 * var14;
      return var10000;
   }

   private static SurfacePaint hairPaint() {
      return SurfacePaint.field(
         (var0, var1, var2) -> {
            float var3 = var1 - 31.200000762939453F;
            float var4 = var2 + 0.699999988079071F;
            float var5 = (float)Math.sqrt((double)(var0 * var0 + var3 * var3 + var4 * var4));
            int var6 = ArgbColors.mix(
               -2592100,
               -677434,
               smooth(0.800000011920929F, 2.9000000953674316F, var5)
            );
            return ArgbColors.mix(
               var6,
               -12321,
               smooth(5.5F, 17.5F, var5)
                  * 0.8999999761581421F
            );
         }
      );
   }

   private static void body(CharacterRig var0) {
      Sdf3D[] var10000 = new Sdf3D[2];
      var10000[0] = SdfShapes.capsule(
         0.0F,
         23.950000762939453F,
         -0.15000000596046448F,
         -2.549999952316284F,
         23.299999237060547F,
         -0.15000000596046448F,
         0.949999988079071F
      );
      var10000[1] = SdfShapes.capsule(
         0.0F,
         23.950000762939453F,
         -0.15000000596046448F,
         2.549999952316284F,
         23.299999237060547F,
         -0.15000000596046448F,
         0.949999988079071F
      );
      Sdf3D var1 = SdfShapes.union(var10000);
      Sdf3D var2 = SdfShapes.ellipsoid(
         0.0F,
         21.700000762939453F,
         0.05000000074505806F,
         2.549999952316284F,
         2.0999999046325684F,
         1.7000000476837158F
      );
      Sdf3D var3 = SdfShapes.ellipsoid(
            0.8600000143051147F,
            21.600000381469727F,
            0.6000000238418579F,
            0.9200000166893005F,
            0.8199999928474426F,
            0.9800000190734863F
         )
         .mirrorX();
      Sdf3D var4 = SdfShapes.ellipsoid(
         0.0F,
         19.600000381469727F,
         0.0F,
         2.1500000953674316F,
         1.7000000476837158F,
         1.5F
      );
      Sdf3D var5 = SdfShapes.ellipsoid(
         0.0F,
         17.799999237060547F,
         0.0F,
         2.200000047683716F,
         1.600000023841858F,
         1.5499999523162842F
      );
      float var15 = 1.0F;
      Sdf3D[] var10001 = new Sdf3D[4];
      var10001[0] = var1;
      int var10003 = 1;
      float var10004 = 0.800000011920929F;
      Sdf3D[] var10005 = new Sdf3D[2];
      var10005[0] = var2;
      var10005[1] = var3;
      var10001[var10003] = SdfShapes.blend(var10004, var10005);
      var10001[2] = var4;
      var10001[3] = var5;
      Sdf3D var6 = SdfShapes.blend(var15, var10001)
         .intersect(SdfShapes.above(17.200000762939453F));
      float var16 = 0.41999998688697815F;
      float var22 = 0.4000000059604645F;
      float[] var10002 = new float[15];
      var10002[0] = 0.0F;
      var10002[1] = 24.75F;
      var10002[2] = -1.100000023841858F;
      var10002[3] = -0.949999988079071F;
      var10002[4] = 24.6200008392334F;
      var10002[5] = -0.7200000286102295F;
      var10002[6] = -1.2200000286102295F;
      var10002[7] = 24.299999237060547F;
      var10002[8] = 0.3499999940395355F;
      var10002[9] = -0.75F;
      var10002[10] = 23.350000381469727F;
      var10002[11] = 1.4500000476837158F;
      var10002[12] = 0.11999999731779099F;
      var10002[13] = 22.450000762939453F;
      var10002[14] = 1.9199999570846558F;
      TaperedTubeSdf3D var7 = SdfShapes.strand(var16, var22, var10002)
         .flattenFrom(
            2.200000047683716F,
            0.0F,
            22.5F,
            -1.2000000476837158F
         );
      float var17 = 0.41999998688697815F;
      float var23 = 0.4000000059604645F;
      var10002 = new float[18];
      var10002[0] = 0.0F;
      var10002[1] = 24.75F;
      var10002[2] = -1.100000023841858F;
      var10002[3] = 0.949999988079071F;
      var10002[4] = 24.6200008392334F;
      var10002[5] = -0.7200000286102295F;
      var10002[6] = 1.2200000286102295F;
      var10002[7] = 24.299999237060547F;
      var10002[8] = 0.3499999940395355F;
      var10002[9] = 0.75F;
      var10002[10] = 23.350000381469727F;
      var10002[11] = 1.5F;
      var10002[12] = -0.30000001192092896F;
      var10002[13] = 22.149999618530273F;
      var10002[14] = 2.0199999809265137F;
      var10002[15] = -1.350000023841858F;
      var10002[16] = 20.600000381469727F;
      var10002[17] = 1.8799999952316284F;
      TaperedTubeSdf3D var8 = SdfShapes.strand(var17, var23, var10002)
         .flattenFrom(
            2.200000047683716F,
            0.0F,
            22.5F,
            -1.2000000476837158F
         );
      SurfacePaint var9 = SurfacePaint.field(
         (var0x, var1x, var2x) -> {
            float var3x = smooth(0.5F, 1.2999999523162842F, var2x)
               * smooth(19.899999618530273F, 20.5F, var1x)
               * (
                  1.0F
                     - smooth(20.600000381469727F, 21.100000381469727F, var1x)
               );
            return ArgbColors.mix(-263689, -2305053, var3x * 0.550000011920929F);
         }
      );
      CharacterPartBuilder var18 = var0.part(CharacterBone.BODY);
      float var24 = 0.14000000059604645F;
      Sdf3D[] var28 = new Sdf3D[3];
      var28[0] = var6;
      var28[1] = var7;
      var28[2] = var8;
      var18.shape(SdfShapes.blend(var24, var28).paint(var9))
         .outline(-7568744, 0.10000000149011612F)
         .detail(0.8500000238418579F)
         .occlusion(0.20000000298023224F)
         .decal(collar());
      Sdf3D var10 = SdfShapes.subtract(
         SdfShapes.ellipsoid(
               0.0F,
               19.200000762939453F,
               0.0F,
               2.819999933242798F,
               2.5999999046325684F,
               2.319999933242798F
            )
            .intersect(
               SdfShapes.box(
                  0.0F,
                  19.200000762939453F,
                  0.0F,
                  3.200000047683716F,
                  0.30000001192092896F,
                  2.700000047683716F,
                  0.11999999731779099F
               )
            ),
         SdfShapes.ellipsoid(
            0.0F,
            19.200000762939453F,
            0.0F,
            2.4000000953674316F,
            2.5999999046325684F,
            1.899999976158142F
         )
      );
      Sdf3D var11 = SdfShapes.ellipsoid(
         0.0F,
         19.219999313354492F,
         2.359999895095825F,
         0.36000001430511475F,
         0.36000001430511475F,
         0.23999999463558197F
      );
      Sdf3D var12 = SdfShapes.ellipsoid(
            -1.0F,
            19.399999618530273F,
            2.2799999713897705F,
            1.0F,
            0.4399999976158142F,
            0.20000000298023224F
         )
         .rotate(
            0.0F,
            -8.0F,
            -12.0F,
            -1.0F,
            19.399999618530273F,
            2.2799999713897705F
         );
      float var19 = 0.27000001072883606F;
      float var25 = 0.2199999988079071F;
      var10002 = new float[9];
      var10002[0] = -0.11999999731779099F;
      var10002[1] = 19.0F;
      var10002[2] = 2.380000114440918F;
      var10002[3] = -0.41999998688697815F;
      var10002[4] = 18.100000381469727F;
      var10002[5] = 2.440000057220459F;
      var10002[6] = -0.6399999856948853F;
      var10002[7] = 17.200000762939453F;
      var10002[8] = 2.4800000190734863F;
      TaperedTubeSdf3D var13 = SdfShapes.strand(var19, var25, var10002)
         .flatten(
            2.200000047683716F,
            0.0F,
            0.0F,
            1.0F
         );
      var10000 = new Sdf3D[5];
      var10000[0] = var11;
      var10000[1] = var12;
      var10000[2] = var12.mirrored();
      var10000[3] = var13;
      var10000[4] = var13.mirrored();
      Sdf3D var14 = SdfShapes.union(var10000);
      CharacterPartBuilder var21 = var0.extra("himo", CharacterBone.BODY);
      var10001 = new Sdf3D[2];
      var10001[0] = var10;
      var10001[1] = var14;
      var21.shape(SdfShapes.union(var10001).color(-263689))
         .resolution(0.6000000238418579F)
         .detail(0.36000001430511475F)
         .outline(-7568744, 0.09000000357627869F);
   }

   private static SurfaceDecal collar() {
      PixelCanvas var0 = new PixelCanvas(92, 78);
      float[] var10000 = new float[2];
      var10000[0] = 0.0F;
      var10000[1] = 25.100000381469727F;
      float[] var1 = uv(var10000);
      var10000 = new float[2];
      var10000[0] = 0.0F;
      var10000[1] = 23.200000762939453F;
      float[] var2 = uv(var10000);
      float[] var10001 = new float[14];
      var10001[0] = -0.949999988079071F;
      var10001[1] = 25.100000381469727F;
      var10001[2] = -0.8399999737739563F;
      var10001[3] = 24.489999771118164F;
      var10001[4] = -0.4099999964237213F;
      var10001[5] = 23.59000015258789F;
      var10001[6] = 0.019999999552965164F;
      var10001[7] = 23.15999984741211F;
      var10001[8] = 0.4000000059604645F;
      var10001[9] = 23.59000015258789F;
      var10001[10] = 0.8399999737739563F;
      var10001[11] = 24.489999771118164F;
      var10001[12] = 0.949999988079071F;
      var10001[13] = 25.100000381469727F;
      Sdf2D var7 = Sdf2D.polygon(uv(var10001));
      float var10002 = 0.0F;
      float var10003 = var1[1];
      float var10004 = 0.0F;
      float var10005 = var2[1];
      int[] var10006 = new int[3];
      var10006[0] = -9016;
      var10006[1] = -9016;
      var10006[2] = -1331558;
      var0.fill(var7, ColorField2D.linear(var10002, var10003, var10004, var10005, var10006));
      float var8 = 6.599999904632568F;
      int var12 = -2674372;
      float[] var14 = new float[8];
      var14[0] = -0.8999999761581421F;
      var14[1] = 25.100000381469727F;
      var14[2] = -0.8399999737739563F;
      var14[3] = 24.489999771118164F;
      var14[4] = -0.4099999964237213F;
      var14[5] = 23.59000015258789F;
      var14[6] = 0.05000000074505806F;
      var14[7] = 23.1200008392334F;
      segments(var0, var8, var12, var14);
      float var9 = 6.599999904632568F;
      int var13 = -2674372;
      float[] var15 = new float[8];
      var15[0] = 0.8999999761581421F;
      var15[1] = 25.100000381469727F;
      var15[2] = 0.8399999737739563F;
      var15[3] = 24.489999771118164F;
      var15[4] = 0.4000000059604645F;
      var15[5] = 23.59000015258789F;
      var15[6] = -0.019999999552965164F;
      var15[7] = 23.100000381469727F;
      segments(var0, var9, var13, var15);
      var10000 = new float[2];
      var10000[0] = 0.019999999552965164F;
      var10000[1] = 23.1200008392334F;
      float[] var3 = uv(var10000);
      var0.fill(
         Sdf2D.circle(var3[0], var3[1], 4.199999809265137F),
         -2674372
      );
      int var4 = 1484418696;
      float var10 = 1.7999999523162842F;
      float[] var16 = new float[8];
      var16[0] = -1.649999976158142F;
      var16[1] = 24.25F;
      var16[2] = -1.600000023841858F;
      var16[3] = 24.110000610351562F;
      var16[4] = -1.1299999952316284F;
      var16[5] = 23.15999984741211F;
      var16[6] = -0.6000000238418579F;
      var16[7] = 22.600000381469727F;
      segments(var0, var10, var4, var16);
      float var11 = 1.7999999523162842F;
      float[] var17 = new float[8];
      var17[0] = 1.649999976158142F;
      var17[1] = 24.25F;
      var17[2] = 1.600000023841858F;
      var17[3] = 24.110000610351562F;
      var17[4] = 1.090000033378601F;
      var17[5] = 23.1200008392334F;
      var17[6] = 0.550000011920929F;
      var17[7] = 22.450000762939453F;
      segments(var0, var11, var4, var17);
      return SurfaceDecal.front(
            var0,
            0.0F,
            23.799999237060547F,
            2.0F,
            3.8333332538604736F,
            3.25F
         )
         .depth(1.600000023841858F, 1.2000000476837158F)
         .maxAngle(86.0F)
         .flatLight(0.8999999761581421F)
         .occlusion(0.4000000059604645F);
   }

   private static float[] uv(float... var0) {
      float[] var1 = new float[var0.length];

      for (int var2 = 0; var2 < var0.length; var2 += 2) {
         var1[var2] = (var0[var2] + 1.9166666269302368F) * 24.0F;
         var1[var2 + (1)] = (25.424999237060547F - var0[var2 + (1)])
            * 24.0F;
      }

      return var1;
   }

   private static void segments(PixelCanvas var0, float var1, int var2, float... var3) {
      float[] var4 = uv(var3);

      for (int var5 = 0; var5 + (3) < var4.length; var5 += 2) {
         var0.fill(
            Sdf2D.line(
               var4[var5], var4[var5 + (1)], var4[var5 + (2)], var4[var5 + (3)], var1
            ),
            var2
         );
      }
   }

   private static void hakama(CharacterRig var0) {
      float[] var10000 = new float[6];
      var10000[0] = -0.30000001192092896F;
      var10000[1] = 20.399999618530273F;
      var10000[2] = 0.30000001192092896F;
      var10000[3] = 20.399999618530273F;
      var10000[4] = 0.0F;
      var10000[5] = 16.299999237060547F;
      Sdf3D var1 = SdfShapes.extrude(
            Sdf2D.polygon(var10000), 0.699999988079071F, 0.03999999910593033F
         )
         .rotate(
            0.0F, 90.0F, 0.0F
         )
         .move(-2.950000047683716F, 0.0F, 0.0F)
         .color(-263689);
      Sdf3D var2 = SdfShapes.subtract(
         SdfShapes.field(
               SakuraDesign::hakamaField,
               -5.099999904632568F,
               2.25F,
               -3.9000000953674316F,
               2.0999999046325684F,
               20.25F,
               3.9000000953674316F
            )
            .paint(SurfacePaint.field(SakuraDesign::hakamaColor)),
         var1
      );
      BoneMotionProfile var3 = new BoneMotionProfile()
         .follow(CharacterBone.RIGHT_LEG, 0.6200000047683716F, 13.0F)
         .drag(3.0F)
         .hang(0.5F)
         .spring(80.0F, 11.0F)
         .bend(1.600000023841858F)
         .limit(24.0F);
      CharacterPartBuilder var4 = var0.extra("hakama_r", CharacterBone.BODY)
         .pivot(-1.0F, 19.600000381469727F, 0.0F)
         .shape(var2)
         .motion(var3)
         .resolution(1.100000023841858F)
         .detail(0.41999998688697815F)
         .flatLight(0.3499999940395355F)
         .occlusion(0.20000000298023224F)
         .outline(-8514270, 0.11999999731779099F);
      var4.decal(pleatLine(PLEATS[0]))
         .decal(pleatLine(PLEATS[1]));
      var0.extra("hakama_l", CharacterBone.BODY).mirrorOf(var4);
   }

   private static SurfaceDecal pleatLine(float var0) {
      PixelCanvas var1 = new PixelCanvas(10, 96);
      Sdf2D var10001 = Sdf2D.taper(
         5.0F,
         1.0F,
         1.2000000476837158F,
         5.0F,
         95.0F,
         6.0F
      );
      float var10002 = 0.0F;
      float var10003 = 0.0F;
      float var10004 = 0.0F;
      float var10005 = 40.0F;
      int[] var10006 = new int[2];
      var10006[0] = 8262946;
      var10006[1] = -1719790302;
      var1.fill(var10001, ColorField2D.linear(var10002, var10003, var10004, var10005, var10006));
      float var2 = (float)Math.sin((double)var0);
      float var3 = (float)Math.cos((double)var0);
      return SurfaceDecal.wrap(
         var1,
         -1.1399999856948853F,
         8.0F,
         0.0F,
         1.149999976158142F,
         17.5F,
         0.0F,
         -var2,
         0.0F,
         var3,
         3.5999999046325684F,
         11.0F
      );
   }

   private static float hakamaField(float var0, float var1, float var2) {
      float var3 = clamp01((20.0F - var1) / 17.5F);
      float var4 = (float)Math.pow((double)var3, 0.8);
      float var5 = -(0.3499999940395355F + 1.149999976158142F * var3);
      float var6 = 2.049999952316284F + 1.149999976158142F * var4;
      float var7 = 1.899999976158142F + 1.5F * var4;
      float var8 = var0 - var5;
      float var9 = ellipse(var8, var2, var6, var7);
      float var10 = (float)Math.atan2((double)(-var8), (double)var2);
      float var11 = 0.05000000074505806F + 0.17000000178813934F * var3;
      float[] var12 = PLEATS;
      int var13 = var12.length;

      for (int var14 = 0; var14 < var13; var14++) {
         float var15 = var12[var14];
         var9 -= var11 * pleat(var10 - var15);
      }

      float var16 = Math.max(var1 - 20.0F, 2.5F - var1);
      return smax(var9, var16, 0.20000000298023224F) * 0.8999999761581421F;
   }

   private static int hakamaColor(float var0, float var1, float var2) {
      float var3 = clamp01((20.0F - var1) / 17.5F);
      float var4 = (float)Math.pow((double)var3, 0.8);
      float var5 = var0 + 0.3499999940395355F + 1.149999976158142F * var3;
      if (var1 < 2.799999952316284F
         && ellipse(
               var5,
               var2,
               2.049999952316284F + 1.149999976158142F * var4,
               1.899999976158142F + 1.5F * var4
            )
            < -0.20000000298023224F) {
         return -10087904;
      } else {
         float var6 = (float)Math.atan2((double)(-var5), (double)var2);
         float var7 = 0.0F;
         float[] var8 = PLEATS;
         int var9 = var8.length;

         for (int var10 = 0; var10 < var9; var10++) {
            float var11 = var8[var10];
            float var12 = var6 - var11;
            if (var12 >= 0.0F && var12 < 0.1599999964237213F) {
               var7 = Math.max(
                  var7,
                  1.0F
                     - smooth(0.019999999552965164F, 0.1599999964237213F, var12)
               );
            }
         }

         int var13 = ArgbColors.mix(
            -2674372,
            -5955793,
            smooth(9.0F, 2.5F, var1)
               * 0.44999998807907104F
         );
         return ArgbColors.mix(
            var13,
            -5955793,
            var7
               * 0.3499999940395355F
               * smooth(0.019999999552965164F, 0.20000000298023224F, var3)
         );
      }
   }

   private static float pleat(float var0) {
      if (!(var0 < -0.4000000059604645F) && !(var0 > 0.07000000029802322F)) {
         return var0 < 0.0F
            ? smooth(-0.4000000059604645F, 0.0F, var0)
            : 1.0F
               - smooth(0.0F, 0.07000000029802322F, var0);
      } else {
         return 0.0F;
      }
   }

   private static float ellipse(float var0, float var1, float var2, float var3) {
      float var4 = var0 / var2;
      float var5 = var1 / var3;
      float var6 = (float)Math.sqrt((double)(var4 * var4 + var5 * var5));
      float var7 = var0 / (var2 * var2);
      float var8 = var1 / (var3 * var3);
      float var9 = (float)Math.sqrt((double)(var7 * var7 + var8 * var8));
      return var9 < 9.999999974752427e-07F
         ? -Math.min(var2, var3)
         : var6 * (var6 - 1.0F) / var9;
   }

   private static void arms(CharacterRig var0) {
      float var1 = -3.619999885559082F;
      float var2 = 23.0F;
      float var3 = -0.11999999731779099F;
      float var4 = -4.050000190734863F;
      float var5 = 19.450000762939453F;
      float var6 = -0.30000001192092896F;
      float var7 = -4.28000020980835F;
      float var8 = 15.949999809265137F;
      float var9 = 0.44999998807907104F;
      float var10 = (float)Math.sqrt((double)((var7 - var4) * (var7 - var4) + (var8 - var5) * (var8 - var5) + (var9 - var6) * (var9 - var6)));
      float var11 = (var7 - var4) / var10;
      float var12 = (var8 - var5) / var10;
      float var13 = (var9 - var6) / var10;
      float var10000 = 0.3499999940395355F;
      Sdf3D[] var10001 = new Sdf3D[2];
      var10001[0] = SdfShapes.cone(
         var1, var2, var3, 0.6600000262260437F, var4, var5, var6, 0.5799999833106995F
      );
      var10001[1] = SdfShapes.cone(
         var4, var5, var6, 0.5799999833106995F, var7, var8, var9, 0.6600000262260437F
      );
      Sdf3D var14 = SdfShapes.blend(var10000, var10001);
      Sdf3D var15 = SdfShapes.sphere(
            var7 + 0.30000001192092896F * var11,
            var8 + 0.30000001192092896F * var12,
            var9 + 0.30000001192092896F * var13,
            0.46000000834465027F
         )
         .color(-2502430);
      CharacterPartBuilder var16 = var0.part(CharacterBone.RIGHT_ARM)
         .pivot(-3.5F, 23.25F, -0.10000000149011612F)
         .grip(-4.320000171661377F, 15.050000190734863F, 0.7200000286102295F)
         .shape(SdfShapes.subtract(0.07999999821186066F, var14.color(-263689), var15))
         .resolution(0.699999988079071F)
         .detail(0.699999988079071F)
         .outline(-7568744, 0.10000000149011612F)
         .swing(0.550000011920929F)
         .joint(var4, var5, var6, 0.6000000238418579F);
      var0.part(CharacterBone.LEFT_ARM).mirrorOf(var16);
      Sdf3D var17 = SdfShapes.field(
            (var0x, var1x, var2x) -> {
               float var3x = SLEEVE_SIDE.distance(var2x, var1x);
               float var4x = -4.119999885559082F
                  - 0.08500000089406967F * (23.799999237060547F - var1x);
               float var5x = 0.30000001192092896F
                  + 0.1599999964237213F
                     * clamp01((22.0F - var1x) / 8.0F)
                  + 0.25999999046325684F
                     * smooth(0.0F, 1.2999999523162842F, -var3x)
                  + 0.07000000029802322F
                     * (float)Math.sin((double)(var2x * 2.299999952316284F + 0.6000000238418579F))
                     * smooth(22.0F, 17.0F, var1x);
               return smax(var3x, Math.abs(var0x - var4x) - var5x, 0.2800000011920929F);
            },
            -6.099999904632568F,
            13.199999809265137F,
            -3.9000000953674316F,
            -3.299999952316284F,
            24.700000762939453F,
            1.600000023841858F
         )
         .paint(
            SurfacePaint.vertical(
               -1053966, 13.5F, -263689, 19.0F
            )
         );
      Sdf3D[] var21 = new Sdf3D[2];
      var21[0] = SdfShapes.sphere(
            -5.0F,
            14.140000343322754F,
            -3.4200000762939453F,
            0.23000000417232513F
         )
         .color(-1816774);
      var21[1] = SdfShapes.cone(
            -5.0F,
            13.979999542236328F,
            -3.440000057220459F,
            0.15000000596046448F,
            -5.010000228881836F,
            13.579999923706055F,
            -3.4600000381469727F,
            0.27000001072883606F
         )
         .paint(
            SurfacePaint.vertical(
               -4705748, 13.300000190734863F, -1816774, 13.899999618530273F
            )
         );
      Sdf3D var18 = SdfShapes.union(var21);
      BoneMotionProfile var19 = BoneMotionProfile.cloth()
         .hang(0.699999988079071F)
         .drag(8.0F)
         .spring(40.0F, 5.0F)
         .bend(1.2999999523162842F)
         .limit(35.0F);
      CharacterPartBuilder var22 = var0.extra(
         "sleeve_r", CharacterBone.RIGHT_ARM
      );
      var10001 = new Sdf3D[2];
      var10001[0] = var17;
      var10001[1] = var18;
      CharacterPartBuilder var20 = var22.shape(SdfShapes.union(var10001))
         .motion(var19)
         .resolution(1.0F)
         .detail(0.699999988079071F)
         .outline(-7568744, 0.10000000149011612F)
         .decal(sleeveTrim());
      var0.extra("sleeve_l", CharacterBone.LEFT_ARM).mirrorOf(var20);
      hands(var0, var7, var8, var9);
   }

   private static void hands(CharacterRig var0, float var1, float var2, float var3) {
      float var4 = 4.300000190734863F;
      float var5 = 15.25F;
      float var6 = 0.6399999856948853F;
      ArrayList var7 = new ArrayList();
      var7.add(
         SdfShapes.ellipsoid(
            var4,
            var5,
            var6,
            0.33000001311302185F,
            0.6000000238418579F,
            0.5199999809265137F
         )
      );
      var7.add(
         SdfShapes.capsule(
            var4 - 0.019999999552965164F,
            var5 + 0.44999998807907104F,
            var6 - 0.11999999731779099F,
            -var1,
            var2 + 0.10000000149011612F,
            var3,
            0.3199999928474426F
         )
      );
      float var10001 = 0.15000000596046448F;
      float var10002 = 0.12999999523162842F;
      float[] var10003 = new float[9];
      var10003[0] = var4 + 0.019999999552965164F;
      var10003[1] = var5 - 0.4000000059604645F;
      var10003[2] = var6 + 0.36000001430511475F;
      var10003[3] = var4 - 0.019999999552965164F;
      var10003[4] = var5 - 0.8600000143051147F;
      var10003[5] = var6 + 0.4399999976158142F;
      var10003[6] = var4 - 0.20000000298023224F;
      var10003[7] = var5 - 1.100000023841858F;
      var10003[8] = var6 + 0.4000000059604645F;
      var7.add(SdfShapes.strand(var10001, var10002, var10003));
      var10001 = 0.15000000596046448F;
      var10002 = 0.12999999523162842F;
      var10003 = new float[9];
      var10003[0] = var4 + 0.029999999329447746F;
      var10003[1] = var5 - 0.4399999976158142F;
      var10003[2] = var6 + 0.11999999731779099F;
      var10003[3] = var4;
      var10003[4] = var5 - 0.9800000190734863F;
      var10003[5] = var6 + 0.14000000059604645F;
      var10003[6] = var4 - 0.2199999988079071F;
      var10003[7] = var5 - 1.2599999904632568F;
      var10003[8] = var6 + 0.10999999940395355F;
      var7.add(SdfShapes.strand(var10001, var10002, var10003));
      var10001 = 0.14000000059604645F;
      var10002 = 0.11999999731779099F;
      var10003 = new float[9];
      var10003[0] = var4 + 0.029999999329447746F;
      var10003[1] = var5 - 0.41999998688697815F;
      var10003[2] = var6 - 0.11999999731779099F;
      var10003[3] = var4;
      var10003[4] = var5 - 0.8999999761581421F;
      var10003[5] = var6 - 0.12999999523162842F;
      var10003[6] = var4 - 0.20000000298023224F;
      var10003[7] = var5 - 1.159999966621399F;
      var10003[8] = var6 - 0.14000000059604645F;
      var7.add(SdfShapes.strand(var10001, var10002, var10003));
      var10001 = 0.12999999523162842F;
      var10002 = 0.10999999940395355F;
      var10003 = new float[9];
      var10003[0] = var4 + 0.019999999552965164F;
      var10003[1] = var5 - 0.36000001430511475F;
      var10003[2] = var6 - 0.3400000035762787F;
      var10003[3] = var4;
      var10003[4] = var5 - 0.7400000095367432F;
      var10003[5] = var6 - 0.36000001430511475F;
      var10003[6] = var4 - 0.1599999964237213F;
      var10003[7] = var5 - 0.949999988079071F;
      var10003[8] = var6 - 0.3499999940395355F;
      var7.add(SdfShapes.strand(var10001, var10002, var10003));
      var10001 = 0.17000000178813934F;
      var10002 = 0.14000000059604645F;
      var10003 = new float[9];
      var10003[0] = var4 - 0.18000000715255737F;
      var10003[1] = var5 + 0.10000000149011612F;
      var10003[2] = var6 + 0.41999998688697815F;
      var10003[3] = var4 - 0.30000001192092896F;
      var10003[4] = var5 - 0.30000001192092896F;
      var10003[5] = var6 + 0.5799999833106995F;
      var10003[6] = var4 - 0.3199999928474426F;
      var10003[7] = var5 - 0.5400000214576721F;
      var10003[8] = var6 + 0.5F;
      var7.add(SdfShapes.strand(var10001, var10002, var10003));
      CharacterPartBuilder var8 = var0.extra(
            "hand_l", CharacterBone.LEFT_ARM
         )
         .shape(
            SdfShapes.blend(0.11999999731779099F, ((Sdf3D[]) var7.toArray(new Sdf3D[0])))
               .color(-9016)
         )
         .resolution(0.44999998807907104F)
         .detail(0.3499999940395355F)
         .flatLight(1.0F)
         .occlusion(0.25F)
         .outline(-5740452, 0.10000000149011612F);
      var0.extra("hand_r", CharacterBone.RIGHT_ARM).mirrorOf(var8);
   }

   private static SurfaceDecal sleeveTrim() {
      PixelCanvas var0 = new PixelCanvas(64, 24);
      float var1 = 16.0F;
      float[] var10000 = new float[10];
      var10000[0] = -0.30000001192092896F;
      var10000[1] = 14.75F;
      var10000[2] = -1.2000000476837158F;
      var10000[3] = 14.300000190734863F;
      var10000[4] = -2.25F;
      var10000[5] = 14.050000190734863F;
      var10000[6] = -2.8499999046325684F;
      var10000[7] = 14.25F;
      var10000[8] = -3.119999885559082F;
      var10000[9] = 14.800000190734863F;
      float[] var2 = var10000;

      for (int var3 = 0; var3 + (3) < var2.length; var3 += 2) {
         var0.fill(
            Sdf2D.line(
               (var2[var3] + 3.75F) * var1,
               (15.300000190734863F - var2[var3 + (1)]) * var1,
               (var2[var3 + (2)] + 3.75F) * var1,
               (15.300000190734863F - var2[var3 + (3)]) * var1,
               3.0F
            ),
            -1816774
         );
      }

      return SurfaceDecal.right(
            var0,
            -6.099999904632568F,
            15.300000190734863F - 12.0F / var1,
            -3.75F + 32.0F / var1,
            64.0F / var1,
            24.0F / var1
         )
         .depth(1.2999999523162842F, 1.2000000476837158F)
         .maxAngle(48.0F);
   }

   private static void legs(CharacterRig var0) {
      float var1 = -1.2999999523162842F;
      float var10000 = 0.3499999940395355F;
      Sdf3D[] var10001 = new Sdf3D[5];
      var10001[0] = SdfShapes.sphere(
         var1, 1.6200000047683716F, -0.11999999731779099F, 0.5199999809265137F
      );
      var10001[1] = SdfShapes.ellipsoid(
         var1,
         0.9800000190734863F,
         -0.44999998807907104F,
         0.5600000023841858F,
         0.5400000214576721F,
         0.6200000047683716F
      );
      var10001[2] = SdfShapes.ellipsoid(
         var1,
         0.8399999737739563F,
         0.550000011920929F,
         0.6000000238418579F,
         0.4300000071525574F,
         1.2200000286102295F
      );
      var10001[3] = SdfShapes.ellipsoid(
         var1 + 0.33000001311302185F,
         0.7599999904632568F,
         1.5700000524520874F,
         0.25F,
         0.3100000023841858F,
         0.4300000071525574F
      );
      var10001[4] = SdfShapes.ellipsoid(
         var1 - 0.18000000715255737F,
         0.7300000190734863F,
         1.4700000286102295F,
         0.3700000047683716F,
         0.28999999165534973F,
         0.46000000834465027F
      );
      Sdf3D var2 = SdfShapes.blend(var10000, var10001);
      Sdf3D var3 = SdfShapes.box(
            var1 + 0.10000000149011612F,
            0.800000011920929F,
            1.9700000286102295F,
            0.05000000074505806F,
            0.4000000059604645F,
            0.550000011920929F,
            0.019999999552965164F
         )
         .color(-2305053);
      Sdf3D var4 = SdfShapes.cone(
         var1,
         1.7000000476837158F,
         -0.10000000149011612F,
         0.5F,
         var1 + 0.019999999552965164F,
         3.299999952316284F,
         -0.07999999821186066F,
         0.5400000214576721F
      );
      var10000 = 0.30000001192092896F;
      var10001 = new Sdf3D[2];
      var10001[0] = var2;
      var10001[1] = var4;
      Sdf3D var5 = SdfShapes.subtract(SdfShapes.blend(var10000, var10001).color(-263689), var3);
      Sdf3D var6 = SdfShapes.box(
            var1,
            0.2199999988079071F,
            0.5199999809265137F,
            0.7400000095367432F,
            0.2199999988079071F,
            1.6399999856948853F,
            0.20000000298023224F
         )
         .paint(
            SurfacePaint.field(
               (var0x, var1x, var2x) -> var1x > 0.36000001430511475F ? -1320012 : -10600144
            )
         );
      Sdf3D[] var11 = new Sdf3D[3];
      int var10002 = 0;
      float var10003 = 0.20000000298023224F;
      float var10004 = 0.20000000298023224F;
      float[] var10005 = new float[6];
      var10005[0] = var1 + 0.12999999523162842F;
      var10005[1] = 0.5F;
      var10005[2] = 1.5F;
      var10005[3] = var1 + 0.12999999523162842F;
      var10005[4] = 0.949999988079071F;
      var10005[5] = 1.2999999523162842F;
      var11[var10002] = SdfShapes.strand(var10003, var10004, var10005);
      var10002 = 1;
      var10003 = 0.20000000298023224F;
      var10004 = 0.20000000298023224F;
      var10005 = new float[9];
      var10005[0] = var1 + 0.12999999523162842F;
      var10005[1] = 0.949999988079071F;
      var10005[2] = 1.2999999523162842F;
      var10005[3] = var1 - 0.3499999940395355F;
      var10005[4] = 1.0800000429153442F;
      var10005[5] = 0.8500000238418579F;
      var10005[6] = var1 - 0.6200000047683716F;
      var10005[7] = 0.550000011920929F;
      var10005[8] = 0.3499999940395355F;
      var11[var10002] = SdfShapes.strand(var10003, var10004, var10005);
      var10002 = 2;
      var10003 = 0.20000000298023224F;
      var10004 = 0.20000000298023224F;
      var10005 = new float[9];
      var10005[0] = var1 + 0.12999999523162842F;
      var10005[1] = 0.949999988079071F;
      var10005[2] = 1.2999999523162842F;
      var10005[3] = var1 + 0.3499999940395355F;
      var10005[4] = 1.0800000429153442F;
      var10005[5] = 0.8500000238418579F;
      var10005[6] = var1 + 0.6000000238418579F;
      var10005[7] = 0.550000011920929F;
      var10005[8] = 0.3499999940395355F;
      var11[var10002] = SdfShapes.strand(var10003, var10004, var10005);
      Sdf3D var7 = SdfShapes.union(var11).color(-1816774);
      Sdf3D[] var12 = new Sdf3D[3];
      var12[0] = var5;
      var12[1] = var6;
      var12[2] = var7;
      Sdf3D var8 = SdfShapes.union(var12)
         .rotate(
            0.0F,
            -7.0F,
            0.0F,
            var1,
            0.0F,
            -0.10000000149011612F
         );
      CharacterPartBuilder var9 = var0.part(CharacterBone.RIGHT_LEG)
         .pivot(var1, 14.199999809265137F, 0.0F)
         .shape(var8)
         .resolution(0.6000000238418579F)
         .detail(0.5F)
         .flatLight(0.4000000059604645F)
         .outline(-10860992, 0.10000000149011612F)
         .swing(0.3799999952316284F, 18.0F);
      var0.part(CharacterBone.LEFT_LEG).mirrorOf(var9);
   }

   private static float px(float var0) {
      return 128.0F + var0 * 56.88888931274414F;
   }

   private static float py(float var0) {
      return (29.950000762939453F - var0) * 56.88888931274414F;
   }

   private static SurfaceDecal face(float[][] var0) {
      PixelCanvas var1 = new PixelCanvas(88, 136);
      float var2 = 40.0F;
      float var3 = 70.0F;
      Sdf2D var4 = Sdf2D.ellipse(
         var2, var3, 27.5F, 33.0F
      );
      float var10003 = var3 - 33.0F;
      float var10005 = var3 + 10.0F;
      int[] var10006 = new int[2];
      var10006[0] = -923920;
      var10006[1] = -1;
      var1.fill(var4, ColorField2D.linear(var2, var10003, var2, var10005, var10006));
      var1.fill(
         Sdf2D.ellipse(
               var2,
               var3 - 34.0F,
               34.0F,
               22.0F
            )
            .intersect(var4),
         -1713846054,
         2.0F
      );
      Sdf2D var5 = Sdf2D.ellipse(
         var2,
         var3 + 3.5F,
         20.5F,
         27.5F
      );
      Sdf2D var6 = var5.intersect(var4);
      var10003 = var3 - 24.0F;
      var10005 = var3 + 30.0F;
      var10006 = new int[3];
      var10006[0] = -11923926;
      var10006[1] = -2996102;
      var10006[2] = -19508;
      var1.fill(var6, ColorField2D.linear(var2, var10003, var2, var10005, var10006));
      var1.fill(var5.outline(2.5999999046325684F).intersect(var4), -1337323990);
      var1.fill(
         Sdf2D.ellipse(
            var2,
            var3 + 1.5F,
            9.0F,
            12.5F
         ),
         -14023146
      );
      var1.fill(
         Sdf2D.ellipse(
               var2,
               var3 + 17.0F,
               12.0F,
               6.5F
            )
            .intersect(var6),
         -2130716956,
         3.0F
      );
      var1.fill(
         Sdf2D.curve(
            var2 + 26.5F,
            var3 - 13.0F,
            var2 + 2.0F,
            var3 - 46.0F,
            var2 - 30.0F,
            var3 - 6.0F,
            4.199999809265137F,
            8.399999618530273F
         ),
         -13757408
      );
      var1.fill(
         Sdf2D.taper(
            var2 - 25.0F,
            var3 - 9.0F,
            6.0F,
            var2 - 35.0F,
            var3 - 6.0F,
            1.399999976158142F
         ),
         -13757408
      );
      var1.fill(
         Sdf2D.curve(
            var2 - 5.0F,
            var3 + 32.0F,
            var2 - 20.0F,
            var3 + 31.0F,
            var2 - 26.5F,
            var3 + 16.0F,
            1.600000023841858F,
            2.799999952316284F
         ),
         -864407480
      );
      var1.fill(
         Sdf2D.curve(
            var2 + 15.0F,
            var3 - 38.0F,
            var2,
            var3 - 48.0F,
            var2 - 23.0F,
            var3 - 33.0F,
            1.5F,
            1.5F
         ),
         2009102984
      );
      var1.fill(
         Sdf2D.curve(
            var2 + 20.0F,
            var3 - 48.0F,
            var2 + 2.0F,
            var3 - 57.0F,
            var2 - 22.0F,
            var3 - 51.0F,
            4.0F,
            2.5999999046325684F
         ),
         -4892806
      );
      var1.fill(
         Sdf2D.ellipse(
            var2 - 4.0F,
            var3 + 46.0F,
            21.0F,
            9.0F
         ),
         1728023196,
         10.0F
      );
      PixelCanvas var7 = new PixelCanvas(256, 220);
      int var8 = Math.round(py(28.0F)) - (70);
      ArrayList var9 = new ArrayList();
      float[][] var10 = var0;
      int var11 = var0.length;

      for (int var12 = 0; var12 < var11; var12++) {
         float[] var13 = var10[var12];
         float[] var14 = blade(var13);

         for (int var15 = 0; var15 < var14.length; var15 += 2) {
            var14[var15] = px(var14[var15]);
            var14[var15 + (1)] = py(var14[var15 + (1)])
               + 14.0F;
         }

         var9.add(Sdf2D.polygon(var14));
      }

      var9.add(
         Sdf2D.box(
            128.0F,
            py(29.75F),
            130.0F,
            14.222222328186035F,
            0.0F
         )
      );
      var7.fill(
         Sdf2D.union(((Sdf2D[]) var9.toArray(new Sdf2D[0]))),
         -1930845035,
         3.0F
      );
      var7.draw(var1, 28, var8);
      var7.draw(var1.mirrored(), 140, var8);

      for (int var16 = -1; var16 <= (1); var16 += 2) {
         float var17 = 128.0F + (float)var16 * 60.0F;
         var7.fill(
            Sdf2D.ellipse(
               var17 - 7.5F,
               (float)var8 + 60.0F,
               7.0F,
               8.800000190734863F
            ),
            -1
         );
         var7.fill(
            Sdf2D.circle(
               var17 + 8.0F,
               (float)var8 + 83.0F,
               3.0F
            ),
            -570425345
         );
         var7.fill(
            Sdf2D.circle(
               var17 - 12.0F,
               (float)var8 + 76.0F,
               1.600000023841858F
            ),
            -1426063361
         );
      }

      var7.fill(
         Sdf2D.line(
            130.0F,
            (float)var8 + 119.0F,
            127.0F,
            (float)var8 + 124.5F,
            2.4000000953674316F
         ),
         -1713795968
      );
      var7.fill(
         Sdf2D.curve(
            119.0F,
            (float)var8 + 157.0F,
            128.0F,
            (float)var8 + 163.0F,
            137.0F,
            (float)var8 + 157.0F,
            2.5999999046325684F,
            2.5999999046325684F
         ),
         -4896678
      );
      return SurfaceDecal.front(
            var7,
            0.0F,
            ty(28.016407012939453F),
            tz(2.0999999046325684F),
            5.039999961853027F,
            4.331250190734863F
         )
         .depth(2.0F, 1.7999999523162842F)
         .maxAngle(72.0F)
         .flatLight(1.0F)
         .occlusion(0.30000001192092896F);
   }

   private static float smax(float var0, float var1, float var2) {
      float var3 = clamp01(
         0.5F - 0.5F * (var1 - var0) / var2
      );
      return var1 + (var0 - var1) * var3 + var2 * var3 * (1.0F - var3);
   }

   private static float smooth(float var0, float var1, float var2) {
      float var3 = clamp01((var2 - var0) / (var1 - var0));
      return var3 * var3 * (3.0F - 2.0F * var3);
   }

   private static float clamp01(float var0) {
      return var0 < 0.0F
         ? 0.0F
         : Math.min(var0, 1.0F);
   }



































   static {
      float[] var5;
      (var5 = new float[3])[0] = 0.21F;
      var5[1] = 0.7F;
      var5[2] = 2.76F;
      PLEATS = var5;
      float[][] var7 = new float[9][];
      float[] var49;
      (var49 = new float[6])[0] = -0.08F;
      var49[1] = 28.38F;
      var49[2] = -2.0F;
      var49[3] = 0.95F;
      var49[4] = 0.12F;
      var49[5] = 0.34F;
      var7[0] = var49;
      float[] var51;
      (var51 = new float[6])[0] = -0.98F;
      var51[1] = 28.82F;
      var51[2] = -25.0F;
      var51[3] = 0.95F;
      var51[4] = 0.28F;
      var51[5] = 0.3F;
      var7[1] = var51;
      float[] var53;
      (var53 = new float[6])[0] = -1.92F;
      var53[1] = 28.5F;
      var53[2] = -47.0F;
      var53[3] = 0.92F;
      var53[4] = 0.26F;
      var53[5] = 0.3F;
      var7[2] = var53;
      float[] var55;
      (var55 = new float[6])[0] = 0.92F;
      var55[1] = 28.9F;
      var55[2] = 24.0F;
      var55[3] = 0.95F;
      var55[4] = 0.28F;
      var55[5] = 0.3F;
      var7[3] = var55;
      float[] var7x;
      (var7x = new float[6])[0] = 1.9F;
      var7x[1] = 28.62F;
      var7x[2] = 46.0F;
      var7x[3] = 0.92F;
      var7x[4] = 0.25F;
      var7x[5] = 0.3F;
      var7[4] = var7x;
      float[] var59;
      (var59 = new float[6])[0] = -0.55F;
      var59[1] = 28.58F;
      var59[2] = -13.0F;
      var59[3] = 0.45F;
      var59[4] = 0.16F;
      var59[5] = 0.44F;
      var7[5] = var59;
      float[] var61;
      (var61 = new float[6])[0] = 0.46F;
      var61[1] = 28.7F;
      var61[2] = 11.0F;
      var61[3] = 0.45F;
      var61[4] = 0.18F;
      var61[5] = 0.44F;
      var7[6] = var61;
      float[] var63;
      (var63 = new float[6])[0] = -1.46F;
      var63[1] = 28.72F;
      var63[2] = -36.0F;
      var63[3] = 0.42F;
      var63[4] = 0.2F;
      var63[5] = 0.42F;
      var7[7] = var63;
      float[] var65;
      (var65 = new float[6])[0] = 1.42F;
      var65[1] = 28.8F;
      var65[2] = 35.0F;
      var65[3] = 0.42F;
      var65[4] = 0.2F;
      var65[5] = 0.42F;
      var7[8] = var65;
      LOCKS = var7;
      float[] var9;
      (var9 = new float[22])[0] = 0.85F;
      var9[1] = 23.95F;
      var9[2] = 0.62F;
      var9[3] = 19.0F;
      var9[4] = 0.12F;
      var9[5] = 15.7F;
      var9[6] = -0.2F;
      var9[7] = 14.7F;
      var9[8] = -1.2F;
      var9[9] = 14.25F;
      var9[10] = -2.25F;
      var9[11] = 14.0F;
      var9[12] = -2.9F;
      var9[13] = 14.2F;
      var9[14] = -3.2F;
      var9[15] = 14.8F;
      var9[16] = -3.25F;
      var9[17] = 16.0F;
      var9[18] = -2.2F;
      var9[19] = 22.4F;
      var9[20] = -1.0F;
      var9[21] = 24.2F;
      SLEEVE_SIDE = Sdf2D.polygon(var9).inflate(0.3F);
   }
}
