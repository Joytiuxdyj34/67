package krispy.feature;

import it.unimi.dsi.fastutil.longs.LongOpenHashSet;
import java.awt.Color;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import krispy.event.EventListener;
import krispy.event.events.ChunkDataEvent;
import krispy.event.events.Render3DEvent;
import krispy.event.events.TickEvent;
import krispy.module.Category;
import krispy.module.Module;
import krispy.module.setting.BooleanSetting;
import krispy.module.setting.NumberSetting;
import krispy.module.setting.Setting;
import krispy.utils.BlockUtil;
import krispy.utils.EncryptedString;
import krispy.utils.RenderUtils;
import krispy.utils.RenderVisibility;
import krispy.utils.RenderUtils.ColoredBox;
import krispy.utils.RenderUtils.ColoredLine;
import krispy.utils.chunks.ChunkPlateRenderer;
import krispy.utils.chunks.ChunkRegionBuilder;
import net.minecraft.block.BeehiveBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3i;
import net.minecraft.util.math.BlockPos.Mutable;
import net.minecraft.world.LightType;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.world.chunk.WorldChunk;

public final class SusChunkFinderModule extends Module {
   private static final int MIN_SCAN_Y = -64;
   private static final int MAX_SCAN_Y = 64;
   private static final double PLATE_Y = 63.0;
   private static final double PLATE_THICKNESS = 0.05;
   private static final int MAX_CLUSTER_MARKERS = 400;
   private static final long SCAN_BUDGET_NANOS = 4000000L;
   private static final int SCAN_CHUNKS_PER_TICK = 24;
   private static final int MAX_TICKS_BETWEEN_COMMITS = 60;
   private final NumberSetting sensitivity;
   private final NumberSetting simulationDistance;
   private final NumberSetting alpha;
   private final BooleanSetting markGeodeChunks;
   private final BooleanSetting renderClusters;
   private final Map<Long, SusChunkFinderModule.ChunkCluster> geodes;
   private final Queue<Long> scanQueue;
   private final Set<Long> queued;
   private final Set<Long> scanned;
   private final List<ColoredBox> renderBoxes;
   private final List<ColoredLine> renderLines;
   private Set<Long> cachedCandidates;
   private final LongOpenHashSet candidateKeys;
   private final ChunkPlateRenderer candidatePlates;
   private static final Direction[] DIRECTIONS = Direction.values();
   private boolean candidatesDirty;
   private int cachedSimulationRadius;
   private int cachedSensitivity;
   private Object trackedWorld;
   private int ticks;
   private int ticksSinceCommit;
   private static final int[][] NEIGHBORS;

   public SusChunkFinderModule() {
      super(
         EncryptedString.of("Sus Chunk Finder"),
         EncryptedString.of("Finds suspicious chunks from amethyst and full-beehive generation signals"),
         -1,
         Category.DONUT
      );
      int var10000 = 208259676 % 2047151515;
      EncryptedString var58 = EncryptedString.of("Sensitivity");
      NumberSetting var31 = new NumberSetting(var58, 1.0, 20.0, 12.0, 1.0);
      EncryptedString var54 = EncryptedString.of("Geode light-signature threshold (maximum 20)");
      NumberSetting var32 = var31.getValue(var54);
      this.sensitivity = var32;
      EncryptedString var60 = EncryptedString.of("Simulation Distance");
      NumberSetting var33 = new NumberSetting(var60, 2.0, 16.0, 4.0, 1.0);
      EncryptedString var56 = EncryptedString.of("Chunk radius used to triangulate the possible player origin");
      NumberSetting var34 = var33.getValue(var56);
      this.simulationDistance = var34;
      EncryptedString var62 = EncryptedString.of("Alpha");
      NumberSetting var35 = new NumberSetting(var62, 0.0, 255.0, 140.0, 1.0);
      this.alpha = var35;
      EncryptedString var64 = EncryptedString.of("Mark Geode Chunks");
      BooleanSetting var36 = new BooleanSetting(var64, false);
      this.markGeodeChunks = var36;
      EncryptedString var66 = EncryptedString.of("Render Clusters");
      BooleanSetting var37 = new BooleanSetting(var66, false);
      this.renderClusters = var37;
      HashMap var38 = new HashMap();
      this.geodes = var38;
      ArrayDeque var39 = new ArrayDeque();
      this.scanQueue = var39;
      HashSet var40 = new HashSet();
      this.queued = var40;
      HashSet var41 = new HashSet();
      this.scanned = var41;
      ArrayList var42 = new ArrayList();
      this.renderBoxes = var42;
      ArrayList var43 = new ArrayList();
      this.renderLines = var43;
      Set var44 = Set.of();
      this.cachedCandidates = var44;
      LongOpenHashSet var45 = new LongOpenHashSet();
      this.candidateKeys = var45;
      ChunkPlateRenderer var46 = new ChunkPlateRenderer();
      this.candidatePlates = var46;
      this.candidatesDirty = true;
      this.cachedSimulationRadius = -1;
      this.cachedSensitivity = -1;
      Setting[] var51 = new Setting[5];
      NumberSetting var81 = this.sensitivity;
      var51[0] = var81;
      NumberSetting var83 = this.simulationDistance;
      var51[1] = var83;
      NumberSetting var85 = this.alpha;
      var51[2] = var85;
      BooleanSetting var87 = this.markGeodeChunks;
      var51[3] = var87;
      BooleanSetting var89 = this.renderClusters;
      var51[4] = var89;
      this.addSettings(var51);
   }

   public void onEnable() {
      this.reset();
      this.trackedWorld = this.mc.world;
      this.enqueueLoadedChunks();
      super.onEnable();
   }

   public void onDisable() {
      this.reset();
      super.onDisable();
   }

   private void reset() {
      this.geodes.clear();
      this.scanQueue.clear();
      this.queued.clear();
      this.scanned.clear();
      this.renderBoxes.clear();
      this.renderLines.clear();
      this.cachedCandidates = Set.of();
      this.candidateKeys.clear();
      this.candidatesDirty = true;
      this.cachedSimulationRadius = -1;
      this.cachedSensitivity = -1;
      this.trackedWorld = null;
      this.ticks = 0;
      this.ticksSinceCommit = 0;
   }

   @EventListener
   public void onChunkData(ChunkDataEvent var1) {
      this.enqueue(var1.packet.getChunkX(), var1.packet.getChunkZ());
   }

   @EventListener
   public void onTick(TickEvent var1) {
      if (this.mc.world != null && this.mc.player != null) {
         if (this.trackedWorld != this.mc.world) {
            this.reset();
            this.trackedWorld = this.mc.world;
         }

         this.ticks++;
         this.ticksSinceCommit++;
         int var2;
         if ((var2 = this.sensitivity.getIntValue()) != this.cachedSensitivity) {
            this.cachedSensitivity = var2;
            this.geodes.clear();
            this.scanQueue.clear();
            this.queued.clear();
            this.scanned.clear();
            this.candidatesDirty = true;
            this.enqueueLoadedChunks();
         }

         if (this.ticks % 100 == 1) {
            this.enqueueLoadedChunks();
         }

         if (this.ticks % 240 == 0) {
            this.scanned.clear();
            this.enqueueLoadedChunks();
         }

         this.scanQueuedChunks();
         this.pruneUnloaded();
         this.getCandidateChunks();
      } else {
         this.reset();
      }
   }

   private void scanQueuedChunks() {
      long var1 = System.nanoTime() + 4000000L;

      for (int var3 = 0; var3 < 24 && !this.scanQueue.isEmpty(); var3++) {
         this.scanNextChunk();
         if (var3 > 0 && System.nanoTime() >= var1) {
            break;
         }
      }
   }

   private void enqueueLoadedChunks() {
      if (this.mc.world != null && this.mc.player != null) {
         ChunkPos var1 = this.mc.player.getChunkPos();
         List var2;
         (var2 = BlockUtil.getLoadedChunksList()).sort(Comparator.comparingInt(var1xx -> {
            ChunkPos var2x;
            return Math.max(Math.abs((var2x = ((WorldChunk)var1xx).getPos()).x - var1.x), Math.abs(var2x.z - var1.z));
         }));
         Iterator var3 = var2.iterator();

         while (var3.hasNext()) {
            ChunkPos var5 = ((WorldChunk)var3.next()).getPos();
            this.enqueue(var5.x, var5.z);
         }
      }
   }

   private void enqueue(int var1, int var2) {
      long var3 = ChunkPos.toLong(var1, var2);
      if (!this.scanned.contains(var3) && this.queued.add(var3)) {
         this.scanQueue.offer(var3);
      }
   }

   private void scanNextChunk() {
      Long var1;
      if ((var1 = this.scanQueue.poll()) != null) {
         this.queued.remove(var1);
         this.scanned.add(var1);
         int var2 = ChunkPos.getPackedX(var1);
         int var3 = ChunkPos.getPackedZ(var1);
         if (!this.mc.world.isChunkLoaded(var2, var3)) {
            this.removeGeode(var1);
            return;
         }

         WorldChunk var4;
         ChunkSection[] var5 = (var4 = this.mc.world.getChunk(var2, var3)).getSectionArray();
         int var6 = var4.getBottomSectionCoord();
         int var7 = var4.getPos().getStartX();
         int var8 = var4.getPos().getStartZ();
         LongOpenHashSet var9 = new LongOpenHashSet();
         Mutable var10 = new Mutable();
         ArrayList var11 = new ArrayList();
         int var12 = 0;

         for (int var13 = 0; var13 < var5.length; var13++) {
            ChunkSection var28;
            if ((var28 = var5[var13]) != null
               && var28.getBlockStateContainer().hasAny(var0 -> isAmethystSignal(var0.getBlock()) || var0.isOf(Blocks.BEEHIVE) || var0.isOf(Blocks.BEE_NEST))) {
               int var15 = var6 + var13 << 4;

               for (int var16 = 0; var16 < 16; var16++) {
                  for (int var17 = 0; var17 < 16; var17++) {
                     for (int var18 = 0; var18 < 16; var18++) {
                        BlockState var19;
                        if (isAmethystSignal((var19 = var28.getBlockState(var18, var16, var17)).getBlock())) {
                           BlockPos var21 = new BlockPos(var7 + var18, var15 + var16, var8 + var17);
                           if (var11.size() < 400) {
                              var11.add(var21);
                           }

                           for (Direction var25 : DIRECTIONS) {
                              Mutable var26 = var10.set(var21.getX() + var25.getOffsetX(), var21.getY() + var25.getOffsetY(), var21.getZ() + var25.getOffsetZ());
                              if (this.mc.world.getBlockState(var26).isOf(Blocks.STONE)) {
                                 var9.add(var26.asLong());
                              }
                           }
                        } else if ((var19.isOf(Blocks.BEEHIVE) || var19.isOf(Blocks.BEE_NEST)) && (Integer)var19.get(BeehiveBlock.HONEY_LEVEL) >= 5) {
                           var12++;
                        }
                     }
                  }
               }
            }
         }

         int var27 = Math.max(1, this.sensitivity.getIntValue());
         int var27x;
         if ((var27x = Math.max(var9.size(), var12 >= 2 ? var27 : 0)) >= var27) {
            this.setGeode(var1, new SusChunkFinderModule.ChunkCluster(new ChunkPos(var2, var3), var27x, List.copyOf(var11)));
            return;
         }

         this.removeGeode(var1);
      }
   }

   private void setGeode(long var1, SusChunkFinderModule.ChunkCluster var3) {
      SusChunkFinderModule.ChunkCluster var4 = this.geodes.put(var1, var3);
      if (!var3.equals(var4)) {
         this.candidatesDirty = true;
      }
   }

   private void removeGeode(long var1) {
      if (this.geodes.remove(var1) != null) {
         this.candidatesDirty = true;
      }
   }

   private List<BlockPos> findBestLightSphere(List<BlockPos> var1, int var2) {
      if (var1.size() < var2) {
         return List.of();
      } else {
         boolean[] var3 = new boolean[var1.size()];
         Object var4 = List.of();

         for (int var5 = 0; var5 < var1.size(); var5++) {
            if (!var3[var5]) {
               ArrayList var6 = new ArrayList();
               ArrayDeque var7;
               (var7 = new ArrayDeque()).add(var5);
               var3[var5] = true;

               while (!var7.isEmpty()) {
                  int var8 = (Integer)var7.remove();
                  BlockPos var9 = var1.get(var8);
                  var6.add(var9);

                  for (int var10 = 0; var10 < var1.size(); var10++) {
                     if (!var3[var10] && var9.getSquaredDistance((Vec3i)var1.get(var10)) <= 121.0) {
                        var3[var10] = true;
                        var7.add(var10);
                     }
                  }
               }

               if (var6.size() >= var2 && var6.size() > ((Collection)var4).size() && this.matchesGeodeSphere(var6)) {
                  var4 = var6;
               }
            }
         }

         return (List<BlockPos>)var4;
      }
   }

   private boolean matchesGeodeSphere(List<BlockPos> var1) {
      int var2 = var1.size();
      double var3 = 0.0;
      double var5 = 0.0;
      double var7 = 0.0;

      for (BlockPos var10 : var1) {
         var3 += var10.getX();
         var5 += var10.getY();
         var7 += var10.getZ();
      }

      var3 /= var2;
      var5 /= var2;
      var7 /= var2;
      double[][] var56 = new double[4][4];
      double[] var57 = new double[4];
      Iterator var58 = var1.iterator();

      while (var58.hasNext()) {
         BlockPos var59;
         double var13 = (var59 = (BlockPos)var58.next()).getX() - var3;
         double var15 = var59.getY() - var5;
         double var17 = var59.getZ() - var7;
         double var19 = var13 * var13 + var15 * var15 + var17 * var17;
         double[] var21 = new double[]{var13, var15, var17, 1.0};

         for (int var22 = 0; var22 < 4; var22++) {
            for (int var23 = 0; var23 < 4; var23++) {
               var56[var22][var23] = var56[var22][var23] + var21[var22] * var21[var23];
            }

            var57[var22] += var21[var22] * var19;
         }
      }

      double[] var581;
      if ((var581 = solve4x4(var56, var57)) == null) {
         return false;
      } else {
         double var59 = var581[0] / 2.0;
         double var14 = var581[1] / 2.0;
         double var16 = var581[2] / 2.0;
         double var18;
         if ((var18 = var581[3] + var59 * var59 + var14 * var14 + var16 * var16) <= 0.0) {
            return false;
         } else {
            double var20;
            if (!((var20 = Math.sqrt(var18)) < 3.0) && !(var20 > 7.0)) {
               double var60 = var3 + var59;
               double var24 = var5 + var14;
               double var26 = var7 + var16;
               double var28 = 0.0;
               double var30 = 0.0;
               double var32 = 0.0;
               double var34 = 0.0;
               HashSet var36 = new HashSet();
               int var37 = Integer.MAX_VALUE;
               int var38 = Integer.MAX_VALUE;
               int var39 = Integer.MAX_VALUE;
               int var40 = Integer.MIN_VALUE;
               int var41 = Integer.MIN_VALUE;
               int var42 = Integer.MIN_VALUE;
               Iterator var61 = var1.iterator();

               while (var61.hasNext()) {
                  BlockPos var44;
                  double var45 = (var44 = (BlockPos)var61.next()).getX() - var60;
                  double var47 = var44.getY() - var24;
                  double var49 = var44.getZ() - var26;
                  double var51;
                  if ((var51 = Math.sqrt(var45 * var45 + var47 * var47 + var49 * var49)) < 1.0E-4) {
                     var51 = 1.0;
                  }

                  var28 += Math.abs(var51 - var20);
                  var30 += var45 / var51;
                  var32 += var47 / var51;
                  var34 += var49 / var51;
                  var36.add((var45 >= 0.0 ? 1 : 0) | (var47 >= 0.0 ? 2 : 0) | (var49 >= 0.0 ? 4 : 0));
                  var37 = Math.min(var37, var44.getX());
                  var40 = Math.max(var40, var44.getX());
                  var38 = Math.min(var38, var44.getY());
                  var41 = Math.max(var41, var44.getY());
                  var39 = Math.min(var39, var44.getZ());
                  var42 = Math.max(var42, var44.getZ());
               }

               if (var28 / var2 > 1.35 || var36.size() < 3) {
                  return false;
               } else if (Math.sqrt(var30 * var30 + var32 * var32 + var34 * var34) / var2 > 0.72) {
                  return false;
               } else {
                  BlockPos var62 = BlockPos.ofFloored(var60, var24, var26);
                  if (this.mc.world.getLightLevel(LightType.BLOCK, var62) > 3) {
                     return false;
                  } else {
                     int var46 = var40 - var37 + 1;
                     int var63 = var41 - var38 + 1;
                     int var48 = var42 - var39 + 1;
                     return (var46 >= 3 || var48 >= 3) && var46 + var48 >= 6 && var63 >= 2;
                  }
               }
            } else {
               return false;
            }
         }
      }
   }

   private static double[] solve4x4(double[][] var0, double[] var1) {
      double[][] var2 = new double[4][5];

      for (int var3 = 0; var3 < 4; var3++) {
         System.arraycopy(var0[var3], 0, var2[var3], 0, 4);
         var2[var3][4] = var1[var3];
      }

      for (int var10 = 0; var10 < 4; var10++) {
         int var4 = var10;

         for (int var5 = var10 + 1; var5 < 4; var5++) {
            if (Math.abs(var2[var5][var10]) > Math.abs(var2[var4][var10])) {
               var4 = var5;
            }
         }

         double[] var13 = var2[var10];
         var2[var10] = var2[var4];
         var2[var4] = var13;
         if (Math.abs(var2[var10][var10]) < 1.0E-9) {
            return null;
         }

         for (int var6 = var10 + 1; var6 < 4; var6++) {
            double var7 = var2[var6][var10] / var2[var10][var10];

            for (int var9 = var10; var9 <= 4; var9++) {
               var2[var6][var9] = var2[var6][var9] - var7 * var2[var10][var9];
            }
         }
      }

      double[] var11 = new double[4];

      for (int var12 = 3; var12 >= 0; var12--) {
         double var14 = 0.0;

         for (int var15 = var12 + 1; var15 < 4; var15++) {
            var14 += var2[var12][var15] * var11[var15];
         }

         var11[var12] = (var2[var12][4] - var14) / var2[var12][var12];
      }

      return var11;
   }

   private static long cellKey(int var0, int var1) {
      return ChunkPos.toLong(var0 >> 3, var1 >> 3);
   }

   private static boolean isGeodeSignature(Block var0) {
      return var0 == Blocks.AMETHYST_BLOCK
         || var0 == Blocks.BUDDING_AMETHYST
         || var0 == Blocks.CALCITE
         || var0 == Blocks.SMOOTH_BASALT
         || isAmethystGrowth(var0);
   }

   private static boolean isAmethystSignal(Block var0) {
      return var0 == Blocks.AMETHYST_BLOCK || var0 == Blocks.BUDDING_AMETHYST || isAmethystGrowth(var0);
   }

   private static boolean isAmethystGrowth(Block var0) {
      return var0 == Blocks.SMALL_AMETHYST_BUD || var0 == Blocks.MEDIUM_AMETHYST_BUD || var0 == Blocks.LARGE_AMETHYST_BUD || var0 == Blocks.AMETHYST_CLUSTER;
   }

   private void pruneUnloaded() {
      if (this.mc.world != null && this.ticks % 20 == 0 && this.geodes.entrySet().removeIf(var1x -> {
         int var2 = ChunkPos.getPackedX(var1x.getKey());
         int var3 = ChunkPos.getPackedZ(var1x.getKey());
         return !this.mc.world.isChunkLoaded(var2, var3);
      })) {
         this.candidatesDirty = true;
      }
   }

   @EventListener
   public void onRender3D(Render3DEvent var1) {
      if (this.mc.world != null && !this.geodes.isEmpty()) {
         this.getCandidateChunks();
         int var2;
         if ((var2 = this.alpha.getIntValue()) != 0) {
            Color var3 = new Color(255, 0, 0, var2);
            this.candidatePlates.draw(var1, this.candidateKeys, var3, null, 1.0F, 63.0, 0.05);
            boolean var4 = this.markGeodeChunks.getValue();
            boolean var5 = this.renderClusters.getValue();
            Camera var6;
            if ((var4 || var5) && (var6 = RenderUtils.getCamera()) != null && var6.isReady()) {
               Color var7 = new Color(180, 100, 255, var2 / 3);
               Color var8 = new Color(195, 125, 255, var2);
               this.renderBoxes.clear();
               this.renderLines.clear();
               Iterator var20 = this.geodes.values().iterator();

               while (var20.hasNext()) {
                  SusChunkFinderModule.ChunkCluster var10;
                  double var11 = (var10 = (SusChunkFinderModule.ChunkCluster)var20.next()).pos.getStartX();
                  double var13 = var10.pos.getStartZ();
                  if (var4 && RenderVisibility.box(var11, 63.0, var13, var11 + 16.0, 63.05, var13 + 16.0)) {
                     this.renderBoxes.add(new ColoredBox(var11, 63.0, var13, var11 + 16.0, 63.05, var13 + 16.0, var7));
                     RenderUtils.addBoxOutline(this.renderLines, var11, 63.0, var13, var11 + 16.0, 63.05, var13 + 16.0, var8, 1.5F);
                  }

                  if (var5) {
                     Iterator var15 = var10.clusterPositions.iterator();

                     while (var15.hasNext()) {
                        BlockPos var16;
                        if (RenderVisibility.box(
                           (var16 = (BlockPos)var15.next()).getX(), var16.getY(), var16.getZ(), var16.getX() + 1, var16.getY() + 1, var16.getZ() + 1
                        )) {
                           this.renderBoxes
                              .add(new ColoredBox(var16.getX(), var16.getY(), var16.getZ(), var16.getX() + 1, var16.getY() + 1, var16.getZ() + 1, var7));
                        }
                     }
                  }
               }

               MatrixStack var201 = var1.matrixStack;
               var1.matrixStack.push();

               try {
                  RenderUtils.applyCameraTransform(var201, var6);
                  RenderUtils.renderFilledBoxes(var201, this.renderBoxes);
                  RenderUtils.renderLines(var201, this.renderLines);
               } finally {
                  var201.pop();
               }

               return;
            }
         }
      }
   }

   private Set<Long> getCandidateChunks() {
      int var1 = this.simulationDistance.getIntValue();
      boolean var2 = this.scanQueue.isEmpty() || this.ticksSinceCommit >= 60;
      if (var1 != this.cachedSimulationRadius || this.candidatesDirty && var2) {
         this.cachedCandidates = this.calculateCandidateChunks(var1);
         this.candidateKeys.clear();
         this.candidateKeys.addAll(this.cachedCandidates);
         this.cachedSimulationRadius = var1;
         this.candidatesDirty = false;
         this.ticksSinceCommit = 0;
      }

      return this.cachedCandidates;
   }

   private Set<Long> calculateCandidateChunks(int var1) {
      ArrayList var2;
      (var2 = new ArrayList<>(this.geodes.values()))
         .sort(Comparator.<SusChunkFinderModule.ChunkCluster>comparingInt(var0 -> var0.pos.x).thenComparingInt(var0 -> var0.pos.z));
      long[] var3 = new long[var2.size()];

      for (int var4 = 0; var4 < var2.size(); var4++) {
         var3[var4] = ((SusChunkFinderModule.ChunkCluster)var2.get(var4)).pos.toLong();
      }

      return ChunkRegionBuilder.build(var3, var1);
   }







   static {
      int[][] var6 = new int[6][];
      int[] var12;
      (var12 = new int[3])[0] = 1;
      var12[1] = 0;
      var12[2] = 0;
      var6[0] = var12;
      int[] var14;
      (var14 = new int[3])[0] = -1;
      var14[1] = 0;
      var14[2] = 0;
      var6[1] = var14;
      int[] var16;
      (var16 = new int[3])[0] = 0;
      var16[1] = 1;
      var16[2] = 0;
      var6[2] = var16;
      int[] var18;
      (var18 = new int[3])[0] = 0;
      var18[1] = -1;
      var18[2] = 0;
      var6[3] = var18;
      int[] var6x;
      (var6x = new int[3])[0] = 0;
      var6x[1] = 0;
      var6x[2] = 1;
      var6[4] = var6x;
      int[] var22;
      (var22 = new int[3])[0] = 0;
      var22[1] = 0;
      var22[2] = -1;
      var6[5] = var22;
      NEIGHBORS = var6;
   }

   private record ChunkCluster(ChunkPos pos, int hits, List<BlockPos> clusterPositions) {
   }
}
