package krispy.feature;

import java.awt.Color;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Iterator;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import krispy.Krispy;
import krispy.event.EventListener;
import krispy.event.events.TickEvent;
import krispy.mixin.MobSpawnerLogicAccessor;
import krispy.module.Category;
import krispy.module.Module;
import krispy.module.ModuleManager;
import krispy.module.setting.BooleanSetting;
import krispy.module.setting.NumberSetting;
import krispy.module.setting.StringSetting;
import krispy.utils.BlockUtil;
import krispy.utils.EnchantmentUtil;
import krispy.utils.EncryptedString;
import krispy.utils.InventoryUtil;
import krispy.utils.embed.DiscordWebhook;
import krispy.utils.embed.DiscordWebhook.EmbedObject;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.entity.BarrelBlockEntity;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.ChestBlockEntity;
import net.minecraft.block.entity.EnchantingTableBlockEntity;
import net.minecraft.block.entity.EnderChestBlockEntity;
import net.minecraft.block.entity.FurnaceBlockEntity;
import net.minecraft.block.entity.MobSpawnerBlockEntity;
import net.minecraft.block.entity.ShulkerBoxBlockEntity;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket.Action;
import net.minecraft.network.packet.s2c.common.DisconnectS2CPacket;
import net.minecraft.registry.RegistryKey;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.hit.HitResult.Type;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.chunk.WorldChunk;

public final class TunnelBaseFinderModule extends Module {
   private final NumberSetting minimumStorage;
   private final BooleanSetting spawners;
   private final BooleanSetting autoTotemBuy;
   private final NumberSetting totemSlot;
   private final BooleanSetting autoMend;
   private final NumberSetting xpBottleSlot;
   private final BooleanSetting discordNotification;
   private final StringSetting webhook;
   private final BooleanSetting totemCheck;
   private final NumberSetting totemCheckTime;
   private TunnelBaseFinderModule.TunnelDirection currentDirection;
   private int blocksMined;
   private int spawnerCount;
   private int idleTicks;
   private Vec3d lastPosition;
   private boolean isDigging;
   private boolean shouldDig;
   private int totemCheckCounter;
   private int totemBuyCounter;
   private double actionDelay;
   private int scanCooldown;

   public TunnelBaseFinderModule() {
      super(EncryptedString.of("Tunnel Base Finder"), EncryptedString.of("Finds bases digging tunnel"), -1, Category.DONUT);
      this.minimumStorage = new NumberSetting(EncryptedString.of("Minimum Storage"), 1.0, 500.0, 100.0, 1.0);
      this.spawners = new BooleanSetting(EncryptedString.of("Spawners"), true);
      this.autoTotemBuy = new BooleanSetting(EncryptedString.of("Auto Totem Buy"), true);
      this.totemSlot = new NumberSetting(EncryptedString.of("Totem Slot"), 1.0, 9.0, 8.0, 1.0);
      this.autoMend = new BooleanSetting(EncryptedString.of("Auto Mend"), true)
         .setDescription(EncryptedString.of("Automatically repairs pickaxe."));
      this.xpBottleSlot = new NumberSetting(EncryptedString.of("XP Bottle Slot"), 1.0, 9.0, 9.0, 1.0);
      this.discordNotification = new BooleanSetting(EncryptedString.of("Discord Notification"), false);
      this.webhook = new StringSetting(EncryptedString.of("Webhook"), "");
      this.totemCheck = new BooleanSetting(EncryptedString.of("Totem Check"), true);
      this.totemCheckTime = new NumberSetting(EncryptedString.of("Totem Check Time"), 1.0, 120.0, 20.0, 1.0);
      this.addSettings(this.minimumStorage, this.spawners, this.autoTotemBuy, this.totemSlot,
         this.autoMend, this.xpBottleSlot, this.discordNotification, this.webhook,
         this.totemCheck, this.totemCheckTime);
   }

   public void onEnable() {
      super.onEnable();
      this.currentDirection = this.mc.player == null ? null : this.getInitialDirection();
      this.blocksMined = 0;
      this.idleTicks = 0;
      this.spawnerCount = 0;
      this.lastPosition = null;
      this.isDigging = false;
      this.shouldDig = false;
      this.totemCheckCounter = 0;
      this.totemBuyCounter = 0;
      this.actionDelay = 0.0;
      this.scanCooldown = 0;
   }

   public void onDisable() {
      super.onDisable();
      this.currentDirection = null;
      this.isDigging = false;
      this.shouldDig = false;
      this.mc.options.leftKey.setPressed(false);
      this.mc.options.rightKey.setPressed(false);
      this.mc.options.forwardKey.setPressed(false);
      if (this.mc.interactionManager != null) {
         this.mc.interactionManager.cancelBlockBreaking();
      }
   }

   @EventListener
   public void onTick(TickEvent var1) {
      if (this.mc.player != null && this.mc.world != null && this.mc.interactionManager != null) {
         if (this.currentDirection == null) {
            this.currentDirection = this.getInitialDirection();
         }

         if (this.currentDirection != null) {
            Module var2 = Krispy.INSTANCE.MODULE_MANAGER.getModuleByClass(AutoEatModule.class);
            if (!var2.isEnabled() || !((AutoEatModule)var2).shouldEat()) {
               int var3 = (this.calculateDirection(this.currentDirection) + (90) * this.idleTicks)
                  % (360);
               if (this.mc.player.getYaw() != (float)var3) {
                  this.mc.player.setYaw((float)var3);
               }

               if (this.mc.player.getPitch() != 2.0F) {
                  this.mc.player.setPitch(2.0F);
               }

               this.updateDirection(this.getInitialDirection());
               if (this.blocksMined > 0) {
                  this.mc.options.forwardKey.setPressed(false);
                  this.blocksMined -= 1;
               } else {
                  if ((this.scanCooldown += 1) >= (20)) {
                     this.scanCooldown = 0;
                     this.notifyFound();
                     if (!this.isEnabled()) {
                        return;
                     }
                  }

                  if (this.autoTotemBuy.getValue()) {
                     int var4 = this.totemSlot.getIntValue() - (1);
                     if (!this.mc.player.getInventory().getStack(var4).isOf(Items.TOTEM_OF_UNDYING)) {
                        if (this.totemBuyCounter < (30) && !this.shouldDig) {
                           this.totemBuyCounter += 1;
                           return;
                        }

                        this.totemBuyCounter = 0;
                        this.shouldDig = true;
                        if (this.mc.player.getInventory().getSelectedSlot() != var4) {
                           InventoryUtil.swap(var4);
                        }

                        ScreenHandler var18 = this.mc.player.currentScreenHandler;
                        if (this.mc.player.currentScreenHandler instanceof GenericContainerScreenHandler && ((GenericContainerScreenHandler)var18).getRows() == (3)) {
                           if (var18.getSlot(11).getStack().isOf(Items.END_STONE)) {
                              this.mc
                                 .interactionManager
                                 .clickSlot(
                                    this.mc.player.currentScreenHandler.syncId,
                                    13,
                                    0,
                                    SlotActionType.PICKUP,
                                    this.mc.player
                                 );
                              this.blocksMined = 10;
                              return;
                           }

                           if (var18.getSlot(16).getStack().isOf(Items.EXPERIENCE_BOTTLE)) {
                              this.mc
                                 .interactionManager
                                 .clickSlot(
                                    this.mc.player.currentScreenHandler.syncId,
                                    13,
                                    0,
                                    SlotActionType.PICKUP,
                                    this.mc.player
                                 );
                              this.blocksMined = 10;
                              return;
                           }

                           this.mc.player.networkHandler.sendPacket(new PlayerActionC2SPacket(Action.DROP_ALL_ITEMS, BlockPos.ORIGIN, Direction.DOWN));
                           if (var18.getSlot(23).getStack().isOf(Items.LIME_STAINED_GLASS_PANE)) {
                              this.mc
                                 .interactionManager
                                 .clickSlot(
                                    this.mc.player.currentScreenHandler.syncId,
                                    23,
                                    0,
                                    SlotActionType.PICKUP,
                                    this.mc.player
                                 );
                              this.blocksMined = 10;
                              return;
                           }

                           this.mc.getNetworkHandler().sendChatCommand("shop");
                           this.blocksMined = 10;
                           return;
                        }

                        this.mc.getNetworkHandler().sendChatCommand("shop");
                        this.blocksMined = 10;
                        return;
                     }

                     if (this.shouldDig) {
                        if (this.mc.currentScreen != null) {
                           this.mc.player.closeHandledScreen();
                           this.blocksMined = 20;
                        }

                        this.shouldDig = false;
                        this.totemBuyCounter = 0;
                     }
                  }

                  if (this.isDigging) {
                     int var12 = this.xpBottleSlot.getIntValue() - (1);
                     ItemStack var5 = this.mc.player.getInventory().getStack(var12);
                     if (this.mc.player.getInventory().getSelectedSlot() != var12) {
                        InventoryUtil.swap(var12);
                     }

                     if (!var5.isOf(Items.EXPERIENCE_BOTTLE)) {
                        ScreenHandler var6 = this.mc.player.currentScreenHandler;
                        if (!(this.mc.player.currentScreenHandler instanceof GenericContainerScreenHandler) || ((GenericContainerScreenHandler)var6).getRows() != (3)) {
                           this.mc.getNetworkHandler().sendChatCommand("shop");
                           this.blocksMined = 10;
                           return;
                        }

                        if (var6.getSlot(11).getStack().isOf(Items.END_STONE)) {
                           this.mc
                              .interactionManager
                              .clickSlot(
                                 this.mc.player.currentScreenHandler.syncId,
                                 13,
                                 0,
                                 SlotActionType.PICKUP,
                                 this.mc.player
                              );
                           this.blocksMined = 10;
                           return;
                        }

                        if (var6.getSlot(16).getStack().isOf(Items.EXPERIENCE_BOTTLE)) {
                           this.mc
                              .interactionManager
                              .clickSlot(
                                 this.mc.player.currentScreenHandler.syncId,
                                 16,
                                 0,
                                 SlotActionType.PICKUP,
                                 this.mc.player
                              );
                           this.blocksMined = 10;
                           return;
                        }

                        if (var6.getSlot(17).getStack().isOf(Items.LIME_STAINED_GLASS_PANE)) {
                           this.mc
                              .interactionManager
                              .clickSlot(
                                 this.mc.player.currentScreenHandler.syncId,
                                 17,
                                 0,
                                 SlotActionType.PICKUP,
                                 this.mc.player
                              );
                           this.blocksMined = 10;
                           return;
                        }

                        this.mc.player.networkHandler.sendPacket(new PlayerActionC2SPacket(Action.DROP_ALL_ITEMS, BlockPos.ORIGIN, Direction.DOWN));
                        if (var6.getSlot(23).getStack().isOf(Items.LIME_STAINED_GLASS_PANE)) {
                           this.mc
                              .interactionManager
                              .clickSlot(
                                 this.mc.player.currentScreenHandler.syncId,
                                 23,
                                 0,
                                 SlotActionType.PICKUP,
                                 this.mc.player
                              );
                           this.blocksMined = 10;
                           return;
                        }

                        this.mc.getNetworkHandler().sendChatCommand("shop");
                        this.blocksMined = 10;
                     } else {
                        if (this.mc.currentScreen != null) {
                           this.mc.player.closeHandledScreen();
                           this.blocksMined = 20;
                           return;
                        }

                        if (!EnchantmentUtil.hasEnchantment(this.mc.player.getOffHandStack(), Enchantments.MENDING)) {
                           this.mc
                              .interactionManager
                              .clickSlot(
                                 this.mc.player.currentScreenHandler.syncId,
                                 (36) + this.totemCheckCounter,
                                 40,
                                 SlotActionType.SWAP,
                                 this.mc.player
                              );
                           this.blocksMined = 20;
                           return;
                        }

                        if (this.mc.player.getOffHandStack().getDamage() > 0) {
                           ActionResult var19 = this.mc.interactionManager.interactItem(this.mc.player, Hand.MAIN_HAND);
                           if (var19.isAccepted()) {
                              this.mc.player.swingHand(Hand.MAIN_HAND);
                           }

                           this.blocksMined = 1;
                           return;
                        }

                        this.mc
                           .interactionManager
                           .clickSlot(
                              this.mc.player.currentScreenHandler.syncId,
                              (36) + this.totemCheckCounter,
                              40,
                              SlotActionType.SWAP,
                              this.mc.player
                           );
                        this.isDigging = false;
                     }
                  } else {
                     if (this.autoMend.getValue()) {
                        ItemStack var13 = this.mc.player.getMainHandStack();
                        if (EnchantmentUtil.hasEnchantment(var13, Enchantments.MENDING)
                           && var13.getMaxDamage() - var13.getDamage() < (100)) {
                           this.isDigging = true;
                           this.totemCheckCounter = this.mc.player.getInventory().getSelectedSlot();
                        }
                     }

                     if (this.totemCheck.getValue()) {
                        boolean var14 = this.mc.player.getOffHandStack().getItem().equals(Items.TOTEM_OF_UNDYING);
                        Module var16 = Krispy.INSTANCE.MODULE_MANAGER.getModuleByClass(AutoTotemModule.class);
                        if (var14) {
                           this.actionDelay = 0.0;
                        } else if (var16.isEnabled() && ((AutoTotemModule)var16).findItemSlot(Items.TOTEM_OF_UNDYING) != (-1)) {
                           this.actionDelay = 0.0;
                        } else {
                           this.actionDelay = this.actionDelay
                              + 1.0;
                        }

                        if (this.actionDelay > this.totemCheckTime.getValue()) {
                           this.notifyTotemExploded(
                              "Your totem exploded",
                              (int)this.mc.player.getX(),
                              (int)this.mc.player.getY(),
                              (int)this.mc.player.getZ()
                           );
                           return;
                        }
                     }

                      boolean var15 = false;
                     HitResult var17 = this.mc.crosshairTarget;
                     if (this.mc.crosshairTarget instanceof BlockHitResult) {
                        BlockPos var20 = ((BlockHitResult)var17).getBlockPos();
                        if (!BlockUtil.isBlockAtPosition(var20, Blocks.AIR)) {
                           var15 = this.isBlockPositionValid(var20, this.mc.player.getHorizontalFacing());
                        }
                     }

                      if (var15) {
                        this.handleBlockBreaking(true);
                     }

                     boolean var21 = this.isBlockInDirection(this.mc.player.getHorizontalFacing(), 3);
                     int var7 = 0;
                     HitResult var8 = this.mc.crosshairTarget;
                     if (this.mc.crosshairTarget instanceof BlockHitResult) {
                        var7 = this.mc
                                 .player
                                 .getCameraPosVec(1.0F)
                                 .distanceTo(Vec3d.ofCenter(((BlockHitResult)var8).getBlockPos()))
                              > 3.0
                           ? 1
                           : 0;
                     }

                     if (!var15 && (var7 == 0 || !var21)) {
                        this.idleTicks += 1;
                        this.lastPosition = this.mc.player.getEntityPos();
                        this.blocksMined = 5;
                        return;
                     }

                     this.mc.options.forwardKey.setPressed(((var21 && var7 != 0)));
                     if (this.idleTicks > 0
                        && this.lastPosition != null
                        && this.mc.player.getEntityPos().distanceTo(this.lastPosition)
                           > 1.0) {
                        this.lastPosition = this.mc.player.getEntityPos();
                        Direction var9 = this.mc.player.getHorizontalFacing().rotateYCounterclockwise();
                        BlockPos var10 = this.mc.player.getBlockPos().up().offset(var9);

                        for (int var11 = 0; var11 < (5); var11++) {
                           var10 = var10.offset(var9);
                           if (!this.mc.world.getBlockState(var10).getBlock().equals(Blocks.AIR)) {
                              if (this.isBlockPositionValid(var10, var9) && this.isBlockPositionValid(var10.offset(var9), var9)) {
                                 this.idleTicks -= 1;
                                 this.blocksMined = 5;
                              }

                              return;
                           }
                        }
                     }
                  }
               }
            }
         }
      }
   }

   private int calculateDirection(TunnelBaseFinderModule.TunnelDirection var1) {
      if (var1 == TunnelBaseFinderModule.TunnelDirection.NORTH) {
         return 180;
      } else if (var1 == TunnelBaseFinderModule.TunnelDirection.SOUTH) {
         return 0;
      } else if (var1 == TunnelBaseFinderModule.TunnelDirection.EAST) {
         return 270;
      } else {
         return var1 == TunnelBaseFinderModule.TunnelDirection.WEST ? 90 : Math.round(this.mc.player.getYaw());
      }
   }

   private boolean isBlockInDirection(Direction var1, int var2) {
      BlockPos var3 = this.mc.player.getBlockPos().down();
      BlockPos var4 = this.mc.player.getBlockPos();

      for (int var5 = 0; var5 < var2; var5++) {
         BlockPos var6 = var3.offset(var1, var5);
         BlockPos var7 = var4.offset(var1, var5);
         if (this.mc.world.getBlockState(var6).isAir() || !this.isBlockPositionSafe(var6)) {
            return false;
         }

         if (!this.mc.world.getBlockState(var7).isAir()) {
            return false;
         }
      }

      return true;
   }

   private boolean isBlockPositionValid(BlockPos var1, Direction var2) {
      if (var1 != null && var2 != null && this.mc.player != null && this.mc.world != null) {
         BlockPos var3 = this.mc.player.getBlockPos();
         int var4 = var1.getX() - var3.getX();
         int var5 = var1.getZ() - var3.getZ();
         int var6 = var4 * var2.getOffsetX() + var5 * var2.getOffsetZ();
         int var7 = var4 * var2.getOffsetZ() - var5 * var2.getOffsetX();
         int var8 = var1.getY() - var3.getY();
         if (var6 >= (1) && var6 <= (4) && var7 == 0 && var8 >= 0 && var8 <= (1)) {
            if (this.mc.player.getCameraPosVec(1.0F).squaredDistanceTo(Vec3d.ofCenter(var1))
               > 25.0) {
               return false;
            } else if (!this.mc.world.getBlockState(var1).isAir()
               && !(this.mc.world.getBlockState(var1).getHardness(this.mc.world, var1) < 0.0F)) {
               Direction var9 = var2.rotateYClockwise();
               BlockPos[] var10000 = new BlockPos[5];
               var10000[0] = var1;
               var10000[1] = var1.up();
               var10000[2] = var1.offset(var2);
               var10000[3] = var1.offset(var9);
               var10000[4] = var1.offset(var9.getOpposite());
               BlockPos[] var10 = var10000;
               int var11 = var10.length;

               for (int var12 = 0; var12 < var11; var12++) {
                  BlockPos var13 = var10[var12];
                  if (!this.isBlockPositionSafe(var13)) {
                     return false;
                  }
               }

               return ((this.mc.world.getBlockState(var1.up()).getBlock() != Blocks.GRAVEL));
            } else {
               return false;
            }
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   private boolean isBlockPositionSafe(BlockPos var1) {
      return this.isBlockValid(this.mc.world.getBlockState(var1).getBlock());
   }

   private boolean isBlockValid(Block var1) {
      return ((var1 != Blocks.LAVA && var1 != Blocks.WATER));
   }

   private void updateDirection(TunnelBaseFinderModule.TunnelDirection var1) {
      double var2 = this.mc.player.getX();
      double var4 = this.mc.player.getZ();
      double var6 = Math.floor(var4);
      double var8 = Math.floor(var2) + 0.5 - var2;
      double var10 = var6 + 0.5 - var4;
      this.mc.options.leftKey.setPressed(false);
      this.mc.options.rightKey.setPressed(false);
      int var12 = 0;
      int var13 = 0;
      if (var1 == TunnelBaseFinderModule.TunnelDirection.SOUTH) {
         if (var8 > 0.1) {
            var13 = 1;
         } else if (var8 < -0.1) {
            var12 = 1;
         }
      }

      if (var1 == TunnelBaseFinderModule.TunnelDirection.NORTH) {
         if (var8 > 0.1) {
            var12 = 1;
         } else if (var8 < -0.1) {
            var13 = 1;
         }
      }

      if (var1 == TunnelBaseFinderModule.TunnelDirection.WEST) {
         if (var10 > 0.1) {
            var13 = 1;
         } else if (var10 < -0.1) {
            var12 = 1;
         }
      }

      if (var1 == TunnelBaseFinderModule.TunnelDirection.EAST) {
         if (var10 > 0.1) {
            var12 = 1;
         } else if (var10 < -0.1) {
            var13 = 1;
         }
      }

      if (var12 != 0) {
         this.mc.options.rightKey.setPressed(true);
      }

      if (var13 != 0) {
         this.mc.options.leftKey.setPressed(true);
      }
   }

   private void handleBlockBreaking(boolean var1) {
      if (!this.mc.player.isUsingItem()) {
         if (var1 && this.mc.crosshairTarget != null && this.mc.crosshairTarget.getType() == Type.BLOCK) {
            BlockHitResult var2 = (BlockHitResult)this.mc.crosshairTarget;
            BlockPos var3 = ((BlockHitResult)this.mc.crosshairTarget).getBlockPos();
            if (!this.mc.world.getBlockState(var3).isAir()) {
               Direction var4 = var2.getSide();
               if (this.mc.interactionManager.updateBlockBreakingProgress(var3, var4)) {
                  this.mc.player.swingHand(Hand.MAIN_HAND);
               }
            }
         } else {
            this.mc.interactionManager.cancelBlockBreaking();
         }
      }
   }

   private TunnelBaseFinderModule.TunnelDirection getInitialDirection() {
      float var1 = this.mc.player.getYaw() % 360.0F;
      if (var1 < 0.0F) {
         var1 += 360.0F;
      }

      if (var1 >= 45.0F && var1 < 135.0F) {
         return TunnelBaseFinderModule.TunnelDirection.WEST;
      } else if (var1 >= 135.0F && var1 < 225.0F) {
         return TunnelBaseFinderModule.TunnelDirection.NORTH;
      } else {
         return var1 >= 225.0F && var1 < 315.0F
            ? TunnelBaseFinderModule.TunnelDirection.EAST
            : TunnelBaseFinderModule.TunnelDirection.SOUTH;
      }
   }

   private void notifyFound() {
      int var1 = 0;
      int var2 = 0;
      BlockPos var3 = null;
      Iterator var4 = BlockUtil.getLoadedChunks().iterator();

      while (var4.hasNext()) {
         for (Object var6 : ((WorldChunk)var4.next()).getBlockEntityPositions()) {
            BlockEntity var7 = this.mc.world.getBlockEntity((BlockPos)var6);
            if (this.spawners.getValue() && var7 instanceof MobSpawnerBlockEntity) {
               String var8 = ((MobSpawnerLogicAccessor)((MobSpawnerBlockEntity)var7).getLogic())
                  .getSpawnEntry()
                  .getNbt()
                  .getString("id")
                  .orElse("");
               if (!var8.equals("minecraft:cave_spider")
                  && !var8.equals("minecraft:spider")) {
                  var2++;
                  var3 = (BlockPos)var6;
               }
            }

            if (!(var7 instanceof ChestBlockEntity) && !(var7 instanceof EnderChestBlockEntity)) {
               if (var7 instanceof ShulkerBoxBlockEntity) {
                  var1++;
                  continue;
               }

               if (!(var7 instanceof FurnaceBlockEntity) && !(var7 instanceof BarrelBlockEntity) && !(var7 instanceof EnchantingTableBlockEntity)) {
                  continue;
               }
            }

            var1++;
         }
      }

      if (var2 > 0) {
         this.spawnerCount += 1;
      } else {
         this.spawnerCount = 0;
      }

      if (this.spawnerCount > (10)) {
         this.notifyFound(
            "YOU FOUND SPAWNER",
            var3.getX(),
            var3.getY(),
            var3.getZ(),
            false
         );
         this.spawnerCount = 0;
      }

      if (var1 > this.minimumStorage.getIntValue()) {
         this.notifyFound(
            "YOU FOUND BASE",
            (int)this.mc.player.getX(),
            (int)this.mc.player.getY(),
            (int)this.mc.player.getZ(),
            true
         );
      }
   }

   private void notifyTotemExploded(String message, int x, int y, int z) {
      if (this.discordNotification.getValue()) {
         DiscordWebhook webhookMessage = new DiscordWebhook(this.webhook.value);
         EmbedObject embed = new EmbedObject();
         embed.setTitle("Totem Exploded");
         embed.setThumbnail(String.valueOf(MinecraftClient.getInstance().getSession().getUuidOrNull()));
         embed.setDescription("Your Totem Exploded - " + MinecraftClient.getInstance().getSession().getUsername());
         embed.setColor(Color.RED);
         embed.setFooter(LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm")), null);
         embed.addField("Location", "x: " + x + " y: " + y + " z: " + z, true);
         webhookMessage.addEmbed(embed);
         sendWebhookAsync(webhookMessage);
      }
      this.disconnectWithMessage(Text.of(message));
   }

   private void notifyFound(String message, int x, int y, int z, boolean base) {
      String type = base ? "Base" : "Spawner";
      if (this.discordNotification.getValue()) {
         DiscordWebhook webhookMessage = new DiscordWebhook(this.webhook.value);
         EmbedObject embed = new EmbedObject();
         embed.setTitle(type);
         embed.setThumbnail(String.valueOf(MinecraftClient.getInstance().getSession().getUuidOrNull()));
         embed.setDescription(type + " Found - " + MinecraftClient.getInstance().getSession().getUsername());
         embed.setColor(Color.GRAY);
         embed.setFooter(LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm")), null);
         embed.addField(type + "Found at", "x: " + x + " y: " + y + " z: " + z, true);
         webhookMessage.addEmbed(embed);
         sendWebhookAsync(webhookMessage);
      }
      this.disconnectWithMessage(Text.of(message));
   }

   private void disconnectWithMessage(Text message) {
      MutableText notice = Text.literal("[TunnelBaseFinder] ");
      notice.append(message);
      if (this.isEnabled()) {
         this.toggle();
      }
      if (this.mc.player != null && this.mc.player.networkHandler != null) {
         this.mc.player.networkHandler.onDisconnect(new DisconnectS2CPacket(notice));
      }
   }

   private static void sendWebhookAsync(DiscordWebhook webhookMessage) {
      CompletableFuture.runAsync(() -> {
         try {
            webhookMessage.execute();
         } catch (Exception error) {
            System.err.println("Tunnel Base Finder notification failed: " + error.getMessage());
         }
      });
   }

   public boolean isDigging() {
      return this.isDigging;
   }

   static enum TunnelDirection {
      NORTH, SOUTH, EAST, WEST
   }
}
