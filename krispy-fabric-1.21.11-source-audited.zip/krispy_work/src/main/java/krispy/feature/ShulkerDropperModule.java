package krispy.feature;

import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Random;
import krispy.event.EventListener;
import krispy.event.events.TickEvent;
import krispy.module.Category;
import krispy.module.Module;
import krispy.module.setting.BooleanSetting;
import krispy.module.setting.NumberSetting;
import krispy.module.setting.Setting;
import krispy.utils.BytecodeException;
import krispy.utils.EncryptedString;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.SlotActionType;


public final class ShulkerDropperModule extends Module {
   private final NumberSetting delay = new NumberSetting(
      EncryptedString.of("Delay"),
      0.0,
      20.0,
      1.0,
      1.0
   );
   private final NumberSetting clicksPerBuy = new NumberSetting(
      EncryptedString.of("Clicks Per Buy"),
      1.0,
      32.0,
      8.0,
      1.0
   );
   private final NumberSetting reopenDelay = new NumberSetting(
      EncryptedString.of("Reopen Delay"),
      1.0,
      60.0,
      20.0,
      1.0
   );
   private final BooleanSetting dropBought = new BooleanSetting(
      EncryptedString.of("Drop Bought"), true
   );
   private int delayCounter;

   public ShulkerDropperModule() {
      super(
         EncryptedString.of("Shulker Dropper"),
         EncryptedString.of(
            "Automatically buys and drops shulker boxes from /shop"
         ),
         -1,
         Category.MISC
      );
      Setting[] var10001 = new Setting[4];
      var10001[0] = this.delay;
      var10001[1] = this.clicksPerBuy;
      var10001[2] = this.reopenDelay;
      var10001[3] = this.dropBought;
      this.addSettings(var10001);
   }

   @Override
   public void onEnable() {
      this.delayCounter = 0;
      super.onEnable();
   }

   @Override
   public void onDisable() {
      this.delayCounter = 0;
      super.onDisable();
   }

   @EventListener
   public void onTick(TickEvent var1) {
      if (this.mc.player != null && this.mc.interactionManager != null && this.mc.getNetworkHandler() != null) {
         int var10000 = this.delayCounter;
         this.delayCounter -= 1;
         if (var10000 <= 0) {
            if (!(this.mc.player.currentScreenHandler instanceof GenericContainerScreenHandler var2)) {
               this.mc.getNetworkHandler().sendChatCommand("shop");
               this.delayCounter = this.reopenDelay.getIntValue();
            } else {
               int var6 = var2.getRows() * (9);
               int var4 = -1;

               for (int var5 = 0; var5 < var6; var5++) {
                  if (var2.getSlot(var5).getStack().isOf(Items.SHULKER_BOX)) {
                     var4 = var5;
                     break;
                  }
               }

               if (var4 < 0) {
                  this.delayCounter = Math.max(1, this.delay.getIntValue());
               } else {
                  for (int var7 = 0; var7 < this.clicksPerBuy.getIntValue(); var7++) {
                     this.mc.interactionManager.clickSlot(var2.syncId, var4, 0, SlotActionType.PICKUP, this.mc.player);
                  }

                  if (this.dropBought.getValue()) {
                     for (int var8 = var6; var8 < var2.slots.size(); var8++) {
                        if (var2.getSlot(var8).getStack().isOf(Items.SHULKER_BOX)) {
                           this.mc.interactionManager.clickSlot(var2.syncId, var8, 1, SlotActionType.THROW, this.mc.player);
                        }
                     }
                  }

                  this.delayCounter = Math.max(1, this.delay.getIntValue());
               }
            }
         }
      }
   }
}
