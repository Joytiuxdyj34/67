package krispy.feature;

import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import krispy.Krispy;
import krispy.event.EventListener;
import krispy.event.events.ChunkMarkClosedEvent;
import krispy.event.events.KeyEvent;
import krispy.event.events.MouseButtonEvent;
import krispy.event.events.MouseScrolledEvent;
import krispy.event.events.SetScreenEvent;
import krispy.event.events.TickEvent;
import krispy.halloween.CinematicCamera;
import krispy.mixin.InputAccessor;
import krispy.module.Category;
import krispy.module.Module;
import krispy.module.setting.BooleanSetting;
import krispy.module.setting.NumberSetting;
import krispy.module.setting.Setting;
import krispy.utils.EncryptedString;
import krispy.utils.KeyUtils;
import krispy.utils.Utils;
import net.minecraft.util.PlayerInput;
import net.minecraft.client.input.KeyInput;
import net.minecraft.client.gui.Click;
import net.minecraft.client.input.MouseInput;
import net.minecraft.util.math.Vec2f;
import net.minecraft.util.math.Vec3d;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.util.math.MathHelper;
import net.minecraft.client.option.Perspective;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.client.input.Input;
import net.minecraft.client.network.ClientPlayerEntity;
import org.joml.Vector3d;

public final class FreecamModule extends Module {
   private static final double MIN_SPEED = 0.01;
   private static final double MAX_SCROLL_SPEED = 12.0;
   private static final double ACCELERATION = 12.0;
   private static final double SCROLL_STEP = 0.25;
   private final NumberSetting speed;
   private final NumberSetting scrollSensitivity;
   private final BooleanSetting keepWalking;
   private final BooleanSetting keepJumping;
   private final BooleanSetting keepSneaking;
   public final Vector3d currentPosition;
   public final Vector3d previousPosition;
   private final Vector3d smoothedVelocity;
   private Perspective savedPerspective;
   private ClientPlayerEntity attachedPlayer;
   private ClientWorld attachedWorld;
   private boolean cameraActive;
   private boolean savedChunkCulling;
   private float savedPlayerYaw;
   private float savedPlayerPitch;
   private PlayerInput lockedInput;
   private Vec2f lockedMovementVector;
   private boolean lockedSprinting;
   private double movementSpeed;
   private long lastMovementNanos;
   public float yaw;
   public float pitch;
   public float previousYaw;
   public float previousPitch;
   private boolean isMovingForward;
   private boolean isMovingBackward;
   private boolean isMovingRight;
   private boolean isMovingLeft;
   private boolean isMovingUp;
   private boolean isMovingDown;

   public FreecamModule() {
      super((EncryptedString.of(("Freecam"))), (EncryptedString.of(("Moves the camera independently from the real player"))), (-1), (Category.MISC));
      String var37 = "Speed";
      EncryptedString var38 = EncryptedString.of(var37);
      double var52 = 0.01;
      double var6 = 50.0;
      double var8 = 1.0;
      double var10 = 0.1;
      NumberSetting var24 = new NumberSetting(var38, var52, var6, var8, var10);
      this.speed = var24;
      String var39 = "Scroll Sensitivity";
      EncryptedString var40 = EncryptedString.of(var39);
      double var54 = 0.0;
      double var69 = 5.0;
      double var71 = 1.0;
      double var73 = 0.1;
      NumberSetting var25 = new NumberSetting(var40, var54, var69, var71, var73);
      this.scrollSensitivity = var25;
      String var41 = "Keep Walking";
      EncryptedString var42 = EncryptedString.of(var41);
      boolean var56 = false;
      BooleanSetting var26 = new BooleanSetting(var42, var56);
      this.keepWalking = var26;
      String var43 = "Keep Jumping";
      EncryptedString var44 = EncryptedString.of(var43);
      boolean var57 = false;
      BooleanSetting var27 = new BooleanSetting(var44, var57);
      this.keepJumping = var27;
      String var45 = "Keep Sneaking";
      EncryptedString var46 = EncryptedString.of(var45);
      boolean var58 = false;
      BooleanSetting var28 = new BooleanSetting(var46, var58);
      this.keepSneaking = var28;
      Vector3d var29 = new Vector3d();
      this.currentPosition = var29;
      Vector3d var30 = new Vector3d();
      this.previousPosition = var30;
      Vector3d var31 = new Vector3d();
      this.smoothedVelocity = var31;
      PlayerInput var32 = PlayerInput.DEFAULT;
      this.lockedInput = var32;
      Vec2f var33 = Vec2f.ZERO;
      this.lockedMovementVector = var33;
      byte var34 = 5;
      Setting[] var35 = new Setting[var34];
      byte var47 = 0;
      NumberSetting var60 = this.speed;
      var35[var47] = var60;
      byte var48 = 1;
      NumberSetting var62 = this.scrollSensitivity;
      var35[var48] = var62;
      byte var49 = 2;
      BooleanSetting var64 = this.keepWalking;
      var35[var49] = var64;
      byte var50 = 3;
      BooleanSetting var66 = this.keepJumping;
      var35[var50] = var66;
      byte var51 = 4;
      BooleanSetting var68 = this.keepSneaking;
      var35[var51] = var68;
      this.addSettings(var35);
   }

   @Override
   public void onEnable() {
      if (this.mc.player != null && this.mc.world != null) {
         FreelookModule var1 = (FreelookModule)Krispy.INSTANCE.getModuleManager().getModuleByClass(FreelookModule.class);
         if (var1 != null && var1.isEnabled()) {
            var1.toggle(false);
         }

         this.attachedPlayer = this.mc.player;
         this.attachedWorld = this.mc.world;
         this.cameraActive = true;
         this.savedPerspective = this.mc.options.getPerspective();
         this.savedChunkCulling = this.mc.chunkCullingEnabled;
         this.mc.chunkCullingEnabled = false;
         this.savedPlayerYaw = this.mc.player.getYaw();
         this.savedPlayerPitch = this.mc.player.getPitch();
         this.yaw = this.savedPlayerYaw;
         this.pitch = this.savedPlayerPitch;
         if (this.savedPerspective == Perspective.THIRD_PERSON_FRONT) {
            this.yaw += 180.0F;
            this.pitch = -this.pitch;
         }

         Vec3d var2 = this.mc.gameRenderer.getCamera().getCameraPos();
         Utils.copyVector(this.currentPosition, var2);
         Utils.copyVector(this.previousPosition, var2);
         this.previousYaw = this.yaw;
         this.previousPitch = this.pitch;
         this.smoothedVelocity.zero();
         this.movementSpeed = this.speed.getValue();
         this.lastMovementNanos = System.nanoTime();
         this.lockedInput = this.mc.player.input.playerInput;
         this.lockedMovementVector = this.mc.player.input.getMovementInput();
         this.lockedSprinting = this.mc.player.isSprinting();
         this.isMovingForward = this.mc.options.forwardKey.isPressed();
         this.isMovingBackward = this.mc.options.backKey.isPressed();
         this.isMovingRight = this.mc.options.rightKey.isPressed();
         this.isMovingLeft = this.mc.options.leftKey.isPressed();
         this.isMovingUp = this.mc.options.jumpKey.isPressed();
         this.isMovingDown = this.mc.options.sneakKey.isPressed();
         this.resetMovementKeys();
         super.onEnable();
      } else {
         this.toggle(false);
      }
   }

   @Override
   public void onDisable() {
      if (this.cameraActive) {
         this.cameraActive = false;
         this.clearCameraInput();
         if (this.savedPerspective != null) {
            this.mc.options.setPerspective(this.savedPerspective);
         }

         this.mc.chunkCullingEnabled = this.savedChunkCulling;
         if (this.mc.player != null && this.mc.player == this.attachedPlayer) {
            this.mc.player.input.playerInput = PlayerInput.DEFAULT;
            ((InputAccessor)this.mc.player.input).krispy$setMovementVector(Vec2f.ZERO);
            this.mc.player.setSneaking(false);
         }

         this.lockedInput = PlayerInput.DEFAULT;
         this.lockedMovementVector = Vec2f.ZERO;
         this.lockedSprinting = false;
         this.attachedPlayer = null;
         this.attachedWorld = null;
         this.savedPerspective = null;
         this.previousPosition.set(this.currentPosition);
         this.previousYaw = this.yaw;
         this.previousPitch = this.pitch;
         KeyBinding.updatePressedStates();
         super.onDisable();
      }
   }

   private void resetMovementKeys() {
      this.mc.options.forwardKey.setPressed(false);
      this.mc.options.backKey.setPressed(false);
      this.mc.options.rightKey.setPressed(false);
      this.mc.options.leftKey.setPressed(false);
      this.mc.options.jumpKey.setPressed(false);
      this.mc.options.sneakKey.setPressed(false);
   }

   private void clearCameraInput() {
      this.isMovingForward = this.isMovingBackward = this.isMovingRight = this.isMovingLeft = false;
      this.isMovingUp = this.isMovingDown = false;
      this.smoothedVelocity.zero();
   }

   @EventListener
   private void handleSetScreenEvent(SetScreenEvent var1) {
      this.clearCameraInput();
      this.resetMovementKeys();
   }

   @EventListener
   private void handleTickEvent(TickEvent var1) {
      if (this.mc.player == this.attachedPlayer && this.mc.world == this.attachedWorld && this.mc.player != null && this.mc.world != null) {
         if (!this.mc.options.getPerspective().isFirstPerson()) {
            this.mc.options.setPerspective(Perspective.FIRST_PERSON);
         }
      } else {
         this.toggle(false);
      }
   }

   public void applyContinuedPlayerInput(Input var1) {
      if (this.isEnabled()
         && this.cameraActive
         && this.mc.player == this.attachedPlayer
         && this.mc.world == this.attachedWorld
         && var1 == this.mc.player.input
         && !CinematicCamera.inputLocked()) {
         PlayerInput var2 = continuedInput(
            this.lockedInput, this.keepWalking.getValue(), this.keepJumping.getValue(), this.keepSneaking.getValue(), this.lockedSprinting
         );
         var1.playerInput = var2;
         ((InputAccessor)var1).krispy$setMovementVector(this.keepWalking.getValue() ? this.lockedMovementVector : Vec2f.ZERO);
         this.mc.player.setSprinting(var2.sprint());
         this.mc.player.setSneaking(var2.sneak());
      }
   }

   static PlayerInput continuedInput(PlayerInput var0, boolean var1, boolean var2, boolean var3, boolean var4) {
      return new PlayerInput(
         var1 && var0.forward(),
         var1 && var0.backward(),
         var1 && var0.left(),
         var1 && var0.right(),
         var2 && var0.jump(),
         var3 & var0.sneak(),
         var1 && var4 && !(var3 & var0.sneak())
      );
   }

   public void updateCameraMovement() {
      if (this.isEnabled() && this.cameraActive && this.mc.player == this.attachedPlayer && this.mc.world == this.attachedWorld) {
         if (this.mc.currentScreen != null || CinematicCamera.inputLocked()) {
            this.clearCameraInput();
            this.lastMovementNanos = System.nanoTime();
            this.previousPosition.set(this.currentPosition);
            return;
         }

         this.previousPosition.set(this.currentPosition);
         this.previousYaw = this.yaw;
         this.previousPitch = this.pitch;
         long var1 = System.nanoTime();
         double var3 = MathHelper.clamp((double)(var1 - this.lastMovementNanos) / 1.0E9, 0.001, 0.1);
         this.lastMovementNanos = var1;
         double var5 = Math.toRadians((double)this.yaw);
         double var7 = -Math.sin(var5);
         double var9 = Math.cos(var5);
         double var11 = -Math.cos(var5);
         double var13 = -Math.sin(var5);
         double var15 = MathHelper.clamp(this.movementSpeed, 0.01, 12.0) * 4.0;
         if (this.mc.options.sprintKey.isPressed()) {
            var15 *= 2.0;
         }

         double var17 = 0.0;
         double var19 = 0.0;
         double var21 = 0.0;
         if (this.isMovingForward) {
            var17 += var7 * var15;
            var21 += var9 * var15;
         }

         if (this.isMovingBackward) {
            var17 -= var7 * var15;
            var21 -= var9 * var15;
         }

         if (this.isMovingRight) {
            var17 += var11 * var15;
            var21 += var13 * var15;
         }

         if (this.isMovingLeft) {
            var17 -= var11 * var15;
            var21 -= var13 * var15;
         }

         if (this.isMovingUp) {
            var19 += var15;
         }

         if (this.isMovingDown) {
            var19 -= var15;
         }

         double var23 = 1.0 - Math.exp(-12.0 * var3);
         this.smoothedVelocity.x = MathHelper.lerp(var23, this.smoothedVelocity.x, var17);
         this.smoothedVelocity.y = MathHelper.lerp(var23, this.smoothedVelocity.y, var19);
         this.smoothedVelocity.z = MathHelper.lerp(var23, this.smoothedVelocity.z, var21);
         this.currentPosition.add(this.smoothedVelocity.x * var3, this.smoothedVelocity.y * var3, this.smoothedVelocity.z * var3);
      }
   }

   @EventListener
   private void onKey(KeyEvent var1) {
      if (this.mc.currentScreen == null && !CinematicCamera.inputLocked() && !KeyUtils.isKeyPressed(292)) {
         boolean var2 = true;
         KeyInput var3 = new KeyInput(var1.key, 0, 0);
         if (this.mc.options.forwardKey.matchesKey(var3)) {
            this.isMovingForward = var1.mode != 0;
         } else if (this.mc.options.backKey.matchesKey(var3)) {
            this.isMovingBackward = var1.mode != 0;
         } else if (this.mc.options.rightKey.matchesKey(var3)) {
            this.isMovingRight = var1.mode != 0;
         } else if (this.mc.options.leftKey.matchesKey(var3)) {
            this.isMovingLeft = var1.mode != 0;
         } else if (this.mc.options.jumpKey.matchesKey(var3)) {
            this.isMovingUp = var1.mode != 0;
         } else if (this.mc.options.sneakKey.matchesKey(var3)) {
            this.isMovingDown = var1.mode != 0;
         } else {
            var2 = false;
         }

         if (var2) {
            this.resetMovementKeys();
            var1.cancel();
         }
      }
   }

   @EventListener
   private void handleMouseButtonEvent(MouseButtonEvent var1) {
      if (this.mc.currentScreen == null && !CinematicCamera.inputLocked()) {
         boolean var2 = true;
         Click var3 = new Click(0.0, 0.0, new MouseInput(var1.button, 0));
         if (this.mc.options.forwardKey.matchesMouse(var3)) {
            this.isMovingForward = var1.actions != 0;
         } else if (this.mc.options.backKey.matchesMouse(var3)) {
            this.isMovingBackward = var1.actions != 0;
         } else if (this.mc.options.rightKey.matchesMouse(var3)) {
            this.isMovingRight = var1.actions != 0;
         } else if (this.mc.options.leftKey.matchesMouse(var3)) {
            this.isMovingLeft = var1.actions != 0;
         } else if (this.mc.options.jumpKey.matchesMouse(var3)) {
            this.isMovingUp = var1.actions != 0;
         } else if (this.mc.options.sneakKey.matchesMouse(var3)) {
            this.isMovingDown = var1.actions != 0;
         } else {
            var2 = false;
         }

         if (var2) {
            this.resetMovementKeys();
            var1.cancel();
         }
      }
   }

   @EventListener
   private void handleMouseScrolledEvent(MouseScrolledEvent var1) {
      if (this.mc.currentScreen == null && var1.amount != 0.0) {
         double var2 = this.scrollSensitivity.getValue();
         if (var2 > 0.0) {
            double var4 = MathHelper.clamp(Math.abs(var1.amount), 0.25, 8.0);
            double var6 = Math.pow(1.0 + 0.25 * var2, var4);
            this.movementSpeed = var1.amount > 0.0
               ? MathHelper.clamp(this.movementSpeed * var6, 0.01, 12.0)
               : MathHelper.clamp(this.movementSpeed / var6, 0.01, 12.0);
         }

         var1.cancel();
      }
   }

   @EventListener
   private void handleChunkMarkClosedEvent(ChunkMarkClosedEvent var1) {
      var1.cancel();
   }

   public void updateRotation(double var1, double var3) {
      this.previousYaw = this.yaw;
      this.previousPitch = this.pitch;
      this.yaw = MathHelper.wrapDegrees(this.yaw + (float)var1);
      this.pitch = MathHelper.clamp(this.pitch + (float)var3, -90.0F, 90.0F);
   }

   public double getInterpolatedX(float var1) {
      return MathHelper.lerp((double)var1, this.previousPosition.x, this.currentPosition.x);
   }

   public double getInterpolatedY(float var1) {
      return MathHelper.lerp((double)var1, this.previousPosition.y, this.currentPosition.y);
   }

   public double getInterpolatedZ(float var1) {
      return MathHelper.lerp((double)var1, this.previousPosition.z, this.currentPosition.z);
   }

   public double getInterpolatedYaw(float var1) {
      return (double)MathHelper.lerp(var1, this.previousYaw, this.yaw);
   }

   public double getInterpolatedPitch(float var1) {
      return (double)MathHelper.lerp(var1, this.previousPitch, this.pitch);
   }







}
