package krispy.feature;

import it.unimi.dsi.fastutil.ints.IntArrayList;
import it.unimi.dsi.fastutil.longs.Long2LongOpenHashMap;
import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.longs.LongArrayList;
import it.unimi.dsi.fastutil.longs.LongIterator;
import it.unimi.dsi.fastutil.longs.LongLinkedOpenHashSet;
import it.unimi.dsi.fastutil.longs.LongListIterator;
import it.unimi.dsi.fastutil.longs.LongOpenHashSet;
import it.unimi.dsi.fastutil.longs.Long2LongMap.Entry;
import it.unimi.dsi.fastutil.objects.ObjectIterator;
import java.util.Arrays;
import java.util.BitSet;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.BooleanSupplier;
import krispy.module.ext.ClientModule;
import krispy.module.ext.EventHandler;
import krispy.module.ext.ModuleCategory;
import krispy.module.ext.Stage;
import krispy.module.ext.event.BlockUpdateEvent;
import krispy.module.ext.event.PacketReceiveNettyEvent;
import krispy.module.ext.event.Render3DEvent;
import krispy.module.ext.event.TickEvent;
import krispy.module.ext.setting.BooleanSetting;
import krispy.module.ext.setting.ColorSetting;
import krispy.utils.ext.ChunkAreas;
import krispy.utils.ext.ChunkOverlay;
import krispy.utils.ext.LevelUtil;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.AbstractPressurePlateBlock;
import net.minecraft.block.AbstractRedstoneGateBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.ButtonBlock;
import net.minecraft.block.CaveVines;
import net.minecraft.block.CrafterBlock;
import net.minecraft.block.DaylightDetectorBlock;
import net.minecraft.block.DispenserBlock;
import net.minecraft.block.HopperBlock;
import net.minecraft.block.LeverBlock;
import net.minecraft.block.NoteBlock;
import net.minecraft.block.ObserverBlock;
import net.minecraft.block.PistonBlock;
import net.minecraft.block.PistonExtensionBlock;
import net.minecraft.block.PistonHeadBlock;
import net.minecraft.block.RedstoneBlock;
import net.minecraft.block.RedstoneLampBlock;
import net.minecraft.block.RedstoneTorchBlock;
import net.minecraft.block.RedstoneWireBlock;
import net.minecraft.block.TargetBlock;
import net.minecraft.block.TripwireHookBlock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.toast.Toast;
import net.minecraft.client.toast.ToastManager;
import net.minecraft.client.world.ClientChunkManager;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.s2c.play.ChunkDataS2CPacket;
import net.minecraft.network.packet.s2c.play.GameJoinS2CPacket;
import net.minecraft.network.packet.s2c.play.LightData;
import net.minecraft.network.packet.s2c.play.LightUpdateS2CPacket;
import net.minecraft.text.Text;
import net.minecraft.util.Util;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.ChunkSectionPos;
import net.minecraft.util.math.ColorHelper;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.BlockPos.Mutable;
import net.minecraft.world.LightType;
import net.minecraft.world.chunk.ChunkNibbleArray;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.world.chunk.ChunkStatus;
import net.minecraft.world.chunk.WorldChunk;
import net.minecraft.world.chunk.light.ChunkLightingView;

@Environment(EnvType.CLIENT)
public final class PrimeChunkFinderModule extends ClientModule {
   private static final int SECTION_BYTES = 2048;
   private static final int MAX_FLAGGED_CHUNKS = 256;
   private static final int AMETHYST_MAX_LIGHT = 5;
   private static final int AMETHYST_REACH = 5;
   private static final long REDSTONE_NOTIFY_COOLDOWN_MS = 15000L;
   private static final int ORE_LIGHT = 9;
   private static final long[] NO_ORES = new long[0];
   private static final int LAMP_LIGHT = 14;
   private static final int[] NO_LAMPS = new int[0];
   private static final long GONE_LAMP_MS = 5000L;
   private static final int MAX_TRACKED_CHUNKS = 5000;
   private static final int SNAPSHOT_RADIUS = 32;
   private static final byte[] ZERO_SECTION = new byte[2048];
   private static final double MAX_Y = 0.0;
   private final ColorSetting chunkColor;
   private final BooleanSetting tracers;
   private final BooleanSetting sound;
   private final LinkedHashMap<Long, Map<Integer, byte[]>> chunkLight;
   private final LongOpenHashSet passedChunks;
   private final LongLinkedOpenHashSet flaggedChunks;
   private final LongOpenHashSet shownChunks;
   private final ChunkAreas chunkAreas;
   private final LongOpenHashSet checkedSections;
   private final LongOpenHashSet amethystSections;
   private final Long2ObjectOpenHashMap<long[]> oreSections;
   private final Long2ObjectOpenHashMap<int[]> lampSections;
   private final Long2LongOpenHashMap goneLamps;
   private final Mutable cursor;
   private final Long2LongOpenHashMap redstoneNotified;

   public PrimeChunkFinderModule() {
      super("prime-chunk-finder", "Prime Chunk Finder", "Flags chunks with light and redstone changes below Y 0.", ModuleCategory.BASE_RAID);
      String var56 = "chunk-color";
      String var6 = "Chunk Color";
      ColorSetting var60 = new ColorSetting(var6, 1342242650);
      ColorSetting var33 = (ColorSetting)this.addSetting(var56, var60);
      this.chunkColor = var33;
      String var57 = "tracers";
      String var65 = "Tracers";
      BooleanSetting var61 = new BooleanSetting(var65, true);
      BooleanSetting var36 = (BooleanSetting)this.addSetting(var57, var61);
      this.tracers = var36;
      String var58 = "sound";
      String var66 = "Sound";
      BooleanSetting var62 = new BooleanSetting(var66, true);
      BooleanSetting var39 = (BooleanSetting)this.addSetting(var58, var62);
      this.sound = var39;
      LinkedHashMap var40 = new LinkedHashMap(256, 0.75F, true);
      this.chunkLight = var40;
      LongOpenHashSet var41 = new LongOpenHashSet();
      this.passedChunks = var41;
      LongLinkedOpenHashSet var42 = new LongLinkedOpenHashSet();
      this.flaggedChunks = var42;
      LongOpenHashSet var43 = new LongOpenHashSet();
      this.shownChunks = var43;
      ChunkAreas var44 = new ChunkAreas();
      this.chunkAreas = var44;
      LongOpenHashSet var45 = new LongOpenHashSet();
      this.checkedSections = var45;
      LongOpenHashSet var46 = new LongOpenHashSet();
      this.amethystSections = var46;
      Long2ObjectOpenHashMap var47 = new Long2ObjectOpenHashMap();
      this.oreSections = var47;
      Long2ObjectOpenHashMap var48 = new Long2ObjectOpenHashMap();
      this.lampSections = var48;
      Long2LongOpenHashMap var49 = new Long2LongOpenHashMap();
      this.goneLamps = var49;
      Mutable var50 = new Mutable();
      this.cursor = var50;
      Long2LongOpenHashMap var51 = new Long2LongOpenHashMap();
      this.redstoneNotified = var51;
      BooleanSetting var25 = this.usesNotifications();
      BooleanSetting var27 = this.sound;
      BooleanSupplier var53 = var25::get;
      var27.visibleWhen(var53);
      this.redstoneNotified.defaultReturnValue(-4611686018427387904L);
   }

   public boolean persistEnabled() {
      return false;
   }

   public void onEnable() {
      MinecraftClient var1 = MinecraftClient.getInstance();
      if (var1.player != null
         && var1.world != null
         && !(var1.player.getY() >= 0.0)) {
         this.reset();
         this.snapshotLoadedChunks();
         this.on(PacketReceiveNettyEvent.TYPE, this::onPacket);
      } else {
         warnDeepslateOnly(var1);
         this.requestDisable();
      }
   }

   public void onDisable() {
      this.reset();
   }

   private static void warnDeepslateOnly(MinecraftClient var0) {
      ToastManager var1 = var0.getToastManager();
      if (var1.getToast(PrimeChunkToast.class, Toast.TYPE) == null) {
         var1.add(new PrimeChunkToast());
      }
   }

   private void onPacket(PacketReceiveNettyEvent var1) {
      MinecraftClient var2 = MinecraftClient.getInstance();
      if (var1.packet instanceof GameJoinS2CPacket) {
         var2.execute(() -> {
            if (this.isEnabled()) {
               this.reset();
            }
         });
      } else {
         Packet var10 = var1.packet;
         if (var1.packet instanceof ChunkDataS2CPacket) {
            ChunkDataS2CPacket var3;
            int var8 = (var3 = (ChunkDataS2CPacket)var10).getChunkX();
            int var6 = var3.getChunkZ();
            LightData var7 = var3.getLightData();
            var2.execute(() -> {
               if (this.isEnabled() && var2.world != null) {
                  this.baselineChunk(var8, var6, var7);
               }
            });
         } else {
            var10 = var1.packet;
            if (var1.packet instanceof LightUpdateS2CPacket) {
               LightUpdateS2CPacket var4;
               int var10x = (var4 = (LightUpdateS2CPacket)var10).getChunkX();
               int var11 = var4.getChunkZ();
               LightData var12 = var4.getData();
               var2.execute(() -> {
                  if (this.isEnabled() && var2.world != null) {
                     this.detectChanges(var10x, var11, var12);
                  }
               });
            }
         }
      }
   }

   @EventHandler
   public void onBlockUpdate(BlockUpdateEvent var1) {
      if (var1.oldState != var1.newState && MinecraftClient.getInstance().world != null) {
         this.rememberGoneLamp(var1.pos, var1.oldState, var1.newState);
         this.detectRedstone(var1.pos, var1.oldState, var1.newState);
      }
   }

   @EventHandler(
      stage = Stage.POST
   )
   public void onTick(TickEvent var1) {
      MinecraftClient var2 = MinecraftClient.getInstance();
      if (var2.world == null) {
         this.reset();
      } else {
         if (var2.player != null && var2.player.getY() < 0.0) {
            this.passedChunks.add(var2.player.getChunkPos().toLong());
         }

         this.forgetOldLamps();
         this.refreshShown(var2.world);
      }
   }

   private void refreshShown(ClientWorld var1) {
      this.shownChunks.clear();
      LongListIterator var2 = this.flaggedChunks.iterator();

      while (var2.hasNext()) {
         long var3 = var2.next();
         if (LevelUtil.isLoaded(var1, ChunkPos.getPackedX(var3), ChunkPos.getPackedZ(var3))) {
            this.shownChunks.add(var3);
         }
      }
   }

   @EventHandler
   public void onRender3D(Render3DEvent var1) {
      if (!this.shownChunks.isEmpty() && MinecraftClient.getInstance().world != null) {
         int var2 = this.chunkColor.argb();
         ChunkOverlay.draw(this.shownChunks, var2, var1.partialTick);
         if (this.tracers.get()) {
            this.chunkAreas
               .drawTracers(
                  this.shownChunks, 63.0, ColorHelper.fullAlpha(var2)
               );
         }
      }
   }

   private void flagChunk(long var1) {
      this.flaggedChunks.addAndMoveToLast(var1);
      this.shownChunks.add(var1);

      while (this.flaggedChunks.size() > (256)) {
         this.flaggedChunks.removeFirstLong();
      }
   }

   private void snapshotLoadedChunks() {
      MinecraftClient var1 = MinecraftClient.getInstance();
      if (var1.world != null && var1.player != null) {
         int var2 = var1.player.getBlockX() >> (4);
         int var3 = var1.player.getBlockZ() >> (4);

         for (int var4 = var2 - (32); var4 <= var2 + (32); var4++) {
            for (int var5 = var3 - (32); var5 <= var3 + (32); var5++) {
               Map var6 = this.snapshotChunk(var4, var5);
               if (var6 != null) {
                  this.chunkLight.put(Long.valueOf(ChunkPos.toLong(var4, var5)), var6);
               }
            }
         }

         this.trimChunkCache();
      }
   }

   private Map<Integer, byte[]> snapshotChunk(int var1, int var2) {
      ClientWorld var3 = MinecraftClient.getInstance().world;
      if (var3 == null) {
         return null;
      } else {
         ClientChunkManager var4 = var3.getChunkManager();
         if (!var4.isChunkLoaded(var1, var2)) {
            return null;
         } else {
            ChunkLightingView var5 = var4.getLightingProvider().get(LightType.BLOCK);
            Map var6 = this.createZeroedChunk();

            for (int var7 = this.bottomSection(); var7 <= this.topSection(); var7++) {
               ChunkNibbleArray var8 = var5.getLightSection(ChunkSectionPos.from(var1, var7, var2));
               if (var8 != null && !var8.isUninitialized(0)) {
                  var6.put(var7, Arrays.copyOf(var8.asByteArray(), 2048));
               }
            }

            return var6;
         }
      }
   }

   private void baselineChunk(int var1, int var2, LightData var3) {
      Map var4 = this.createZeroedChunk();
      this.applyInitializedSections(var3, var4, var1, var2, false, null);
      this.applyUninitializedSections(var3, var4, var1, var2, false, null);
      this.chunkLight.put(Long.valueOf(ChunkPos.toLong(var1, var2)), var4);
      this.trimChunkCache();
   }

   private void detectChanges(int var1, int var2, LightData var3) {
      long var4 = ChunkPos.toLong(var1, var2);
      this.checkedSections.clear();
      this.amethystSections.clear();
      this.oreSections.clear();
      this.lampSections.clear();
      Map var6 = this.chunkLight.get(var4);
      if (var6 == null) {
         var6 = this.snapshotChunk(var1, var2);
      }

      int var7 = var6 != null && !this.isOwnChunk(var4) ? 1 : 0;
      if (var6 == null) {
         var6 = this.createZeroedChunk();
      }

      PrimeChunkFinderModule.BlockChange var8 = new PrimeChunkFinderModule.BlockChange();
      this.applyInitializedSections(var3, var6, var1, var2, (var7 != 0), var8);
      this.applyUninitializedSections(var3, var6, var1, var2, (var7 != 0), var8);
      this.chunkLight.put(Long.valueOf(var4), var6);
      this.trimChunkCache();
      if (var8.count != 0) {
         this.flagChunk(var4);
         if (this.notificationsOn()) {
            StackedNotificationToast.addOrUpdate(
               new ItemStack(Items.EMERALD_BLOCK), this.name(), Text.literal(var8.x + ", " + var8.y + ", " + var8.z), this.sound.get()
            );
         }
      }
   }

   private void rememberGoneLamp(BlockPos var1, BlockState var2, BlockState var3) {
      if (isLamp(var2)) {
         int var4 = var2.getLuminance();
         if (!isLamp(var3) || var3.getLuminance() < var4) {
            this.goneLamps
               .put(var1.asLong(), Util.getMeasuringTimeMs() + (5000L) << (4) | (long)var4);
         }
      }
   }

   private void forgetOldLamps() {
      if (!this.goneLamps.isEmpty()) {
         long var1 = Util.getMeasuringTimeMs();
         LongIterator var3 = this.goneLamps.values().iterator();

         while (var3.hasNext()) {
            if (var3.nextLong() >>> (4) < var1) {
               var3.remove();
            }
         }
      }
   }

   private void detectRedstone(BlockPos var1, BlockState var2, BlockState var3) {
      if (!((double)var1.getY() >= 0.0)
         && (isRedstone(var3) || isRedstone(var2))) {
         long var4 = ChunkPos.toLong(var1.getX() >> (4), var1.getZ() >> (4));
         if (!this.isOwnChunk(var4)) {
            this.flagChunk(var4);
            long var6 = Util.getMeasuringTimeMs();
            if (this.notificationsOn() && var6 - this.redstoneNotified.get(var4) >= (15000L)) {
               this.redstoneNotified.put(var4, var6);
               StackedNotificationToast.addOrUpdate(
                  new ItemStack(Items.REDSTONE),
                  this.name(),
                  Text.literal("Redstone " + var1.getX() + ", " + var1.getY() + ", " + var1.getZ()),
                  this.sound.get()
               );
            }
         }
      }
   }

   private static boolean isRedstone(BlockState var0) {
      Block var1 = var0.getBlock();
      return ((!(!(var1 instanceof RedstoneWireBlock)
            && !(var1 instanceof AbstractRedstoneGateBlock)
            && !(var1 instanceof RedstoneTorchBlock)
            && !(var1 instanceof RedstoneLampBlock)
            && !(var1 instanceof ObserverBlock)
            && !(var1 instanceof PistonBlock)
            && !(var1 instanceof PistonHeadBlock)
            && !(var1 instanceof PistonExtensionBlock)
            && !(var1 instanceof DispenserBlock)
            && !(var1 instanceof HopperBlock)
            && !(var1 instanceof NoteBlock)
            && !(var1 instanceof DaylightDetectorBlock)
            && !(var1 instanceof LeverBlock)
            && !(var1 instanceof ButtonBlock)
            && !(var1 instanceof AbstractPressurePlateBlock)
            && !(var1 instanceof TripwireHookBlock)
            && !(var1 instanceof TargetBlock)
            && !(var1 instanceof CrafterBlock)
            && !(var1 instanceof RedstoneBlock))));
   }

   private boolean isOwnChunk(long var1) {
      if (this.passedChunks.contains(var1)) {
         return true;
      } else {
         MinecraftClient var3 = MinecraftClient.getInstance();
         return ((var3.player != null && var3.player.getChunkPos().toLong() == var1));
      }
   }

   private void applyInitializedSections(LightData var1, Map<Integer, byte[]> var2, int var3, int var4, boolean var5, PrimeChunkFinderModule.BlockChange var6) {
      BitSet var7 = var1.getInitedBlock();
      List var8 = var1.getBlockNibbles();
      int var9 = 0;

      for (int var10 = var7.nextSetBit(0); var10 >= 0 && var9 < var8.size(); var10 = var7.nextSetBit(var10 + (1))) {
         byte[] var11 = (byte[])var8.get(var9++);
         int var12 = this.lightSectionY(var10);
         if (this.isWorldSection(var12) && var11.length == (2048)) {
            this.updateSection(var2, var3, var4, var12, Arrays.copyOf(var11, 2048), var5, var6);
         }
      }
   }

   private void applyUninitializedSections(LightData var1, Map<Integer, byte[]> var2, int var3, int var4, boolean var5, PrimeChunkFinderModule.BlockChange var6) {
      BitSet var7 = var1.getUninitedBlock();

      for (int var8 = var7.nextSetBit(0); var8 >= 0; var8 = var7.nextSetBit(var8 + (1))) {
         int var9 = this.lightSectionY(var8);
         if (this.isWorldSection(var9)) {
            this.updateSection(var2, var3, var4, var9, ZERO_SECTION, var5, var6);
         }
      }
   }

   private void updateSection(Map<Integer, byte[]> var1, int var2, int var3, int var4, byte[] var5, boolean var6, PrimeChunkFinderModule.BlockChange var7) {
      byte[] var8 = (byte[])var1.get(var4);
      if (var6 && var8 != null && var7 != null) {
         this.compareSection(var8, var5, var2, var3, var4, var7);
      }

      var1.put(var4, var5);
   }

   private void compareSection(byte[] var1, byte[] var2, int var3, int var4, int var5, PrimeChunkFinderModule.BlockChange var6) {
      for (int var7 = 0; var7 < (2048); var7++) {
         int var8 = var1[var7] & (255);
         int var9 = var2[var7] & (255);
         int var10 = var8 ^ var9;
         if ((var10 & (15)) != 0) {
            this.recordChange(
               var3, var4, var5, var7 << (1), var8 & (15), var9 & (15), var6
            );
         }

         if ((var10 & (240)) != 0) {
            this.recordChange(
               var3,
               var4,
               var5,
               (var7 << (1)) + (1),
               var8 >>> (4) & (15),
               var9 >>> (4) & (15),
               var6
            );
         }
      }
   }

   private void recordChange(int var1, int var2, int var3, int var4, int var5, int var6, PrimeChunkFinderModule.BlockChange var7) {
      int var8 = (var1 << (4)) + (var4 & (15));
      int var9 = (var3 << (4)) + (var4 >>> (8) & (15));
      int var10 = (var2 << (4)) + (var4 >>> (4) & (15));
      int var11 = Math.max(var5, var6);
      if (!this.fromAmethyst(var8, var9, var10, var5, var6)
         && !this.fromRedstoneOre(var8, var9, var10, var11)
         && !this.fromLamp(var8, var9, var10, var11)) {
         var7.add(var8, var9, var10, var5, var6);
      }
   }

   private boolean fromLamp(int var1, int var2, int var3, int var4) {
      if (var4 > (14)) {
         return false;
      } else {
         ClientWorld var5 = MinecraftClient.getInstance().world;
         if (var5 == null) {
            return false;
         } else {
            int var6 = (14) - var4;

            for (int var7 = var1 - var6 >> (4); var7 <= var1 + var6 >> (4); var7++) {
               for (int var8 = var2 - var6 >> (4); var8 <= var2 + var6 >> (4); var8++) {
                  for (int var9 = var3 - var6 >> (4); var9 <= var3 + var6 >> (4); var9++) {
                     int[] var10 = this.lamps(var5, var7, var8, var9);
                     int var11 = var10.length;

                     for (int var12 = 0; var12 < var11; var12++) {
                        int var13 = var10[var12];
                        int var14 = var13 >>> (4);
                        int var15 = (var7 << (4)) + (var14 & (15));
                        int var16 = (var8 << (4)) + (var14 >>> (8));
                        int var17 = (var9 << (4)) + (var14 >>> (4) & (15));
                        if (Math.abs(var15 - var1) + Math.abs(var16 - var2) + Math.abs(var17 - var3) <= (var13 & (15)) - var4) {
                           return true;
                        }
                     }
                  }
               }
            }

            long var18 = Util.getMeasuringTimeMs();
            ObjectIterator var19 = this.goneLamps.long2LongEntrySet().iterator();

            while (var19.hasNext()) {
               Entry var20 = (Entry)var19.next();
               long var21 = var20.getLongValue();
               if (var21 >>> (4) >= var18) {
                  long var22 = var20.getLongKey();
                  int var23 = Math.abs(BlockPos.unpackLongX(var22) - var1)
                     + Math.abs(BlockPos.unpackLongY(var22) - var2)
                     + Math.abs(BlockPos.unpackLongZ(var22) - var3);
                  if (var23 <= (int)(var21 & (15L)) - var4) {
                     return true;
                  }
               }
            }

            return false;
         }
      }
   }

   private int[] lamps(ClientWorld var1, int var2, int var3, int var4) {
      long var5 = ChunkSectionPos.asLong(var2, var3, var4);
      int[] var7 = (int[])this.lampSections.get(var5);
      if (var7 != null) {
         return var7;
      } else {
         int[] var8 = scanLamps(var1, var2, var3, var4);
         this.lampSections.put(var5, var8);
         return var8;
      }
   }

   private static int[] scanLamps(ClientWorld var0, int var1, int var2, int var3) {
      if (var2 >= var0.getBottomSectionCoord() && var2 <= var0.getTopSectionCoord()) {
         WorldChunk var4 = var0.getChunkManager().getChunk(var1, var3, ChunkStatus.FULL, false);
         if (var4 == null) {
            return NO_LAMPS;
         } else {
            ChunkSection var5 = var4.getSection(var4.sectionCoordToIndex(var2));
            if (!var5.isEmpty() && var5.getBlockStateContainer().hasAny(PrimeChunkFinderModule::isLamp)) {
               IntArrayList var6 = new IntArrayList();

               for (int var7 = 0; var7 < (4096); var7++) {
                  BlockState var8 = var5.getBlockState(
                     var7 & (15), var7 >>> (8), var7 >>> (4) & (15)
                  );
                  if (isLamp(var8)) {
                     var6.add(var7 << (4) | var8.getLuminance());
                  }
               }

               return var6.isEmpty() ? NO_LAMPS : var6.toIntArray();
            } else {
               return NO_LAMPS;
            }
         }
      } else {
         return NO_LAMPS;
      }
   }

   private static boolean isLamp(BlockState var0) {
      return ((!(!var0.isOf(Blocks.TORCH)
            && !var0.isOf(Blocks.WALL_TORCH)
            && !var0.isOf(Blocks.SOUL_TORCH)
            && !var0.isOf(Blocks.SOUL_WALL_TORCH)
            && !var0.isOf(Blocks.COPPER_TORCH)
            && !var0.isOf(Blocks.COPPER_WALL_TORCH)
            && !CaveVines.hasBerries(var0))));
   }

   private boolean fromAmethyst(int var1, int var2, int var3, int var4, int var5) {
      if (Math.max(var4, var5) > (5)) {
         return false;
      } else {
         ClientWorld var6 = MinecraftClient.getInstance().world;
         if (var6 != null && this.amethystSectionNear(var6, var1, var2, var3)) {
            for (int var7 = -5; var7 <= (5); var7++) {
               int var8 = (5) - Math.abs(var7);

               for (int var9 = -var8; var9 <= var8; var9++) {
                  int var10 = var8 - Math.abs(var9);

                  for (int var11 = -var10; var11 <= var10; var11++) {
                     if (isAmethyst(var6.getBlockState(this.cursor.set(var1 + var7, var2 + var9, var3 + var11)))) {
                        return true;
                     }
                  }
               }
            }

            return false;
         } else {
            return false;
         }
      }
   }

   private boolean amethystSectionNear(ClientWorld var1, int var2, int var3, int var4) {
      for (int var5 = var2 - (5) >> (4); var5 <= var2 + (5) >> (4); var5++) {
         for (int var6 = var3 - (5) >> (4);
            var6 <= var3 + (5) >> (4);
            var6++
         ) {
            for (int var7 = var4 - (5) >> (4);
               var7 <= var4 + (5) >> (4);
               var7++
            ) {
               long var8 = ChunkSectionPos.asLong(var5, var6, var7);
               if (this.checkedSections.add(var8) && sectionHasAmethyst(var1, var5, var6, var7)) {
                  this.amethystSections.add(var8);
               }

               if (this.amethystSections.contains(var8)) {
                  return true;
               }
            }
         }
      }

      return false;
   }

   private static boolean sectionHasAmethyst(ClientWorld var0, int var1, int var2, int var3) {
      if (var2 >= var0.getBottomSectionCoord() && var2 <= var0.getTopSectionCoord()) {
         WorldChunk var4 = var0.getChunkManager().getChunk(var1, var3, ChunkStatus.FULL, false);
         if (var4 == null) {
            return false;
         } else {
            ChunkSection var5 = var4.getSection(var4.sectionCoordToIndex(var2));
            return ((!var5.isEmpty() && var5.getBlockStateContainer().hasAny(PrimeChunkFinderModule::isAmethyst)));
         }
      } else {
         return false;
      }
   }

   private boolean fromRedstoneOre(int var1, int var2, int var3, int var4) {
      if (var4 > (9)) {
         return false;
      } else {
         ClientWorld var5 = MinecraftClient.getInstance().world;
         if (var5 == null) {
            return false;
         } else {
            int var6 = (9) - var4;

            for (int var7 = var1 - var6 >> (4); var7 <= var1 + var6 >> (4); var7++) {
               for (int var8 = var2 - var6 >> (4); var8 <= var2 + var6 >> (4); var8++) {
                  for (int var9 = var3 - var6 >> (4); var9 <= var3 + var6 >> (4); var9++) {
                     long[] var10 = this.exposedOres(var5, var7, var8, var9);
                     int var11 = var10.length;

                     for (int var12 = 0; var12 < var11; var12++) {
                        long var13 = var10[var12];
                        int var15 = Math.abs(BlockPos.unpackLongX(var13) - var1)
                           + Math.abs(BlockPos.unpackLongY(var13) - var2)
                           + Math.abs(BlockPos.unpackLongZ(var13) - var3);
                        if (var15 <= var6) {
                           return true;
                        }
                     }
                  }
               }
            }

            return false;
         }
      }
   }

   private long[] exposedOres(ClientWorld var1, int var2, int var3, int var4) {
      long var5 = ChunkSectionPos.asLong(var2, var3, var4);
      long[] var7 = (long[])this.oreSections.get(var5);
      if (var7 != null) {
         return var7;
      } else {
         long[] var8 = this.scanExposedOres(var1, var2, var3, var4);
         this.oreSections.put(var5, var8);
         return var8;
      }
   }

   private long[] scanExposedOres(ClientWorld var1, int var2, int var3, int var4) {
      if (var3 >= var1.getBottomSectionCoord() && var3 <= var1.getTopSectionCoord()) {
         WorldChunk var5 = var1.getChunkManager().getChunk(var2, var4, ChunkStatus.FULL, false);
         if (var5 == null) {
            return NO_ORES;
         } else {
            ChunkSection var6 = var5.getSection(var5.sectionCoordToIndex(var3));
            if (!var6.isEmpty() && var6.getBlockStateContainer().hasAny(PrimeChunkFinderModule::isRedstoneOre)) {
               LongArrayList var7 = new LongArrayList();

               for (int var8 = 0; var8 < (16); var8++) {
                  for (int var9 = 0; var9 < (16); var9++) {
                     for (int var10 = 0; var10 < (16); var10++) {
                        if (isRedstoneOre(var6.getBlockState(var10, var8, var9))) {
                           int var11 = (var2 << (4)) + var10;
                           int var12 = (var3 << (4)) + var8;
                           int var13 = (var4 << (4)) + var9;
                           if (this.exposed(var1, var11, var12, var13)) {
                              var7.add(BlockPos.asLong(var11, var12, var13));
                           }
                        }
                     }
                  }
               }

               return var7.isEmpty() ? NO_ORES : var7.toLongArray();
            } else {
               return NO_ORES;
            }
         }
      } else {
         return NO_ORES;
      }
   }

   private boolean exposed(ClientWorld var1, int var2, int var3, int var4) {
      Direction[] var5 = Direction.values();
      int var6 = var5.length;

      for (int var7 = 0; var7 < var6; var7++) {
         Direction var8 = var5[var7];
         BlockState var9 = var1.getBlockState(
            this.cursor.set(var2 + var8.getOffsetX(), var3 + var8.getOffsetY(), var4 + var8.getOffsetZ())
         );
         if (var9.isAir() || !var9.isOpaque()) {
            return true;
         }
      }

      return false;
   }

   private static boolean isRedstoneOre(BlockState var0) {
      return ((!(!var0.isOf(Blocks.REDSTONE_ORE) && !var0.isOf(Blocks.DEEPSLATE_REDSTONE_ORE))));
   }

   private static boolean isAmethyst(BlockState var0) {
      return ((!(!var0.isOf(Blocks.AMETHYST_CLUSTER)
            && !var0.isOf(Blocks.LARGE_AMETHYST_BUD)
            && !var0.isOf(Blocks.MEDIUM_AMETHYST_BUD)
            && !var0.isOf(Blocks.SMALL_AMETHYST_BUD)
            && !var0.isOf(Blocks.BUDDING_AMETHYST)
            && !var0.isOf(Blocks.AMETHYST_BLOCK))));
   }

   private Map<Integer, byte[]> createZeroedChunk() {
      HashMap var1 = new HashMap();

      for (int var2 = this.bottomSection(); var2 <= this.topSection(); var2++) {
         var1.put(var2, ZERO_SECTION);
      }

      return var1;
   }

   private int lightSectionY(int var1) {
      ClientWorld var2 = MinecraftClient.getInstance().world;
      return var2 == null ? -2147483648 : var2.getChunkManager().getLightingProvider().getBottomY() + var1;
   }

   private int bottomSection() {
      return MinecraftClient.getInstance().world.getBottomSectionCoord();
   }

   private int topSection() {
      return MinecraftClient.getInstance().world.getTopSectionCoord();
   }

   private boolean isWorldSection(int var1) {
      return ((var1 >= this.bottomSection() && var1 <= this.topSection()));
   }

   private void trimChunkCache() {
      while (this.chunkLight.size() > (5000)) {
         Iterator var1 = this.chunkLight.keySet().iterator();
         var1.next();
         var1.remove();
      }
   }

   private void reset() {
      this.chunkLight.clear();
      this.passedChunks.clear();
      this.flaggedChunks.clear();
      this.shownChunks.clear();
      this.redstoneNotified.clear();
      this.lampSections.clear();
      this.goneLamps.clear();
   }








   @Environment(EnvType.CLIENT)
   private static final class BlockChange {
      int count;
      int x;
      int y;
      int z;
      int oldValue;
      int newValue;

      void add(int x, int y, int z, int oldValue, int newValue) {
         if (count == 0 || Math.abs(newValue - oldValue) > Math.abs(this.newValue - this.oldValue)) {
            this.x = x;
            this.y = y;
            this.z = z;
            this.oldValue = oldValue;
            this.newValue = newValue;
         }
         count++;
      }
   }

   @Environment(EnvType.CLIENT)
   public static final class PrimeChunkToast extends StackedNotificationToast {
      private static final Text TITLE = Text.literal("Deepslate Level Only");
      private static final Text MESSAGE = Text.literal("Go below Y 0 first.");

      PrimeChunkToast() {
         super(new ItemStack(Items.DEEPSLATE), TITLE, MESSAGE, true);
      }
   }
}
