package krispy.feature;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.ColorHelper;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.random.Random;

@Environment(EnvType.CLIENT)
final class SkyDomeRenderer {
   private static final float RADIUS = 100.0F;
   private static final float[] RINGS = {-30.0F, -12.0F, -4.0F, 0.0F, 4.0F, 9.0F, 16.0F, 26.0F, 40.0F, 58.0F, 76.0F, 90.0F};
   private static final int SEGMENTS = 48;
   private static final int HALO_RINGS = 4;
   private static final int HALO_SEGMENTS = 32;
   private static final int METEOR_SEGMENTS = 10;
   private static final float[] KEYS = {-0.35F, -0.08F, 0.06F, 0.3F};
   private static final int GOLDEN_ZENITH = 5210048;
   private static final int GOLDEN_HORIZON = 16032864;
   private static final int GOLDEN_GLOW = 16747069;
   private static final int DAY_ZENITH = 3108822;
   private static final int DAY_HORIZON = 11850996;
   private static final int DAY_GLOW = 16774362;
   private static final int BLUE_HOUR_ZENITH = 1319497;
   private final GpuQuadMesh dome;
   private final GpuQuadMesh endDome;
   private final GpuQuadMesh halo;
   private final GpuQuadMesh meteorMesh;
   private final Random random;
   private int zenith;
   private int horizon;
   private int glow;
   private float glowStrength;
   private float sunX;
   private float sunY;
   private float sunAngle;
   private float moonAngle;
   private boolean ready;
   private long meteorStart;
   private long meteorEnd;
   private long nextMeteor;
   private float mx;
   private float my;
   private float mz;
   private float tx;
   private float ty;
   private float tz;

   SkyDomeRenderer() {
      this.dome = new GpuQuadMesh(
         "Krispy sky dome",
         GpuQuadMesh.PAINT,
         (RINGS.length - (1)) * (48)
      );
      this.endDome = new GpuQuadMesh(
         "Krispy end sky",
         GpuQuadMesh.PAINT,
         (RINGS.length - (1)) * (48)
      );
      this.halo = new GpuQuadMesh(
         "Krispy sun and moon glow",
         GpuQuadMesh.GLOW,
         256
      );
      this.meteorMesh = new GpuQuadMesh(
         "Krispy shooting stars",
         GpuQuadMesh.GLOW,
         12
      );
      this.random = Random.create();
   }

   void update(float var1, float var2, float var3, float var4, float var5, int var6, int var7, int var8) {
      this.sunAngle = var1;
      this.moonAngle = var2;
      this.sunX = -MathHelper.sin((double)var1);
      this.sunY = MathHelper.cos((double)var1);
      int var9 = ColorHelper.lerp(0.30000001192092896F, 1319497, var6);
      int[] var10000 = new int[4];
      var10000[0] = var6;
      var10000[1] = var9;
      var10000[2] = 5210048;
      var10000[3] = 3108822;
      int[] var10 = var10000;
      var10000 = new int[4];
      var10000[0] = var7;
      var10000[1] = scale(var8, 0.75F);
      var10000[2] = 16032864;
      var10000[3] = 11850996;
      int[] var11 = var10000;
      var10000 = new int[4];
      var10000[0] = var7;
      var10000[1] = var8;
      var10000[2] = 16747069;
      var10000[3] = 16774362;
      int[] var12 = var10000;
      float[] var18 = new float[4];
      var18[0] = 0.0F;
      var18[1] = 0.550000011920929F;
      var18[2] = 1.0F;
      var18[3] = 0.25F;
      float[] var13 = var18;
      int var14 = 0;

      while (
         var14 < KEYS.length - (2)
            && this.sunY > KEYS[var14 + (1)]
      ) {
         var14++;
      }

      float var15 = AuroraMeshRenderer.smoothstep(
         (this.sunY - KEYS[var14])
            / (KEYS[var14 + (1)] - KEYS[var14])
      );
      this.zenith = ColorHelper.lerp(var15, var10[var14], var10[var14 + (1)]);
      this.horizon = ColorHelper.lerp(var15, var11[var14], var11[var14 + (1)]);
      this.glow = ColorHelper.lerp(var15, var12[var14], var12[var14 + (1)]);
      this.glowStrength = MathHelper.lerp(var15, var13[var14], var13[var14 + (1)])
         * (1.0F - var3);
      this.zenith = weather(this.zenith, var3, var4, var5);
      this.horizon = weather(this.horizon, var3, var4, var5);
      this.ready = true;
   }

   private static int weather(int var0, float var1, float var2, float var3) {
      int var4 = scale(luma(var0), 0.8500000238418579F);
      var0 = ColorHelper.lerp(var1 * 0.6499999761581421F, var0, var4);
      var0 = scale(
         var0,
         1.0F
            - 0.3499999940395355F * var1
            - 0.25F * var2
      );
      return var3 > 0.0F
         ? ColorHelper.lerp(var3 * 0.44999998807907104F, var0, 15265023)
         : var0;
   }

   boolean ready() {
      return this.ready;
   }

   int horizonToward(float var1, float var2) {
      float var3 = MathHelper.sqrt(var1 * var1 + var2 * var2);
      return var3 < 9.999999747378752e-05F
         ? this.horizon
         : this.colourAt(var1 / var3, 0.019999999552965164F, var2 / var3);
   }

   float golden() {
      return 1.0F
         - Math.min(
            1.0F,
            Math.abs(this.sunY - 0.05999999865889549F) / 0.2199999988079071F
         );
   }

   float nightness() {
      return AuroraMeshRenderer.smoothstep(
         (0.05000000074505806F - this.sunY) / 0.4000000059604645F
      );
   }

   int twilightGlow() {
      return this.glow;
   }

   void renderDome(MatrixStack var1) {
      BufferBuilder var2 = this.dome.begin();
      this.domeQuads(var2, false);
      this.dome.upload(var2);
      this.dome.draw(var1, 1.0F);
   }

   void renderEndDome(MatrixStack var1) {
      if (!this.endDome.isBuilt()) {
         BufferBuilder var2 = this.endDome.begin();
         this.domeQuads(var2, true);
         this.endDome.upload(var2);
      }

      this.endDome.draw(var1, 1.0F);
   }

   private void domeQuads(BufferBuilder var1, boolean var2) {
      for (int var3 = 0; var3 < RINGS.length - (1); var3++) {
         for (int var4 = 0; var4 < (48); var4++) {
            this.corner(var1, RINGS[var3], var4, var2);
            this.corner(var1, RINGS[var3], var4 + (1), var2);
            this.corner(var1, RINGS[var3 + (1)], var4 + (1), var2);
            this.corner(var1, RINGS[var3 + (1)], var4, var2);
         }
      }
   }

   private void corner(BufferBuilder var1, float var2, int var3, boolean var4) {
      float var5 = var2 * 0.01745329238474369F;
      float var6 = (float)var3 / 48.0F * 6.2831854820251465F;
      float var7 = MathHelper.cos((double)var5) * MathHelper.cos((double)var6);
      float var8 = MathHelper.sin((double)var5);
      float var9 = MathHelper.cos((double)var5) * MathHelper.sin((double)var6);
      int var10 = var4 ? endColourAt(var8) : this.colourAt(var7, var8, var9);
      GpuQuadMesh.vertex(
         var1,
         var7 * 100.0F,
         var8 * 100.0F,
         var9 * 100.0F,
         -16777216 | var10
      );
   }

   private int colourAt(float var1, float var2, float var3) {
      int var4 = ColorHelper.lerp(
         (float)Math.sqrt((double)Math.max(var2, 0.0F)), this.horizon, this.zenith
      );
      if (var2 < 0.0F) {
         var4 = scale(
            var4,
            1.0F
               - 0.3499999940395355F * AuroraMeshRenderer.smoothstep(-var2 / 0.4000000059604645F)
         );
      }

      if (this.glowStrength > 0.0010000000474974513F) {
         float var5 = Math.max(0.0F, var1 * this.sunX + var2 * this.sunY);
         float var6 = Math.max(
            0.0F, this.sunX < 0.0F ? -var1 : var1
         );
         float var7 = (float)(
            Math.pow((double)var5, 8.0)
                  * 0.9
               + Math.pow((double)var5, 2.0)
                  * 0.25
         );
         float var8 = (float)(
            Math.exp((double)(-Math.abs(var2) * 9.0F))
               * Math.pow((double)var6, 1.5)
         );
         float var9 = MathHelper.clamp(
            this.glowStrength * (var7 + var8 * 0.6000000238418579F),
            0.0F,
            1.0F
         );
         var4 = ColorHelper.lerp(var9, var4, this.glow);
      }

      return var4 & (16777215);
   }

   private static int endColourAt(float var0) {
      return ColorHelper.lerp(
            (float)Math.sqrt((double)Math.max(var0, 0.0F)), 1839152, 459789
         )
         & (16777215);
   }

   void renderHalos(MatrixStack var1, float var2, float var3) {
      BufferBuilder var4 = this.halo.begin();
      float var5 = 1.0F
         - AuroraMeshRenderer.smoothstep(this.sunY / 0.3499999940395355F);
      float var6 = AuroraMeshRenderer.smoothstep(
            (this.sunY + 0.11999999731779099F) / 0.11999999731779099F
         )
         * var2
         * (0.44999998807907104F + 0.3499999940395355F * var5);
      int var7 = ColorHelper.lerp(var5, 16773584, 16742963);
      haloQuads(
         var4,
         this.sunAngle,
         28.0F
            * (1.0F + 0.6000000238418579F * var5),
         var7,
         var6
      );
      haloQuads(
         var4,
         this.moonAngle,
         34.0F,
         11520255,
         0.3199999928474426F * var3 * var2
      );
      this.halo.upload(var4);
      this.halo.draw(var1, 1.0F);
   }

   private static void haloQuads(BufferBuilder var0, float var1, float var2, int var3, float var4) {
      if (!(var4 <= 0.0020000000949949026F)) {
         float[] var10000 = new float[5];
         var10000[0] = 0.0F;
         var10000[1] = var2 * 0.1599999964237213F;
         var10000[2] = var2 * 0.3799999952316284F;
         var10000[3] = var2 * 0.6600000262260437F;
         var10000[4] = var2;
         float[] var5 = var10000;
         var10000 = new float[5];
         var10000[0] = 1.0F;
         var10000[1] = 0.550000011920929F;
         var10000[2] = 0.2199999988079071F;
         var10000[3] = 0.07000000029802322F;
         var10000[4] = 0.0F;
         float[] var6 = var10000;
         float var7 = MathHelper.cos((double)var1);
         float var8 = MathHelper.sin((double)var1);

         for (int var9 = 0; var9 < (4); var9++) {
            for (int var10 = 0; var10 < (32); var10++) {
               haloVertex(var0, var5[var9], var10, var7, var8, var3, var6[var9] * var4);
               haloVertex(var0, var5[var9], var10 + (1), var7, var8, var3, var6[var9] * var4);
               haloVertex(
                  var0,
                  var5[var9 + (1)],
                  var10 + (1),
                  var7,
                  var8,
                  var3,
                  var6[var9 + (1)] * var4
               );
               haloVertex(var0, var5[var9 + (1)], var10, var7, var8, var3, var6[var9 + (1)] * var4);
            }
         }
      }
   }

   private static void haloVertex(BufferBuilder var0, float var1, int var2, float var3, float var4, int var5, float var6) {
      float var7 = (float)var2 / 32.0F * 6.2831854820251465F;
      float var8 = MathHelper.cos((double)var7) * var1;
      float var9 = 100.0F;
      float var10 = MathHelper.sin((double)var7) * var1;
      float var11 = var9 * var3 - var10 * var4;
      float var12 = var9 * var4 + var10 * var3;
      GpuQuadMesh.vertex(
         var0,
         -var12,
         var11,
         var8,
         Math.round(
                  MathHelper.clamp(var6, 0.0F, 1.0F)
                     * 255.0F
               )
               << (24)
            | var5 & (16777215)
      );
   }

   void renderMeteors(MatrixStack var1, float var2, float var3) {
      long var4 = System.nanoTime();
      if (var4 >= this.meteorEnd) {
         if (this.nextMeteor == (0L)) {
            this.nextMeteor = var4
               + seconds(
                  4.0F + 10.0F * this.random.nextFloat()
               );
         }

         if (var4 < this.nextMeteor
            || var2 < 0.6000000238418579F
            || var3 < 0.800000011920929F) {
            return;
         }

         this.launch(var4);
      }

      float var6 = (float)(var4 - this.meteorStart) / (float)(this.meteorEnd - this.meteorStart);
      float var7 = MathHelper.sin(
            (double)(
               3.1415927410125732F
                  * MathHelper.clamp(var6, 0.0F, 1.0F)
            )
         )
         * var2
         * var3;
      BufferBuilder var8 = this.meteorMesh.begin();
      float var9 = var6 * 0.550000011920929F;
      float var10 = 0.1599999964237213F;
      float[] var11 = null;

      for (int var12 = 0; var12 <= (10); var12++) {
         float var13 = var9 - var10 * (float)var12 / 10.0F;
         float[] var10000 = new float[3];
         var10000[0] = (this.mx + this.tx * var13)
            * 100.0F;
         var10000[1] = (this.my + this.ty * var13)
            * 100.0F;
         var10000[2] = (this.mz + this.tz * var13)
            * 100.0F;
         float[] var14 = var10000;
         if (var11 != null) {
            streak(
               var8,
               var11,
               var14,
               var7
                  * (
                     1.0F
                        - ((float)var12 - 1.0F) / 10.0F
                  ),
               var7 * (1.0F - (float)var12 / 10.0F)
            );
         }

         var11 = var14;
      }

      this.meteorMesh.upload(var8);
      this.meteorMesh.draw(var1, 1.0F);
   }

   private void launch(long var1) {
      float var3 = (30.0F + 40.0F * this.random.nextFloat())
         * 0.01745329238474369F;
      float var4 = this.random.nextFloat() * 6.2831854820251465F;
      this.mx = MathHelper.cos((double)var3) * MathHelper.cos((double)var4);
      this.my = MathHelper.sin((double)var3);
      this.mz = MathHelper.cos((double)var3) * MathHelper.sin((double)var4);
      float var5 = -MathHelper.sin((double)var4);
      float var6 = MathHelper.cos((double)var4);
      float var7 = -0.6000000238418579F - 0.4000000059604645F * this.random.nextFloat();
      float var8 = var5 * this.mx + var7 * this.my + var6 * this.mz;
      this.tx = var5 - var8 * this.mx;
      this.ty = var7 - var8 * this.my;
      this.tz = var6 - var8 * this.mz;
      float var9 = MathHelper.sqrt(
         this.tx * this.tx
            + this.ty * this.ty
            + this.tz * this.tz
      );
      this.tx /= var9;
      this.ty /= var9;
      this.tz /= var9;
      this.meteorStart = var1;
      this.meteorEnd = var1
         + seconds(0.699999988079071F + 0.5F * this.random.nextFloat());
      this.nextMeteor = this.meteorEnd
         + seconds(6.0F + 18.0F * this.random.nextFloat());
   }

   private static void streak(BufferBuilder var0, float[] var1, float[] var2, float var3, float var4) {
      float var5 = var2[0] - var1[0];
      float var6 = var2[1] - var1[1];
      float var7 = var2[2] - var1[2];
      float var8 = var1[1] * var7 - var1[2] * var6;
      float var9 = var1[2] * var5 - var1[0] * var7;
      float var10 = var1[0] * var6 - var1[1] * var5;
      float var11 = MathHelper.sqrt(var8 * var8 + var9 * var9 + var10 * var10);
      if (!(var11 < 9.999999747378752e-06F)) {
         float var12 = 0.2199999988079071F / var11;
         var8 *= var12;
         var9 *= var12;
         var10 *= var12;
         int var13 = Math.round(
                  MathHelper.clamp(var3, 0.0F, 1.0F)
                     * 255.0F
               )
               << (24)
            | 15397631;
         int var14 = Math.round(
                  MathHelper.clamp(var4, 0.0F, 1.0F)
                     * 255.0F
               )
               << (24)
            | 15397631;
         GpuQuadMesh.vertex(
            var0, var1[0] - var8, var1[1] - var9, var1[2] - var10, var13
         );
         GpuQuadMesh.vertex(
            var0, var1[0] + var8, var1[1] + var9, var1[2] + var10, var13
         );
         GpuQuadMesh.vertex(
            var0, var2[0] + var8, var2[1] + var9, var2[2] + var10, var14
         );
         GpuQuadMesh.vertex(
            var0, var2[0] - var8, var2[1] - var9, var2[2] - var10, var14
         );
      }
   }

   private static long seconds(float var0) {
      return (long)(var0 * 1000000000.0F);
   }

   static int scale(int var0, float var1) {
      int var2 = MathHelper.clamp(
         Math.round((float)(var0 >> (16) & (255)) * var1), 0, 255
      );
      int var3 = MathHelper.clamp(
         Math.round((float)(var0 >> (8) & (255)) * var1), 0, 255
      );
      int var4 = MathHelper.clamp(Math.round((float)(var0 & (255)) * var1), 0, 255);
      return var0 & (-16777216) | var2 << (16) | var3 << (8) | var4;
   }

   static int luma(int var0) {
      int var1 = Math.round(
         0.2125999927520752F * (float)(var0 >> (16) & (255))
            + 0.7152000069618225F * (float)(var0 >> (8) & (255))
            + 0.0722000002861023F * (float)(var0 & (255))
      );
      return var0 & (-16777216) | var1 << (16) | var1 << (8) | var1;
   }

   void close() {
      this.dome.close();
      this.endDome.close();
      this.halo.close();
      this.meteorMesh.close();
      this.ready = false;
   }
}
