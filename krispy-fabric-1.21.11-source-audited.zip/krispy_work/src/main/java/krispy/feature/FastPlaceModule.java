package krispy.feature;

import krispy.event.EventListener;
import krispy.event.events.PostItemUseEvent;
import krispy.module.Category;
import krispy.module.Module;
import krispy.module.setting.BooleanSetting;
import krispy.module.setting.NumberSetting;
import krispy.utils.EncryptedString;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.RangedWeaponItem;

public class FastPlaceModule extends Module {
   private final BooleanSetting onlyXP;
   private final BooleanSetting allowBlocks;
   private final BooleanSetting allowItems;
   private final NumberSetting useDelay;

   public FastPlaceModule() {
      super(EncryptedString.of("Fast Place"), EncryptedString.of("Spams use action."), -1, Category.MISC);
      this.onlyXP = new BooleanSetting("Only XP", false);
      this.allowBlocks = new BooleanSetting("Blocks", true);
      this.allowItems = new BooleanSetting("Items", true);
      this.useDelay = new NumberSetting("Delay", 0.0, 10.0, 0.0, 1.0);
      this.addSettings(this.onlyXP, this.allowBlocks, this.allowItems, this.useDelay);
   }

   @Override
   public void onEnable() {
      super.onEnable();
   }

   @Override
   public void onDisable() {
      super.onDisable();
   }

   @EventListener
   public void onPostItemUse(PostItemUseEvent event) {
      ItemStack main = this.mc.player.getMainHandStack();
      ItemStack off = this.mc.player.getOffHandStack();
      Item mainItem = main.getItem();
      Item offItem = this.mc.player.getOffHandStack().getItem();

      if (!main.isOf(Items.EXPERIENCE_BOTTLE) && !off.isOf(Items.EXPERIENCE_BOTTLE)
         && this.onlyXP.getValue()) {
         return;
      }

      if (!this.onlyXP.getValue()) {
         boolean placingBlock = mainItem instanceof BlockItem || offItem instanceof BlockItem;
         if (placingBlock ? !this.allowBlocks.getValue() : !this.allowItems.getValue()) {
            return;
         }
      }

      if (main.get(DataComponentTypes.FOOD) != null || off.get(DataComponentTypes.FOOD) != null) {
         return;
      }
      if (main.isOf(Items.RESPAWN_ANCHOR) || main.isOf(Items.GLOWSTONE)
         || off.isOf(Items.RESPAWN_ANCHOR) || off.isOf(Items.GLOWSTONE)) {
         return;
      }
      if (mainItem instanceof RangedWeaponItem || offItem instanceof RangedWeaponItem) {
         return;
      }
      event.cooldown = this.useDelay.getIntValue();
   }
}
