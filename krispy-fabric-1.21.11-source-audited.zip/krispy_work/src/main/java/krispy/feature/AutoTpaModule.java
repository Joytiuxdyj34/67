package krispy.feature;

import krispy.event.EventListener;
import krispy.event.events.TickEvent;
import krispy.module.Category;
import krispy.module.Module;
import krispy.module.setting.MinMaxSetting;
import krispy.module.setting.ModeSetting;
import krispy.module.setting.StringSetting;
import krispy.utils.EncryptedString;
import net.minecraft.client.network.ClientPlayNetworkHandler;

public final class AutoTpaModule extends Module {
   private final MinMaxSetting delayRange;
   private final ModeSetting<Mode> mode;
   private final StringSetting playerName;
   private int delayCounter;

   public AutoTpaModule() {
      super(
         EncryptedString.of("Auto Tpa"),
         EncryptedString.of("Module that helps you teleport streamers to you"),
         -1,
         Category.MISC
      );
      this.delayRange = new MinMaxSetting(EncryptedString.of("Delay"), 1.0, 80.0, 1.0, 10.0, 30.0);
      this.mode = new ModeSetting<>(EncryptedString.of("Mode"), Mode.TPAHERE, Mode.class);
      this.playerName = new StringSetting(EncryptedString.of("Player"), "DrDonutt");
      this.addSettings(this.mode, this.delayRange, this.playerName);
   }

   @Override
   public void onEnable() {
      super.onEnable();
   }

   @Override
   public void onDisable() {
      super.onDisable();
   }

   @EventListener
   public void onTick(TickEvent event) {
      if (this.delayCounter > 0) {
         this.delayCounter--;
         return;
      }

      ClientPlayNetworkHandler network = this.mc.getNetworkHandler();
      String command = this.mode.getValue().equals(Mode.TPA) ? "tpa " : "tpahere ";
      network.sendChatCommand(command + this.playerName.getValue());
      this.delayCounter = this.delayRange.getRandomIntInRange();
   }

   enum Mode {
      TPA,
      TPAHERE
   }
}
