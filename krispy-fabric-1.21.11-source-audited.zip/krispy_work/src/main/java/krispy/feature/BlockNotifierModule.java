package krispy.feature;

import java.awt.Color;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Queue;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.function.BiFunction;
import java.util.function.Consumer;
import java.util.function.Predicate;
import krispy.event.EventListener;
import krispy.event.events.ChunkDataEvent;
import krispy.event.events.Render3DEvent;
import krispy.event.events.TickEvent;
import krispy.module.Category;
import krispy.module.Module;
import krispy.module.setting.BooleanSetting;
import krispy.module.setting.ModeSetting;
import krispy.module.setting.NumberSetting;
import krispy.module.setting.Setting;
import krispy.module.setting.StorageBlocksSetting;
import krispy.module.setting.StringSetting;
import krispy.module.setting.StorageBlocksSetting.Entry;
import krispy.utils.BlockUtil;
import krispy.utils.EncryptedString;
import krispy.utils.RenderUtils;
import krispy.utils.RenderVisibility;
import krispy.utils.RenderUtils.ColoredBox;
import krispy.utils.RenderUtils.ColoredLine;
import krispy.utils.embed.DiscordWebhook;
import krispy.utils.embed.DiscordWebhook.EmbedObject;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.item.Item;
import net.minecraft.network.ClientConnection;
import net.minecraft.registry.DefaultedRegistry;
import net.minecraft.registry.Registries;
import net.minecraft.registry.entry.RegistryEntry.Reference;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.world.chunk.PalettedContainer;
import net.minecraft.world.chunk.WorldChunk;

public final class BlockNotifierModule extends Module {
   private static final int MAX_RENDERED = 4096;
   private final StorageBlocksSetting blocks;
   private final ModeSetting<BlockNotifierModule.NotificationMode> notificationMode;
   private final BooleanSetting disconnectOnFind;
   private final BooleanSetting notifications;
   private final BooleanSetting webhookEnabled;
   private final StringSetting webhookUrl;
   private final BooleanSetting selfPing;
   private final StringSetting discordId;
   private final BooleanSetting showEsp;
   private final NumberSetting alpha;
   private final BooleanSetting outlines;
   private final BooleanSetting tracers;
   private final BooleanSetting onlyNew;
   private final NumberSetting renderDistance;
   private final Map<Block, Entry> selected;
   private final Map<Long, List<BlockNotifierModule.BlockEntry>> perChunk;
   private final Set<BlockPos> everFound;
   private final Set<BlockPos> newFound;
   private final Queue<Long> scanQueue;
   private final Set<Long> queued;
   private final Set<Long> scanned;
   private final List<ColoredBox> boxes;
   private final List<ColoredLine> lines;
   private Object trackedWorld;
   private int selectionSignature;
   private int ticks;
   private int totalFound;

   public BlockNotifierModule() {
      super(EncryptedString.of("Block Notifier"),
            EncryptedString.of("Notifies and highlights selected blocks when chunks load"), -1, Category.RENDER);
      blocks = createPalette();
      notificationMode = new ModeSetting<>(EncryptedString.of("Notification Mode"), NotificationMode.BOTH, NotificationMode.class);
      disconnectOnFind = new BooleanSetting(EncryptedString.of("Disconnect On Find"), false);
      notifications = new BooleanSetting(EncryptedString.of("Notifications"), true);
      webhookEnabled = new BooleanSetting(EncryptedString.of("Webhook Enabled"), false);
      webhookUrl = new StringSetting(EncryptedString.of("Webhook URL"), "");
      selfPing = new BooleanSetting(EncryptedString.of("Self Ping"), false);
      discordId = new StringSetting(EncryptedString.of("Discord ID"), "");
      showEsp = new BooleanSetting(EncryptedString.of("Show ESP"), true);
      alpha = new NumberSetting(EncryptedString.of("Alpha"), 0.0, 255.0, 100.0, 1.0);
      outlines = new BooleanSetting(EncryptedString.of("Outlines"), true);
      tracers = new BooleanSetting(EncryptedString.of("Tracers"), true);
      onlyNew = new BooleanSetting(EncryptedString.of("Only Render New"), false);
      renderDistance = new NumberSetting(EncryptedString.of("Render Distance"), 0.0, 500.0, 0.0, 5.0);
      selected = new HashMap<>();
      perChunk = new HashMap<>();
      everFound = new HashSet<>();
      newFound = new HashSet<>();
      scanQueue = new ArrayDeque<>();
      queued = new HashSet<>();
      scanned = new HashSet<>();
      boxes = new ArrayList<>();
      lines = new ArrayList<>();
      addSettings(new Setting[]{blocks, notificationMode, disconnectOnFind, notifications, webhookEnabled,
            webhookUrl, selfPing, discordId, showEsp, alpha, outlines, tracers, onlyNew, renderDistance});
   }

   private static StorageBlocksSetting createPalette() {
      StorageBlocksSetting palette = new StorageBlocksSetting(EncryptedString.of("Blocks To Find"));
      for (Block block : Registries.BLOCK) {
         if (block == Blocks.AIR || block == Blocks.CAVE_AIR || block == Blocks.VOID_AIR) {
            continue;
         }
         Identifier id = Registries.BLOCK.getId(block);
         Color color = Color.getHSBColor((id.toString().hashCode() & 0xFFFF) / 65535.0F, 0.7F, 1.0F);
         palette.add(id.toString(), block.getName().getString(), block.asItem(), false, color);
      }
      return palette;
   }

   public void onEnable() {
      this.reset();
      this.trackedWorld = this.mc.world;
      this.refreshSelection();
      this.enqueueLoaded();
      this.chat("Block Notifier activated.");
      super.onEnable();
   }

   public void onDisable() {
      int var1 = this.totalFound;
      this.reset();
      if (this.notifications.getValue() && this.mc.player != null) {
         this.mc
            .player
            .sendMessage(
               Text.literal("§b[Block Notifier] §fDeactivated. Found " + var1 + " blocks this session."), false
            );
      }

      super.onDisable();
   }

   private void reset() {
      this.selected.clear();
      this.perChunk.clear();
      this.everFound.clear();
      this.newFound.clear();
      this.scanQueue.clear();
      this.queued.clear();
      this.scanned.clear();
      this.boxes.clear();
      this.lines.clear();
      this.trackedWorld = null;
      this.selectionSignature = 0;
      this.ticks = 0;
      this.totalFound = 0;
   }

   @EventListener
   public void onChunkData(ChunkDataEvent var1) {
      this.enqueue(var1.packet.getChunkX(), var1.packet.getChunkZ());
   }

   @EventListener
   public void onTick(TickEvent var1) {
      if (this.mc.world != null && this.mc.player != null) {
         if (this.trackedWorld != this.mc.world) {
            this.reset();
            this.trackedWorld = this.mc.world;
            this.refreshSelection();
            this.enqueueLoaded();
         }

         int var2 = this.computeSignature();
         if (var2 != this.selectionSignature) {
            this.perChunk.clear();
            this.everFound.clear();
            this.newFound.clear();
            this.scanQueue.clear();
            this.queued.clear();
            this.scanned.clear();
            this.totalFound = 0;
            this.refreshSelection();
            this.enqueueLoaded();
         }

         if (!this.selected.isEmpty()) {
            this.ticks += 1;
            if (this.ticks % (100) == (1)) {
               this.enqueueLoaded();
            }

            if (this.ticks % (400) == 0) {
               this.scanned.clear();
            }

            this.scanOne();
            if (this.ticks % (20) == 0) {
               this.perChunk
                  .keySet()
                  .removeIf(
                     var1x -> ((!this.mc.world.isChunkLoaded(ChunkPos.getPackedX(var1x), ChunkPos.getPackedZ(var1x))))
                  );
            }
         }
      }
   }

   private int computeSignature() {
      int var1 = 1;

      for (Entry var3 : this.blocks.entries()) {
         if (var3.enabled()) {
            var1 = (31) * var1 + var3.id().hashCode();
         }
      }

      return var1;
   }

   private void refreshSelection() {
      this.selected.clear();

      for (Entry var2 : this.blocks.entries()) {
         if (var2.enabled()) {
            Registries.BLOCK
               .getEntry(Identifier.of(var2.id()))
               .ifPresent(var2x -> this.selected.put((Block)var2x.value(), var2));
         }
      }

      this.selectionSignature = this.computeSignature();
   }

   private void enqueueLoaded() {
      if (this.mc.world != null && this.mc.player != null && !this.selected.isEmpty()) {
         ChunkPos var1 = this.mc.player.getChunkPos();
          List<WorldChunk> var2 = BlockUtil.getLoadedChunksList();
         var2.sort(
            Comparator.comparingInt(
               var1x -> Math.max(Math.abs(var1x.getPos().x - var1.x), Math.abs(var1x.getPos().z - var1.z))
            )
         );

         for (Object var4Object : var2) { WorldChunk var4 = (WorldChunk)var4Object;
            this.enqueue(var4.getPos().x, var4.getPos().z);
         }
      }
   }

   private void enqueue(int var1, int var2) {
      long var3 = ChunkPos.toLong(var1, var2);
      if (!this.selected.isEmpty() && !this.scanned.contains(var3) && this.queued.add(var3)) {
         this.scanQueue.offer(var3);
      }
   }

   private void scanOne() {
      Long var1 = this.scanQueue.poll();
      if (var1 != null) {
         this.queued.remove(var1);
         this.scanned.add(var1);
         int var2 = ChunkPos.getPackedX(var1);
         int var3 = ChunkPos.getPackedZ(var1);
         if (this.mc.world.isChunkLoaded(var2, var3)) {
            WorldChunk var4 = this.mc.world.getChunk(var2, var3);
            ArrayList var5 = new ArrayList();
            HashMap<Block, Integer> var6 = new HashMap<>();
            ChunkSection[] var7 = var4.getSectionArray();
            int var8 = var4.getBottomSectionCoord();

            for (int var9 = 0; var9 < var7.length; var9++) {
               ChunkSection var10 = var7[var9];
               if (var10 != null && var10.getBlockStateContainer().hasAny(var1x -> this.selected.containsKey(var1x.getBlock()))) {
                  int var11 = var8 + var9 << (4);

                  for (int var12 = 0; var12 < (16); var12++) {
                     for (int var13 = 0; var13 < (16); var13++) {
                        for (int var14 = 0; var14 < (16); var14++) {
                           Block var15 = var10.getBlockState(var14, var12, var13).getBlock();
                           if (this.selected.containsKey(var15)) {
                              BlockPos var16 = new BlockPos(
                                 var4.getPos().getStartX() + var14, var11 + var12, var4.getPos().getStartZ() + var13
                              );
                              var5.add(new BlockNotifierModule.BlockEntry(var16, var15));
                              if (this.everFound.add(var16)) {
                                 this.newFound.add(var16);
                                 this.totalFound += 1;
                                 var6.merge(var15, 1, Integer::sum);
                              }
                           }
                        }
                     }
                  }
               }
            }

            if (var5.isEmpty()) {
               this.perChunk.remove(var1);
            } else {
               this.perChunk.put(var1, List.copyOf(var5));
            }

            if (!var6.isEmpty()) {
               this.notifyFound(var4.getPos(), var6);
            }
         }
      }
   }

   private void notifyFound(ChunkPos var1, Map<Block, Integer> var2) {
      int var3 = var1.getCenterX();
      int var4 = var1.getCenterZ();
      StringBuilder var5 = new StringBuilder();

      for (Map.Entry<Block, Integer> var7 : var2.entrySet()) {
         if (!var5.isEmpty()) {
            var5.append(", ");
         }

         var5.append(((Block)var7.getKey()).getName().getString())
            .append(" x")
            .append(var7.getValue());
      }

      String var8 = "Found " + var5 + " at chunk " + var3 + ", " + var4;
      if (this.notificationMode.isMode(BlockNotifierModule.NotificationMode.CHAT) || this.notificationMode.isMode(BlockNotifierModule.NotificationMode.BOTH)) {
         this.chat(var8);
      }

      if ((this.notificationMode.isMode(BlockNotifierModule.NotificationMode.TOAST) || this.notificationMode.isMode(BlockNotifierModule.NotificationMode.BOTH))
         && this.mc.player != null) {
         this.mc.player.sendMessage(Text.literal("§6[Block Notifier] §f" + var8), true);
      }

      if (this.webhookEnabled.getValue() && !this.webhookUrl.getValue().isBlank()) {
         this.sendWebhook(var8, var3, var4);
      }

      if (this.disconnectOnFind.getValue() && this.mc.getNetworkHandler() != null) {
         this.toggle(false);
         this.mc.getNetworkHandler().getConnection().disconnect(Text.literal("Target block found at " + var3 + ", " + var4));
      }
   }

   private void sendWebhook(String var1, int var2, int var3) {
      String var4 = this.webhookUrl.getValue().trim();
      String var5 = this.selfPing.getValue() && !this.discordId.getValue().isBlank()
         ? "<@" + this.discordId.getValue().trim() + ">"
         : null;
      String var6 = this.mc.getCurrentServerEntry() == null
         ? "Singleplayer"
         : this.mc.getCurrentServerEntry().address;
      CompletableFuture.runAsync(
         () -> {
            try {
               DiscordWebhook var7 = new DiscordWebhook(var4);
               var7.b("Krispy Block Notifier");
               if (var5 != null) {
                  var7.a(var5);
               }

               var7.addEmbed(
                  new EmbedObject()
                     .setTitle("Block Notifier Alert")
                     .setDescription(var1)
                     .setColor(new Color(120, 190, 255))
                     .addField(
                        "Coordinates",
                        var2 + ", " + var3,
                        true
                     )
                     .addField("Server", var6, true)
               );
               var7.execute();
            } catch (Exception var8) {
               this.mc.execute(() -> this.chat("Webhook failed: " + var8.getMessage()));
            }
         }
      );
   }

   @EventListener
   public void onRender3D(Render3DEvent event) {
      if (mc.player == null || perChunk.isEmpty() || (!showEsp.getValue() && !tracers.getValue())) {
         return;
      }

      Camera camera = RenderUtils.getCamera();
      if (camera == null || !camera.isReady()) {
         return;
      }

      boxes.clear();
      lines.clear();
      Vec3d tracerStart = RenderUtils.getTracerStart(camera);
      double maxDistance = renderDistance.getValue();
      int rendered = 0;

      for (List<BlockEntry> chunkEntries : perChunk.values()) {
         for (BlockEntry entry : chunkEntries) {
            BlockPos pos = entry.pos();
            if (!tracers.getValue() && !RenderVisibility.box(
                  pos.getX(), pos.getY(), pos.getZ(), pos.getX() + 1, pos.getY() + 1, pos.getZ() + 1)) {
               continue;
            }
            if (onlyNew.getValue() && !newFound.contains(pos)) {
               continue;
            }
            if (maxDistance > 0.0 && mc.player.squaredDistanceTo(Vec3d.ofCenter(pos)) > maxDistance * maxDistance) {
               continue;
            }

            Entry selectedBlock = selected.get(entry.block());
            if (selectedBlock == null) {
               continue;
            }
            Color baseColor = selectedBlock.color();
            Color color = new Color(baseColor.getRed(), baseColor.getGreen(), baseColor.getBlue(), alpha.getIntValue());
            if (showEsp.getValue()) {
               double inset = outlines.getValue() ? 0.05 : 0.0;
               boxes.add(new ColoredBox(
                     pos.getX() + inset, pos.getY() + inset, pos.getZ() + inset,
                     pos.getX() + 1 - inset, pos.getY() + 1 - inset, pos.getZ() + 1 - inset, color));
            }
            if (tracers.getValue()) {
               lines.add(new ColoredLine(tracerStart, Vec3d.ofCenter(pos), color, 1.5F));
            }
            if (++rendered >= MAX_RENDERED) {
               break;
            }
         }
      }

      MatrixStack matrices = event.matrixStack;
      matrices.push();
      RenderUtils.applyCameraTransform(matrices, camera);
      RenderUtils.renderFilledBoxes(matrices, boxes);
      RenderUtils.renderLines(matrices, lines);
      matrices.pop();
   }

   private void chat(String message) {
      if (notifications.getValue() && mc.player != null) {
         mc.player.sendMessage(Text.literal("§b[Block Notifier] §f" + message), false);
      }
   }

   public int getDetectedBlockCount() {
      return this.totalFound;
   }

   private record BlockEntry(BlockPos pos, Block block) {
   }

   public static enum NotificationMode {
      CHAT,
      TOAST,
      BOTH;
   }
}
