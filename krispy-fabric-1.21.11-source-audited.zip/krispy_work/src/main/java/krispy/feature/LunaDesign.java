package krispy.feature;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import krispy.feature.SdfShapes.DistanceField3D;
import krispy.utils.BytecodeException;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public final class LunaDesign extends CharacterDefinition {
   private static final int SKIN = -6958;
   private static final int SKIN_SHADE = -1331558;
   private static final int SKIN_LINE = -5737368;
   private static final int HAIR = -1912065;
   private static final int HAIR_MID = -4940554;
   private static final int HAIR_TIP = -7706904;
   private static final int HAIR_ROOT = -6519080;
   private static final int HAIR_LIGHT = -1647873;
   private static final int HAIR_LINE = -10794346;
   private static final int NAVY = -14603682;
   private static final int NAVY_DARK = -15460295;
   private static final int NAVY_LINE = -15921370;
   private static final int BODICE = -13945223;
   private static final int TIER = -12693598;
   private static final int LINING = -7571752;
   private static final int RIBBON = -4544530;
   private static final int PETTICOAT = -4611086;
   private static final int LACE = -1036;
   private static final int GOLD = -1326758;
   private static final int GOLD_DARK = -5011921;
   private static final int GOLD_PALE = -2868;
   private static final int GOLD_LINE = -8760296;
   private static final int TIGHTS = -12959880;
   private static final int TIGHTS_SHEEN = -10656082;
   private static final int BOOT = -7710146;
   private static final int BOOT_DARK = -9550799;
   private static final int BOOT_CUFF = -6395064;
   private static final int LEATHER = -8762574;
   private static final int LEATHER_DARK = -11653344;
   private static final int MOON = -4688;
   private static final float HEAD_K = 1.05F;
   private static final float NECK_Y = 24.7F;
   private static final float NECK_Z = -0.1F;
   private static final float AXIS_Z = -0.3F;
   private static final float HAT_TILT_X = -8.0F;
   private static final float HAT_TILT_Z = 4.0F;
   private static final Vec3 HAT_CENTRE = new Vec3(0.0F, 29.15F, -0.25F);
   private static final Sdf2D BRIM = Sdf2D.taper(2.9F, 29.25F, 0.82F, 5.72F, 29.0F, 0.5F);
   private static final float BRIM_WAVE = 0.3F;
   private static final float RIM_R = 5.86F;
   private static final Vec3 ELBOW = new Vec3(-3.72F, 18.4F, -0.05F);
   private static final float ELBOW_PITCH = -12.0F;
   private static final float ELBOW_ROLL = 3.0F;
   private static final float FACE_PPU = 41.48148F;
   private static final float FACE_LEFT = -2.3142858F;
   private static final float FACE_TOP = 28.810715F;
   private static final float[] CAPE_Y;
   private static final float[] CAPE_RX;
   private static final float[] CAPE_RZ;
   private static final float[] CAPE_CZ;
   private static final float[] CAPE_WRAP;
   private static final int CAPE_STEPS = 96;
   private static final float[] CAPE_LUT;
   private static final float[] CURTAIN_Y;
   private static final float[] CURTAIN_RX;
   private static final float[] CURTAIN_RZ;
   private static final float[] CURTAIN_CZ;

   public LunaDesign() {
      super("luna", "Luna");
   }

   protected void define(CharacterRig var1) {
      var1.scale(1.0F).outline(-15396047, 0.15F).occlusion(0.35F);
      PixelCanvas var16;
      paintBand(var16 = new PixelCanvas(128, 12));
      Sdf3D var18 = faceShape();
      Sdf3D var20 = SdfShapes.ellipsoid(0.0F, 27.55F, -0.35F, 2.82F, 2.94F, 2.88F);
      Sdf3D var36 = SdfShapes.plane(0.0F, 24.6F, -2.7F, 0.0F, -1.0F, 0.86F);
      Sdf3D var21 = var20.intersect(var36);
      List var23 = bangs(var18);
      head(var1, var18, var23);
      hair(var1, var21, var23);
      hat(var1);
      body(var1);
      cape(var1);
      skirt(var1, var16);
      arms(var1, var16);
      legs(var1);
   }

   public static Sdf3D faceShape() {
      Sdf3D var0 = SdfShapes.ellipsoid(
         0.0F,
         27.5F,
         -0.30000001192092896F,
         2.380000114440918F,
         2.5F,
         2.4200000762939453F
      );
      Sdf3D var1 = SdfShapes.ellipsoid(
         0.0F,
         26.299999237060547F,
         0.30000001192092896F,
         1.840000033378601F,
         1.3200000524520874F,
         1.840000033378601F
      );
      Sdf3D var2 = SdfShapes.cone(
         0.0F,
         25.75F,
         0.4000000059604645F,
         1.2799999713897705F,
         0.0F,
         24.739999771118164F,
         1.0199999809265137F,
         0.3400000035762787F
      );
      float var10000 = 1.0F;
      Sdf3D[] var10001 = new Sdf3D[3];
      var10001[0] = var0;
      var10001[1] = var1;
      var10001[2] = var2;
      return SdfShapes.blend(var10000, var10001);
   }

   public static void head(CharacterRig var0, Sdf3D var1, List<LunaDesign.CurvedShape> var2) {
      var0.part(CharacterBone.HEAD)
         .pivot(0.0F, 24.700000762939453F, -0.10000000149011612F)
         .shape(hs(var1.paint(SurfacePaint.of(-6958))))
         .resolution(0.8999999761581421F)
         .detail(1.5F)
         .flatLight(1.0F)
         .occlusion(0.20000000298023224F)
         .outline(-5737368, 0.07999999821186066F)
         .decal(faceDecal(var2));
   }

   public static Sdf3D hs(Sdf3D var0) {
      return var0.scale(
         1.0499999523162842F,
         0.0F,
         24.700000762939453F,
         -0.10000000149011612F
      );
   }

   public static Vec3 hp(float var0, float var1, float var2) {
      return new Vec3(
         var0 * 1.0499999523162842F,
         24.700000762939453F
            + (var1 - 24.700000762939453F) * 1.0499999523162842F,
         -0.10000000149011612F + (var2 - -0.10000000149011612F) * 1.0499999523162842F
      );
   }

   public static CharacterPartBuilder at(CharacterPartBuilder var0, Vec3 var1) {
      return var0.pivot(var1.x(), var1.y(), var1.z());
   }

   public static List<LunaDesign.CurvedShape> bangs(Sdf3D var0) {
      float[][] var10000 = new float[7][];
      int var10002 = 0;
      float[] var10003 = new float[5];
      var10003[0] = -50.0F;
      var10003[1] = 26.5F;
      var10003[2] = 0.75F;
      var10003[3] = 0.30000001192092896F;
      var10003[4] = 0.0F;
      var10000[var10002] = var10003;
      var10002 = 1;
      var10003 = new float[5];
      var10003[0] = -24.0F;
      var10003[1] = 27.600000381469727F;
      var10003[2] = 0.7200000286102295F;
      var10003[3] = 0.25F;
      var10003[4] = 0.0F;
      var10000[var10002] = var10003;
      var10002 = 2;
      var10003 = new float[5];
      var10003[0] = 4.0F;
      var10003[1] = 26.899999618530273F;
      var10003[2] = 0.800000011920929F;
      var10003[3] = -0.20000000298023224F;
      var10003[4] = 0.0F;
      var10000[var10002] = var10003;
      var10002 = 3;
      var10003 = new float[5];
      var10003[0] = 27.0F;
      var10003[1] = 27.799999237060547F;
      var10003[2] = 0.699999988079071F;
      var10003[3] = -0.25F;
      var10003[4] = 0.0F;
      var10000[var10002] = var10003;
      var10002 = 4;
      var10003 = new float[5];
      var10003[0] = 52.0F;
      var10003[1] = 26.6200008392334F;
      var10003[2] = 0.75F;
      var10003[3] = -0.30000001192092896F;
      var10003[4] = 0.0F;
      var10000[var10002] = var10003;
      var10002 = 5;
      var10003 = new float[5];
      var10003[0] = -37.0F;
      var10003[1] = 27.200000762939453F;
      var10003[2] = 0.36000001430511475F;
      var10003[3] = 0.20000000298023224F;
      var10003[4] = 1.0F;
      var10000[var10002] = var10003;
      var10002 = 6;
      var10003 = new float[5];
      var10003[0] = 40.0F;
      var10003[1] = 27.020000457763672F;
      var10003[2] = 0.36000001430511475F;
      var10003[3] = -0.20000000298023224F;
      var10003[4] = 1.0F;
      var10000[var10002] = var10003;
      float[][] var1 = var10000;
      ArrayList var2 = new ArrayList();
      float[][] var3 = var1;
      int var4 = var1.length;

      for (int var5 = 0; var5 < var4; var5++) {
         float[] var6 = var3[var5];
         float[] var7 = new float[10];
         float[] var8 = new float[10];

         for (int var9 = 0; var9 < (10); var9++) {
            var7[var9] = var6[1]
               - 0.30000001192092896F
               + (29.600000381469727F - var6[1] + 0.30000001192092896F)
                  * (float)var9
                  / 9.0F;
            var8[var9] = surfaceR(var0, var6[0], var7[var9]);
         }

         var2.add(
            var6[4] > 0.0F
               ? new LunaDesign.CurvedShape(
                  var6[0],
                  29.399999618530273F,
                  var6[1],
                  var6[2],
                  var6[3],
                  0.699999988079071F,
                  0.75F,
                  0.10000000149011612F,
                  0.30000001192092896F,
                  0.20000000298023224F,
                  var7,
                  var8
               )
               : new LunaDesign.CurvedShape(
                  var6[0],
                  29.399999618530273F,
                  var6[1],
                  var6[2],
                  var6[3],
                  0.5F,
                  0.44999998807907104F,
                  0.05000000074505806F,
                  0.4000000059604645F,
                  0.2199999988079071F,
                  var7,
                  var8
               )
         );
      }

      return var2;
   }

   public static float interp(float[] var0, float[] var1, float var2) {
      int var3 = var0.length;
      if (var2 <= var0[0]) {
         return var1[0];
      } else if (var2 >= var0[var3 - (1)]) {
         return var1[var3 - (1)];
      } else {
         int var4 = 0;

         while (var2 > var0[var4 + (1)]) {
            var4++;
         }

         return var1[var4] + (var1[var4 + (1)] - var1[var4]) * (var2 - var0[var4]) / (var0[var4 + (1)] - var0[var4]);
      }
   }

   public static float surfaceR(Sdf3D var0, float var1, float var2) {
      double var3 = Math.toRadians((double)var1);
      float var5 = (float)Math.sin(var3);
      float var6 = (float)Math.cos(var3);
      float var7 = 4.5F;

      for (int var8 = 0; var8 < (80); var8++) {
         float var9 = var0.distance(var5 * var7, var2, -0.30000001192092896F + var6 * var7);
         if (Math.abs(var9) < 0.0010000000474974513F) {
            break;
         }

         var7 -= var9;
      }

      return var7;
   }

   public static void hair(CharacterRig var0, Sdf3D var1, List<LunaDesign.CurvedShape> var2) {
      ArrayList var3 = new ArrayList();
      var3.add(var1);

      for (int var4 = -1; var4 <= (1); var4 += 2) {
         float var10001 = 0.7400000095367432F;
         float var10002 = 0.23999999463558197F;
         float[] var10003 = new float[12];
         var10003[0] = (float)var4 * 2.3499999046325684F;
         var10003[1] = 29.200000762939453F;
         var10003[2] = -0.8999999761581421F;
         var10003[3] = (float)var4 * 3.0399999618530273F;
         var10003[4] = 27.600000381469727F;
         var10003[5] = -0.7200000286102295F;
         var10003[6] = (float)var4 * 3.0199999809265137F;
         var10003[7] = 26.0F;
         var10003[8] = -0.5F;
         var10003[9] = (float)var4 * 2.7799999713897705F;
         var10003[10] = 24.5F;
         var10003[11] = -0.3499999940395355F;
         var3.add(
            SdfShapes.strand(var10001, var10002, var10003)
               .flattenFrom(
                  1.5F,
                  0.0F,
                  26.799999237060547F,
                  -0.6000000238418579F
               )
         );
      }

      SurfacePaint var21 = SurfacePaint.field(
         (var0x, var1x, var2x) -> shine(
               ArgbColors.mix(
                  -4940554,
                  -1912065,
                  clamp01((var1x - 24.600000381469727F) / 3.5999999046325684F)
               ),
               var0x,
               var1x,
               var2x,
               28.100000381469727F,
               0.25999999046325684F,
               7,
               0.30000001192092896F
            )
      );
      var0.extra("hair", CharacterBone.HEAD)
         .shape(hs(SdfShapes.union(((Sdf3D[]) var3.toArray(new Sdf3D[0]))).paint(var21)))
         .resolution(1.2999999523162842F)
         .detail(0.6000000238418579F)
         .flatLight(0.4000000059604645F)
         .noOutline();
      ArrayList var5 = new ArrayList();

      for (LunaDesign.CurvedShape var7 : var2) {
         var5.add(var7.shape());
      }

      SurfacePaint var22 = SurfacePaint.field(
         (var0x, var1x, var2x) -> shine(
               ArgbColors.mix(
                  -1647873,
                  -6519080,
                  clamp01((var1x - 27.100000381469727F) / 1.899999976158142F)
               ),
               var0x,
               var1x,
               var2x,
               28.450000762939453F,
               0.14000000059604645F,
               11,
               0.8999999761581421F
            )
      );
      var0.extra("bangs", CharacterBone.HEAD)
         .shape(hs(SdfShapes.union(((Sdf3D[]) var5.toArray(new Sdf3D[0]))).paint(var22)))
         .resolution(0.44999998807907104F)
         .detail(1.2999999523162842F)
         .flatLight(0.699999988079071F)
         .occlusion(0.15000000596046448F)
         .outline(-10794346, 0.07999999821186066F);
      float var33 = -72.0F;
      float var34 = 29.399999618530273F;
      float var10004 = 24.299999237060547F;
      float var10005 = 0.6200000047683716F;
      float var10006 = 0.8999999761581421F;
      float var10007 = 0.0F;
      float var10008 = 0.0F;
      float var10009 = 0.0F;
      float var10010 = 0.44999998807907104F;
      float var10011 = 0.30000001192092896F;
      float[] var10012 = new float[6];
      var10012[0] = 24.0F;
      var10012[1] = 25.0F;
      var10012[2] = 26.200000762939453F;
      var10012[3] = 27.600000381469727F;
      var10012[4] = 28.799999237060547F;
      var10012[5] = 29.600000381469727F;
      float[] var10013 = new float[6];
      var10013[0] = 2.259999990463257F;
      var10013[1] = 2.5399999618530273F;
      var10013[2] = 2.7200000286102295F;
      var10013[3] = 2.700000047683716F;
      var10013[4] = 2.4200000762939453F;
      var10013[5] = 2.0F;
      LunaDesign.CurvedShape var23 = new LunaDesign.CurvedShape(
         var33, var34, var10004, var10005, var10006, var10007, var10008, var10009, var10010, var10011, var10012, var10013
      );
      SurfacePaint var8 = SurfacePaint.field(
         (var0x, var1x, var2x) -> var1x > 27.200000762939453F
               ? ArgbColors.mix(
                  -1647873,
                  -6519080,
                  clamp01((var1x - 27.200000762939453F) / 1.7999999523162842F)
               )
               : ArgbColors.mix(
                  -4940554,
                  -1647873,
                  clamp01((var1x - 24.299999237060547F) / 2.9000000953674316F)
               )
      );
      var0.extra("locks", CharacterBone.HEAD)
         .shape(hs(var23.shape().mirrorX().paint(var8)))
         .resolution(0.44999998807907104F)
         .detail(0.699999988079071F)
         .flatLight(0.5F)
         .occlusion(0.30000001192092896F)
         .outline(-10794346, 0.07999999821186066F);
      ArrayList var9 = new ArrayList();
      ArrayList var10 = new ArrayList();

      for (int var11 = 0; var11 < (5); var11++) {
         var9.add(
            backLock(
               118.0F + 31.0F * (float)var11,
               -0.2199999988079071F,
               18.200000762939453F + (float)(var11 % (2)) * 0.3499999940395355F,
               1.25F,
               0.5F,
               2.5999999046325684F,
               (float)var11 * 1.7000000476837158F
            )
         );
      }

      for (int var24 = 0; var24 < (7); var24++) {
         float var12 = (float)var24 / 6.0F;
         float var13 = 16.899999618530273F
            + 1.399999976158142F
               * (float)Math.pow(
                  (double)(Math.abs(var12 - 0.5F) * 2.0F),
                  1.5
               )
            + (float)(var24 % (3)) * 0.30000001192092896F;
         var10.add(
            backLock(
               116.0F + 128.0F * var12,
               var24 % (2) == 0 ? 0.14000000059604645F : 0.05999999865889549F,
               var13,
               0.6600000262260437F,
               0.11999999731779099F,
               1.7000000476837158F,
               (float)var24 * 2.299999952316284F
            )
         );
      }

      Sdf3D var25 = SdfShapes.union(((Sdf3D[]) var9.toArray(new Sdf3D[0])))
         .paint(
            SurfacePaint.vertical(
               -9152312, 18.0F, -5993238, 26.0F
            )
         );
      Sdf3D var26 = SdfShapes.union(((Sdf3D[]) var10.toArray(new Sdf3D[0])))
         .paint(
            SurfacePaint.field(
               (var0x, var1x, var2x) -> shine(
                     backHair(var1x),
                     var0x,
                     var1x,
                     var2x,
                     27.25F,
                     0.30000001192092896F,
                     6,
                     1.100000023841858F
                  )
            )
         );
      CharacterPartBuilder var10000 = at(
         var0.extra("hair_back", CharacterBone.HEAD),
         hp(
            0.0F, 28.200000762939453F, -1.600000023841858F
         )
      );
      Sdf3D[] var32 = new Sdf3D[2];
      var32[0] = var25;
      var32[1] = var26;
      var10000.shape(hs(SdfShapes.union(var32)))
         .motion(BoneMotionProfile.hair().hang(0.800000011920929F).drag(18.0F))
         .resolution(1.149999976158142F)
         .detail(0.8500000238418579F)
         .flatLight(0.3499999940395355F)
         .outline(-10794346, 0.10000000149011612F);
      float[] var30 = new float[24];
      var30[0] = -2.299999952316284F;
      var30[1] = 29.0F;
      var30[2] = -0.20000000298023224F;
      var30[3] = 0.5199999809265137F;
      var30[4] = -2.799999952316284F;
      var30[5] = 27.399999618530273F;
      var30[6] = -0.05000000074505806F;
      var30[7] = 0.5799999833106995F;
      var30[8] = -2.950000047683716F;
      var30[9] = 25.600000381469727F;
      var30[10] = 0.25F;
      var30[11] = 0.5600000023841858F;
      var30[12] = -2.799999952316284F;
      var30[13] = 23.799999237060547F;
      var30[14] = 1.0F;
      var30[15] = 0.5F;
      var30[16] = -2.6600000858306885F;
      var30[17] = 22.200000762939453F;
      var30[18] = 1.7000000476837158F;
      var30[19] = 0.46000000834465027F;
      var30[20] = -2.619999885559082F;
      var30[21] = 20.799999237060547F;
      var30[22] = 2.0199999809265137F;
      var30[23] = 0.41999998688697815F;
      TaperedTubeSdf3D var27 = SdfShapes.tube(var30)
         .flattenFrom(
            1.4500000476837158F,
            0.0F,
            22.0F,
            -0.5F
         );
      int var14 = 20;
      float[] var15 = new float[var14 * (4)];

      for (int var16 = 0; var16 < var14; var16++) {
         float var17 = (float)var16 / ((float)var14 - 1.0F);
         double var18 = 3.141592653589793
            + (double)var17
               * 3.141592653589793
               * 5.0;
         float var20 = 0.800000011920929F - 0.2199999988079071F * var17;
         var15[var16 * (4)] = -1.8200000524520874F + var20 * (float)Math.cos(var18);
         var15[var16 * (4) + (1)] = 20.799999237060547F
            - 3.299999952316284F * var17;
         var15[var16 * (4) + (2)] = 2.0199999809265137F + var20 * (float)Math.sin(var18);
         var15[var16 * (4) + (3)] = 0.41999998688697815F
            - 0.18000000715255737F * var17;
      }

      Sdf3D[] var31 = new Sdf3D[2];
      var31[0] = var27;
      var31[1] = SdfShapes.tube(var15);
      Sdf3D var28 = SdfShapes.union(var31)
         .paint(
            SurfacePaint.vertical(
               -7706904, 17.399999618530273F, -1912065, 25.0F
            )
         );
      CharacterPartBuilder var29 = at(
            var0.extra("curl_r", CharacterBone.HEAD),
            hp(
               -2.3499999046325684F, 28.700000762939453F, -0.15000000596046448F
            )
         )
         .shape(hs(var28))
         .resolution(0.8999999761581421F)
         .motion(
            BoneMotionProfile.hair()
               .drag(4.0F)
               .walk(
                  3.0F,
                  0.0F,
                  3.5F,
                  2.0F
               )
               .hang(0.699999988079071F)
               .turn(10.0F, 0.0F)
               .bend(1.399999976158142F)
         )
         .detail(0.8999999761581421F)
         .flatLight(0.4000000059604645F)
         .outline(-10794346, 0.10000000149011612F);
      var0.extra("curl_l", CharacterBone.HEAD).mirrorOf(var29);
   }

   public static int backHair(float var0) {
      if (var0 > 26.200000762939453F) {
         return ArgbColors.mix(
            -1912065,
            -6519080,
            clamp01((var0 - 26.200000762939453F) / 1.899999976158142F)
         );
      } else {
         return var0 > 22.0F
            ? ArgbColors.mix(
               -4940554,
               -1912065,
               clamp01((var0 - 22.0F) / 4.199999809265137F)
            )
            : ArgbColors.mix(
               -7706904,
               -4940554,
               clamp01((var0 - 17.200000762939453F) / 4.800000190734863F)
            );
      }
   }

   public static int shine(int var0, float var1, float var2, float var3, float var4, float var5, int var6, float var7) {
      float var8 = (float)Math.atan2((double)var1, (double)(var3 - -0.30000001192092896F));
      float var9 = Math.abs(
         var2 - var4 + 0.25F * (1.0F - (float)Math.cos((double)var8))
      );
      if (var9 > var5) {
         return var0;
      } else {
         float var10 = (float)Math.sin((double)(var8 * (float)var6 + var7)) + 0.20000000298023224F;
         if (var10 <= 0.0F) {
            return var0;
         } else {
            float var11 = (1.0F - var9 / var5)
               * Math.min(1.0F, var10 * 3.0F)
               * 0.800000011920929F;
            return ArgbColors.mix(
               var0,
               ArgbColors.mix(var0, -1, 0.5F),
               Math.min(1.0F, var11 * 1.600000023841858F)
            );
         }
      }
   }

   public static Sdf3D backLock(float var0, float var1, float var2, float var3, float var4, float var5, float var6) {
      double var7 = Math.toRadians((double)var0);
      float var9 = (float)Math.sin(var7);
      float var10 = (float)Math.cos(var7);
      float[] var10000 = new float[7];
      var10000[0] = 29.299999237060547F;
      var10000[1] = 27.600000381469727F;
      var10000[2] = 25.299999237060547F;
      var10000[3] = 23.0F;
      var10000[4] = 20.799999237060547F;
      var10000[5] = 18.899999618530273F;
      var10000[6] = var2;
      float[] var11 = var10000;
      float[] var12 = new float[var11.length * (3)];

      for (int var13 = 0; var13 < var11.length; var13++) {
         float var14 = var11[var13];
         float var15 = spline(CURTAIN_Y, CURTAIN_RX, var14) + var1;
         float var16 = spline(CURTAIN_Y, CURTAIN_RZ, var14) + var1;
         float var17 = spline(CURTAIN_Y, CURTAIN_CZ, var14);
         float var18 = 0.3199999928474426F
            * clamp01((26.5F - var14) / 5.0F)
            * (float)Math.sin((double)(var14 * 0.949999988079071F + var6));
         float var19 = var13 == var11.length - (1)
            ? 0.1599999964237213F
            : 0.0F;
         var12[var13 * (3)] = (var15 + var19) * var9 + var18 * var10;
         var12[var13 * (3) + (1)] = var14;
         var12[var13 * (3) + (2)] = var17 + (var16 + var19) * var10 - var18 * var9;
      }

      return SdfShapes.strand(var3, var4, var12).flatten(var5, var9, 0.0F, var10);
   }

   public static void hat(CharacterRig var0) {
      SurfacePaint var1 = SurfacePaint.vertical(
         -15460295, 28.600000381469727F, -14603682, 31.0F
      );
      Sdf3D var2 = SdfShapes.field(
            LunaDesign::brimDistance,
            -6.099999904632568F,
            28.100000381469727F,
            -6.349999904632568F,
            6.099999904632568F,
            30.100000381469727F,
            5.849999904632568F
         )
         .paint(var1);
      var0.extra("brim", CharacterBone.HEAD)
         .shape(worn(var2))
         .resolution(1.2000000476837158F)
         .detail(0.6499999761581421F)
         .outline(-15921370, 0.11999999731779099F);
      Sdf3D var3 = SdfShapes.field(
            LunaDesign::rimDistance,
            -6.199999809265137F,
            28.350000381469727F,
            -6.449999809265137F,
            6.199999809265137F,
            29.649999618530273F,
            5.949999809265137F
         )
         .paint(
            SurfacePaint.of(-1326758)
               .grain(0.6000000238418579F, 0.07999999821186066F)
         );
      Sdf3D var4 = SdfShapes.cone(
            0.0F,
            28.700000762939453F,
            -0.25F,
            3.430000066757202F,
            0.0F,
            31.200000762939453F,
            -0.30000001192092896F,
            3.0799999237060547F
         )
         .intersect(
            SdfShapes.box(
               0.0F,
               29.950000762939453F,
               -0.27000001072883606F,
               3.5999999046325684F,
               0.5F,
               3.5999999046325684F
            )
         )
         .subtract(
            SdfShapes.cone(
               0.0F,
               28.700000762939453F,
               -0.25F,
               2.75F,
               0.0F,
               31.200000762939453F,
               -0.30000001192092896F,
               2.4000000953674316F
            )
         )
         .paint(
            SurfacePaint.vertical(
               -6650664, 29.450000762939453F, -4544530, 30.299999237060547F
            )
         );
      CharacterPartBuilder var10000 = var0.extra(
         "hat_trim", CharacterBone.HEAD
      );
      Sdf3D[] var10001 = new Sdf3D[2];
      var10001[0] = var3;
      var10001[1] = var4;
      var10000.shape(worn(SdfShapes.union(var10001)))
         .resolution(0.949999988079071F)
         .detail(0.3499999940395355F)
         .noOutline();
      Sdf3D var5 = SdfShapes.cone(
            0.0F,
            28.700000762939453F,
            -0.25F,
            3.200000047683716F,
            0.0F,
            31.200000762939453F,
            -0.30000001192092896F,
            2.8499999046325684F
         )
         .intersect(
            SdfShapes.box(
               0.0F,
               29.600000381469727F,
               -0.27000001072883606F,
               3.5F,
               0.75F,
               3.5F
            )
         );
      var0.extra("hat", CharacterBone.HEAD)
         .shape(worn(var5.paint(var1)))
         .resolution(1.2000000476837158F)
         .detail(0.30000001192092896F)
         .outline(-15921370, 0.15000000596046448F);
      var0.extra("hat_pin", CharacterBone.HEAD)
         .shape(worn(pin()))
         .resolution(0.4000000059604645F)
         .detail(0.8999999761581421F)
         .outline(-8760296, 0.05999999865889549F);
      float[] var12 = new float[24];
      var12[0] = 0.0F;
      var12[1] = 30.200000762939453F;
      var12[2] = -0.28999999165534973F;
      var12[3] = 2.799999952316284F;
      var12[4] = 0.0F;
      var12[5] = 32.20000076293945F;
      var12[6] = -0.41999998688697815F;
      var12[7] = 2.240000009536743F;
      var12[8] = 0.0F;
      var12[9] = 34.099998474121094F;
      var12[10] = -0.7400000095367432F;
      var12[11] = 1.559999942779541F;
      var12[12] = 0.03999999910593033F;
      var12[13] = 35.29999923706055F;
      var12[14] = -1.4199999570846558F;
      var12[15] = 1.0199999809265137F;
      var12[16] = 0.14000000059604645F;
      var12[17] = 36.0F;
      var12[18] = -2.450000047683716F;
      var12[19] = 0.6399999856948853F;
      var12[20] = 0.30000001192092896F;
      var12[21] = 36.150001525878906F;
      var12[22] = -3.6500000953674316F;
      var12[23] = 0.36000001430511475F;
      Sdf3D var6 = SdfShapes.tube(var12)
         .intersect(SdfShapes.above(30.149999618530273F))
         .subtract(
            0.25F,
            SdfShapes.ellipsoid(
               0.0F,
               34.45000076293945F,
               -2.299999952316284F,
               0.8999999761581421F,
               0.3499999940395355F,
               0.44999998807907104F
            )
         )
         .paint(
            SurfacePaint.vertical(
               -14603682, 30.0F, -14011792, 37.0F
            )
         );
      Vec3 var7 = hatPoint(
         0.0F, 30.399999618530273F, -0.30000001192092896F
      );
      CharacterPartBuilder var8 = at(
            var0.extra("hat_tip", var0.part(CharacterBone.HEAD)),
            hp(var7.x(), var7.y(), var7.z())
         )
         .shape(worn(var6))
         .resolution(1.25F)
         .motion(
            new BoneMotionProfile()
               .idle(
                  2.0F,
                  0.0F,
                  2.0F,
                  0.30000001192092896F
               )
               .walk(
                  6.0F,
                  0.0F,
                  4.0F,
                  2.0F
               )
               .drag(7.0F)
               .hang(0.25F)
               .turn(10.0F, 0.0F)
               .spring(38.0F, 4.5F)
               .bend(1.7000000476837158F)
               .limit(35.0F)
         )
         .detail(0.75F)
         .outline(-15921370, 0.15000000596046448F);
      Vec3 var9 = hatPoint(
         0.2800000011920929F, 35.900001525878906F, -3.5F
      );
      float var13 = 0.07999999821186066F;
      float var15 = 0.07999999821186066F;
      float[] var10002 = new float[6];
      var10002[0] = var9.x();
      var10002[1] = var9.y();
      var10002[2] = var9.z();
      var10002[3] = var9.x();
      var10002[4] = var9.y() - 0.800000011920929F;
      var10002[5] = var9.z();
      Sdf3D var10 = SdfShapes.strand(var13, var15, var10002).color(-5011921);
      Sdf3D var11 = SdfShapes.extrude(
            Sdf2D.star(
                  0.0F,
                  0.0F,
                  0.6200000047683716F,
                  0.27000001072883606F,
                  5
               )
               .rotate(
                  180.0F,
                  0.0F,
                  0.0F
               ),
            0.14000000059604645F,
            0.05000000074505806F
         )
         .rotate(0.0F, 90.0F, 0.0F)
         .move(var9.x(), var9.y() - 1.2999999523162842F, var9.z())
         .paint(SurfacePaint.of(-9872).glow());
      var10000 = at(
         var0.extra("hat_charm", var8),
         hp(var9.x(), var9.y(), var9.z())
      );
      var10001 = new Sdf3D[2];
      var10001[0] = var10;
      var10001[1] = var11;
      var10000.shape(hs(SdfShapes.union(var10001)))
         .motion(
            BoneMotionProfile.hair()
               .hang(0.8999999761581421F)
               .spring(60.0F, 6.0F)
         )
         .resolution(0.44999998807907104F)
         .detail(1.2000000476837158F)
         .outline(-8760296, 0.05000000074505806F);
   }

   public static float brimDistance(float var0, float var1, float var2) {
      float var3 = var2 + 0.25F;
      float var4 = (float)Math.sqrt((double)(var0 * var0 + var3 * var3));
      return BRIM.distance(
         var4,
         var1
            - wave(
               var0,
               var3,
               var4,
               clamp01((var4 - 2.9000000953674316F) / 2.9000000953674316F)
            )
      );
   }

   public static float rimDistance(float var0, float var1, float var2) {
      float var3 = var2 + 0.25F;
      float var4 = (float)Math.sqrt((double)(var0 * var0 + var3 * var3));
      float var5 = var4 - 5.860000133514404F;
      float var6 = var1
         - 29.0F
         - wave(var0, var3, var4, 1.0F);
      return (float)Math.sqrt((double)(var5 * var5 + var6 * var6)) - 0.3100000023841858F;
   }

   public static float wave(float var0, float var1, float var2, float var3) {
      return var2 < 0.0010000000474974513F
         ? 0.0F
         : 0.30000001192092896F * var3 * var3 * (var0 * var0 - var1 * var1) / (var2 * var2);
   }

   public static Sdf3D pin() {
      Sdf2D var0 = Sdf2D.circle(
            0.0F, 0.0F, 0.6800000071525574F
         )
         .subtract(
            Sdf2D.circle(
               0.3400000035762787F, 0.18000000715255737F, 0.5199999809265137F
            )
         );
      Sdf2D var1 = Sdf2D.star(
            0.46000000834465027F,
            0.14000000059604645F,
            0.3799999952316284F,
            0.17000000178813934F,
            5
         )
         .rotate(180.0F, 0.46000000834465027F, 0.14000000059604645F);
      Sdf3D[] var10000 = new Sdf3D[2];
      var10000[0] = SdfShapes.extrude(
            var0, 0.14000000059604645F, 0.05999999865889549F
         )
         .paint(
            SurfacePaint.radial(
                  -4688,
                  -0.30000001192092896F,
                  -0.20000000298023224F,
                  0.0F,
                  0.800000011920929F,
                  -1326758
               )
               .glow()
         );
      var10000[1] = SdfShapes.extrude(
            var1, 0.11999999731779099F, 0.05000000074505806F
         )
         .move(0.0F, 0.0F, 0.03999999910593033F)
         .paint(SurfacePaint.of(-9872).glow());
      Sdf3D var2 = SdfShapes.union(var10000);
      double var3 = Math.toRadians(38.0);
      float var5 = 3.380000114440918F;
      return var2.rotate(
            -8.0F, 38.0F, 0.0F
         )
         .move(
            var5 * (float)Math.sin(var3),
            29.950000762939453F,
            -0.25F + var5 * (float)Math.cos(var3)
         );
   }

   public static Sdf3D worn(Sdf3D var0) {
      return hs(
         var0.rotate(
            -8.0F,
            0.0F,
            4.0F,
            HAT_CENTRE.x(),
            HAT_CENTRE.y(),
            HAT_CENTRE.z()
         )
      );
   }

   public static Vec3 hatPoint(float var0, float var1, float var2) {
      return new Vec3(var0, var1, var2)
         .rotate(
            -8.0F,
            0.0F,
            4.0F,
            HAT_CENTRE
         );
   }

   public static void body(CharacterRig var0) {
      Sdf3D var1 = SdfShapes.ellipsoid(
         0.0F,
         21.350000381469727F,
         0.05000000074505806F,
         2.200000047683716F,
         1.75F,
         1.399999976158142F
      );
      Sdf3D var2 = SdfShapes.capsule(
            0.0F,
            22.950000762939453F,
            -0.15000000596046448F,
            -2.450000047683716F,
            22.399999618530273F,
            -0.15000000596046448F,
            0.7200000286102295F
         )
         .mirrorX();
      Sdf3D var3 = SdfShapes.ellipsoid(
         0.0F,
         19.0F,
         0.0F,
         1.6200000047683716F,
         1.5F,
         1.149999976158142F
      );
      Sdf3D var4 = SdfShapes.ellipsoid(
         0.0F,
         16.799999237060547F,
         -0.05000000074505806F,
         2.200000047683716F,
         1.75F,
         1.5F
      );
      float var10000 = 1.100000023841858F;
      Sdf3D[] var10001 = new Sdf3D[4];
      var10001[0] = var1;
      var10001[1] = var2;
      var10001[2] = var3;
      var10001[3] = var4;
      Sdf3D var5 = SdfShapes.blend(var10000, var10001);
      Sdf3D var6 = var5.paint(
         SurfacePaint.vertical(
            -14933168, 16.5F, -13945223, 22.5F
         )
      );
      Sdf3D var7 = SdfShapes.capsule(
            0.0F,
            22.899999618530273F,
            -0.15000000596046448F,
            0.0F,
            25.100000381469727F,
            -0.05000000074505806F,
            0.6000000238418579F
         )
         .paint(
            SurfacePaint.vertical(
                  -6958,
                  23.700000762939453F,
                  -1331558,
                  24.200000762939453F
               )
               .flatLight(1.0F)
               .occlusion(0.25F)
         );
      Sdf3D var8 = SdfShapes.cone(
            0.0F,
            22.5F,
            -0.11999999731779099F,
            1.0199999809265137F,
            0.0F,
            24.299999237060547F,
            -0.10000000149011612F,
            0.7799999713897705F
         )
         .intersect(
            SdfShapes.box(
               0.0F,
               23.450000762939453F,
               -0.10000000149011612F,
               1.2999999523162842F,
               0.6299999952316284F,
               1.2999999523162842F
            )
         );
      Sdf3D var9 = var5.inflate(0.2199999988079071F)
         .intersect(
            SdfShapes.box(
               0.0F,
               18.450000762939453F,
               0.0F,
               3.0F,
               0.6000000238418579F,
               3.0F
            )
         )
         .paint(
            SurfacePaint.vertical(
               -11653344, 17.899999618530273F, -8762574, 18.899999618530273F
            )
         );
      CharacterPartBuilder var17 = var0.part(CharacterBone.BODY)
         .pivot(0.0F, 24.5F, 0.0F);
      var10001 = new Sdf3D[3];
      var10001[0] = var6;
      var10001[1] = var7;
      var10001[2] = var9;
      var17.shape(SdfShapes.union(var10001))
         .resolution(1.2000000476837158F)
         .detail(0.8999999761581421F)
         .occlusion(0.30000001192092896F)
         .outline(-15921370, 0.14000000059604645F)
         .decal(bodiceTrim());
      var0.extra("collar", CharacterBone.BODY)
         .shape(
            var8.paint(
               SurfacePaint.vertical(
                  -15460295, 22.899999618530273F, -13945223, 24.049999237060547F
               )
            )
         )
         .resolution(0.6000000238418579F)
         .detail(0.3499999940395355F)
         .occlusion(0.30000001192092896F)
         .outline(-15921370, 0.07999999821186066F);
      ArrayList var10 = new ArrayList();
      float var11 = surfaceZ(
         var5, 0.0F, 23.100000381469727F, 4.0F
      );
      float var12 = Math.max(
         var11,
         surfaceZ(
            var8, 0.0F, 23.100000381469727F, 4.0F
         )
      );
      var10.add(
         SdfShapes.ellipsoid(
               0.0F,
               23.079999923706055F,
               var12 + 0.11999999731779099F,
               0.30000001192092896F,
               0.25999999046325684F,
               0.20000000298023224F
            )
            .color(-4544530)
      );
      var10.add(
         SdfShapes.ellipsoid(
               0.6000000238418579F,
               23.139999389648438F,
               var12 + 0.019999999552965164F,
               0.5F,
               0.30000001192092896F,
               0.18000000715255737F
            )
            .rotate(
               0.0F,
               -18.0F,
               -14.0F,
               0.6000000238418579F,
               23.139999389648438F,
               var12
            )
            .mirrorX()
            .color(-4544530)
      );

      for (int var13 = -1; var13 <= (1); var13 += 2) {
         float var14 = surfaceZ(
            var5,
            (float)var13 * 0.3499999940395355F,
            22.299999237060547F,
            4.0F
         );
         float var15 = surfaceZ(
            var5,
            (float)var13 * 0.550000011920929F,
            21.600000381469727F,
            4.0F
         );
         float var19 = 0.2199999988079071F;
         float var10002 = 0.1599999964237213F;
         float[] var10003 = new float[9];
         var10003[0] = (float)var13 * 0.11999999731779099F;
         var10003[1] = 22.950000762939453F;
         var10003[2] = var12 + 0.07999999821186066F;
         var10003[3] = (float)var13 * 0.3499999940395355F;
         var10003[4] = 22.299999237060547F;
         var10003[5] = var14 + 0.14000000059604645F;
         var10003[6] = (float)var13 * 0.550000011920929F;
         var10003[7] = 21.600000381469727F;
         var10003[8] = var15 + 0.11999999731779099F;
         var10.add(
            SdfShapes.strand(var19, var10002, var10003)
               .flatten(
                  1.7000000476837158F,
                  0.0F,
                  0.0F,
                  1.0F
               )
               .color(-4544530)
         );
      }

      var10.add(
         SdfShapes.sphere(
               0.0F,
               23.079999923706055F,
               var12 + 0.30000001192092896F,
               0.17000000178813934F
            )
            .paint(SurfacePaint.of(-4678401).glow())
      );
      float var16 = surfaceZ(
         var9, 0.0F, 18.450000762939453F, 4.0F
      );
      var10.add(
         SdfShapes.extrude(
               Sdf2D.star(
                     0.0F,
                     0.0F,
                     0.5600000023841858F,
                     0.25F,
                     5
                  )
                  .rotate(
                     180.0F,
                     0.0F,
                     0.0F
                  ),
               0.17000000178813934F,
               0.05000000074505806F
            )
            .move(
               0.0F,
               18.450000762939453F,
               var16 + 0.07999999821186066F
            )
            .color(-1326758)
      );
      var0.extra("trim", CharacterBone.BODY)
         .shape(SdfShapes.union(((Sdf3D[]) var10.toArray(new Sdf3D[0]))))
         .resolution(0.5F)
         .detail(0.550000011920929F)
         .noOutline();
   }

   public static void cape(CharacterRig var0) {
      Sdf3D var1 = SdfShapes.field(
            LunaDesign::capeDistance,
            -6.0F,
            6.300000190734863F,
            -6.199999809265137F,
            6.0F,
            25.399999618530273F,
            1.2999999523162842F
         )
         .paint(SurfacePaint.field(LunaDesign::capeColor));
      var0.extra("cape", CharacterBone.BODY)
         .pivot(0.0F, 23.0F, -1.0F)
         .shape(var1)
         .resolution(1.350000023841858F)
         .motion(BoneMotionProfile.cloth().drag(12.0F).hang(0.6000000238418579F))
         .detail(0.44999998807907104F)
         .occlusion(0.30000001192092896F)
         .noOutline()
         .decal(capeStars())
         .decal(capeHem());
   }

   public static float capeAt(int var0, float var1) {
      float var2 = (var1 - CAPE_Y[0])
         / (CAPE_Y[CAPE_Y.length - (1)] - CAPE_Y[0])
         * 96.0F;
      var2 = var2 < 0.0F
         ? 0.0F
         : Math.min(var2, 96.0F);
      int var3 = Math.min((int)var2, 95);
      float var4 = CAPE_LUT[var3 * (4) + var0];
      return var4 + (CAPE_LUT[var3 * (4) + (4) + var0] - var4) * (var2 - (float)var3);
   }

   public static float[] capeTable() {
      float[] var0 = new float[388];

      for (int var1 = 0; var1 <= (96); var1++) {
         float var2 = CAPE_Y[0]
            + (CAPE_Y[CAPE_Y.length - (1)] - CAPE_Y[0])
               * (float)var1
               / 96.0F;
         var0[var1 * (4)] = spline(CAPE_Y, CAPE_RX, var2);
         var0[var1 * (4) + (1)] = spline(
            CAPE_Y, CAPE_RZ, var2
         );
         var0[var1 * (4) + (2)] = spline(CAPE_Y, CAPE_CZ, var2);
         var0[var1 * (4) + (3)] = spline(CAPE_Y, CAPE_WRAP, var2);
      }

      return var0;
   }

   public static float capeDistance(float var0, float var1, float var2) {
      float var3 = capeAt(0, var1);
      float var4 = capeAt(1, var1);
      float var5 = capeAt(2, var1);
      float var6 = Math.abs(ellipse(var0, var2 - var5, var3, var4)) - 0.4300000071525574F;
      if (var6 < 0.6000000238418579F) {
         float var7 = (float)Math.toDegrees(Math.atan2((double)(Math.abs(var0) / var3), (double)(-(var2 - var5) / var4)));
         var6 = Math.max(
            var6,
            (var7 - capeAt(3, var1))
               * 0.017453299835324287F
               * (var3 + var4)
               * 0.5F
         );
      }

      var6 = Math.max(var6, Math.max(var1 - 23.399999618530273F, 7.0F - var1));
      if (var1 < 22.5F) {
         return var6;
      } else {
         float var13 = clamp01((var1 - 22.899999618530273F) / 2.299999952316284F);
         float var8 = 1.4500000476837158F + 0.3499999940395355F * var13;
         float var9 = 1.2999999523162842F + 0.30000001192092896F * var13;
         float var10 = Math.abs(ellipse(var0, var2 + 0.30000001192092896F, var8, var9))
            - 0.3799999952316284F;
         if (var10 < 0.6000000238418579F) {
            float var11 = (float)Math.toDegrees(
               Math.atan2((double)(Math.abs(var0) / var8), (double)(-(var2 + 0.30000001192092896F) / var9))
            );
            var10 = Math.max(
               var10,
               (var11 - 118.0F)
                  * 0.017453299835324287F
                  * 1.5F
            );
         }

         var10 = Math.max(var10, Math.max(var1 - 25.200000762939453F, 22.799999237060547F - var1));
         return Math.min(var6, var10);
      }
   }

   public static int capeColor(float var0, float var1, float var2) {
      float var3 = capeAt(0, var1);
      float var4 = capeAt(1, var1);
      float var5 = capeAt(2, var1);
      if (var1 > 22.899999618530273F) {
         float var6 = clamp01((var1 - 22.899999618530273F) / 2.299999952316284F);
         float var7 = ellipse(
            var0,
            var2 + 0.30000001192092896F,
            1.4500000476837158F + 0.3499999940395355F * var6,
            1.2999999523162842F + 0.30000001192092896F * var6
         );
         if (Math.abs(var7) < Math.abs(ellipse(var0, var2 - var5, var3, var4))) {
            return var7 > 0.0F ? -14603682 : -7571752;
         }
      }

      float var8 = ellipse(var0, var2 - var5, var3, var4);
      return var8 < 0.0F
         ? -7571752
         : ArgbColors.mix(
            -15460295,
            -14603682,
            clamp01((var1 - 7.0F) / 14.0F)
         );
   }

   public static SurfaceDecal capeStars() {
      PixelCanvas var0 = new PixelCanvas(176, 176);
      long var1 = 7L;

      for (int var3 = 0; var3 < (36); var3++) {
         long var4 = var1 * (6364136223846793005L) + (1442695040888963407L);
         float var6 = 7.0F
            + (float)((var4 >>> (33)) % (162L));
         long var7 = var4 * (6364136223846793005L) + (1442695040888963407L);
         float var9 = 8.0F
            + (float)((var7 >>> (33)) % (160L));
         var1 = var7 * (6364136223846793005L) + (1442695040888963407L);
         float var10 = 2.799999952316284F
            + (float)((var1 >>> (33)) % (3L));
         int var11 = (var1 >>> (40)) % (3L) == (0L)
            ? 1
            : 0;
         Sdf2D var12 = var11 != 0
            ? Sdf2D.star(
               var6,
               var9,
               var10 * 1.2999999523162842F,
               var10 * 0.30000001192092896F,
               4
            )
            : Sdf2D.star(var6, var9, var10, var10 * 0.46000000834465027F, 5);
         var0.fill(var12, var11 != 0 ? -598638 : -1326758);
      }

      var0.fill(
         Sdf2D.circle(
               88.0F, 92.0F, 19.0F
            )
            .subtract(
               Sdf2D.circle(
                  97.0F, 86.0F, 16.0F
               )
            ),
         -1326758
      );
      var0.fill(
         Sdf2D.star(
            97.0F,
            88.0F,
            7.5F,
            3.200000047683716F,
            5
         ),
         -598638
      );
      return SurfaceDecal.back(
            var0,
            0.0F,
            12.5F,
            -3.0F,
            11.0F,
            11.0F
         )
         .depth(4.0F, 4.0F)
         .maxAngle(62.0F);
   }

   public static SurfaceDecal capeHem() {
      PixelCanvas var0 = new PixelCanvas(192, 12);
      paintBand(var0);
      return SurfaceDecal.wrap(
            var0,
            0.0F,
            7.269999980926514F,
            -0.800000011920929F,
            0.0F,
            1.0F,
            0.0F,
            0.0F,
            0.0F,
            -1.0F,
            230.0F,
            0.47999998927116394F
         )
         .offset(0.029999999329447746F);
   }

   public static void paintBand(PixelCanvas var0) {
      float var1 = (float)var0.height();
      float var2 = var1 * 2.0F;
      var0.fillAll(
         (var2x, var3) -> {
            float var4 = var3 / var1;
            if (var4 < 0.10000000149011612F || var4 > 0.8999999761581421F) {
               return 0;
            } else if (!(var4 < 0.23999999463558197F) && !(var4 > 0.7599999904632568F)) {
               float var5 = ((float)Math.floor((double)(var2x / var2)) + 0.5F) * var2;
               return Math.abs(var2x - var5) + Math.abs(var3 - var1 * 0.5F)
                     < var1 * 0.2199999988079071F
                  ? -2868
                  : -1326758;
            } else {
               return -5011921;
            }
         }
      );
   }

   public static PixelCanvas lace(int var0, int var1) {
      PixelCanvas var2 = new PixelCanvas(var0, 16);
      float var3 = (float)var0 / (float)var1;
      var2.fill(
         Sdf2D.box(
            (float)var0 * 0.5F,
            3.0F,
            (float)var0 * 0.5F,
            3.0F,
            0.0F
         ),
         -1036
      );

      for (int var4 = 0; var4 < var1; var4++) {
         float var5 = ((float)var4 + 0.5F) * var3;
         var2.fill(
            Sdf2D.circle(var5, 6.5F, var3 * 0.5199999809265137F),
            -1036
         );
         var2.erase(Sdf2D.circle(var5, 6.800000190734863F, var3 * 0.1599999964237213F));
      }

      return var2;
   }

   public static void skirt(CharacterRig var0, PixelCanvas var1) {
      PixelCanvas var2 = lace(448, 34);

      for (int var3 = -1; var3 <= (1); var3 += 2) {
         CharacterBone var4 = var3 < 0 ? CharacterBone.RIGHT_LEG : CharacterBone.LEFT_LEG;
         Sdf3D[] var10000 = new Sdf3D[3];
         var10000[0] = tier(
               var3,
               18.5F,
               12.399999618530273F,
               1.75F,
               3.450000047683716F,
               2.5F,
               11.0F,
               0.23999999463558197F,
               0.7799999713897705F,
               6.0F,
               16.0F
            )
            .shape(-13945223, -15460295);
         var10000[1] = tier(
               var3,
               13.399999618530273F,
               9.100000381469727F,
               3.0999999046325684F,
               3.950000047683716F,
               1.2999999523162842F,
               14.0F,
               0.2800000011920929F,
               0.7400000095367432F,
               14.0F,
               22.0F
            )
            .shape(-12693598, -14603682);
         var10000[2] = tier(
               var3,
               9.550000190734863F,
               8.600000381469727F,
               3.700000047683716F,
               4.050000190734863F,
               1.0F,
               20.0F,
               0.1599999964237213F,
               0.7400000095367432F,
               20.0F,
               24.0F
            )
            .shape(-4611086, -7571752);
         Sdf3D var5 = SdfShapes.union(var10000);
         var0.extra(
               var3 < 0
                  ? "skirt_r"
                  : "skirt_l",
               CharacterBone.BODY
            )
            .pivot(
               0.0F, 18.200000762939453F, 0.0F
            )
            .shape(var5)
            .resolution(1.149999976158142F)
            .motion(
               BoneMotionProfile.skirt(var4)
                  .follow(var4, 0.30000001192092896F, 12.0F)
            )
            .detail(0.4000000059604645F)
            .occlusion(0.30000001192092896F)
            .noOutline()
            .decal(
               hemBand(
                  var1,
                  12.579999923706055F,
                  (float)var3 * 76.0F,
                  140.0F,
                  0.36000001430511475F
               )
            )
            .decal(
               hemBand(
                  var1,
                  9.279999732971191F,
                  (float)var3 * 79.0F,
                  134.0F,
                  0.36000001430511475F
               )
            )
            .decal(
               hemBand(
                  var2,
                  8.800000190734863F,
                  (float)var3 * 80.0F,
                  132.0F,
                  0.3400000035762787F
               )
            );
      }

      LunaDesign.FoldedShape var6 = new LunaDesign.FoldedShape(
         18.200000762939453F,
         8.699999809265137F,
         1.600000023841858F,
         2.9000000953674316F,
         1.600000023841858F,
         16.0F,
         0.11999999731779099F,
         0.6600000262260437F,
         -42.0F,
         -42.0F,
         42.0F,
         42.0F
      );
      var0.extra("underskirt", CharacterBone.BODY)
         .pivot(0.0F, 18.200000762939453F, 0.20000000298023224F)
         .shape(var6.shape(-4611086, -7571752))
         .resolution(1.100000023841858F)
         .motion(
            new BoneMotionProfile()
               .drag(-8.0F)
               .walk(
                  -5.0F,
                  0.0F,
                  0.0F,
                  2.0F
               )
               .walkPhase(90.0F)
               .spring(120.0F, 14.0F)
               .bend(1.0F)
         )
         .detail(0.4000000059604645F)
         .occlusion(0.30000001192092896F)
         .noOutline()
         .decal(underskirtStars());
   }

   public static LunaDesign.FoldedShape tier(
      int var0, float var1, float var2, float var3, float var4, float var5, float var6, float var7, float var8, float var9, float var10
   ) {
      return var0 > 0
         ? new LunaDesign.FoldedShape(
            var1,
            var2,
            var3,
            var4,
            var5,
            var6,
            var7,
            var8,
            var9,
            var10,
            188.0F,
            188.0F
         )
         : new LunaDesign.FoldedShape(
            var1,
            var2,
            var3,
            var4,
            var5,
            var6,
            var7,
            var8,
            -188.0F,
            -188.0F,
            -var9,
            -var10
         );
   }

   public static SurfaceDecal hemBand(PixelCanvas var0, float var1, float var2, float var3, float var4) {
      double var5 = Math.toRadians((double)var2);
      return SurfaceDecal.wrap(
            var0,
            0.0F,
            var1,
            0.0F,
            0.0F,
            1.0F,
            0.0F,
            (float)Math.sin(var5),
            0.0F,
            (float)Math.cos(var5),
            var3,
            var4
         )
         .offset(0.029999999329447746F);
   }

   public static SurfaceDecal underskirtStars() {
      PixelCanvas var0 = new PixelCanvas(192, 288);
      long var1 = 3L;

      for (int var3 = 0; var3 < (20); var3++) {
         long var4 = var1 * (6364136223846793005L) + (1442695040888963407L);
         float var6 = 12.0F
            + (float)((var4 >>> (33)) % (168L));
         var1 = var4 * (6364136223846793005L) + (1442695040888963407L);
         float var7 = 88.0F
            + (float)((var1 >>> (33)) % (170L));
         var0.fill(
            Sdf2D.star(
               var6, var7, 5.400000095367432F, 1.7000000476837158F, 4
            ),
            -1326758
         );
      }

      for (int var8 = 0; var8 < (18); var8++) {
         float var9 = ((float)var8 + 0.5F)
            * 192.0F
            / 18.0F;
         var0.fill(
            Sdf2D.circle(var9, 278.0F, 6.199999809265137F),
            -1036
         );
         var0.erase(Sdf2D.circle(var9, 278.5F, 1.899999976158142F));
      }

      var0.fill(
         Sdf2D.box(
            96.0F,
            272.0F,
            96.0F,
            4.0F,
            0.0F
         ),
         -1036
      );
      return SurfaceDecal.front(
            var0,
            0.0F,
            13.5F,
            3.0F,
            6.400000095367432F,
            9.600000381469727F
         )
         .depth(3.5F, 3.0F)
         .maxAngle(66.0F);
   }

   public static SurfaceDecal bodiceTrim() {
      PixelCanvas var0 = new PixelCanvas(64, 96);

      for (int var1 = -1; var1 <= (1); var1 += 2) {
         float var10001 = 2.0F;
         float var10002 = 2.0F;
         float[] var10003 = new float[6];
         var10003[0] = 32.0F + (float)var1 * 10.5F;
         var10003[1] = 2.0F;
         var10003[2] = 32.0F + (float)var1 * 9.0F;
         var10003[3] = 48.0F;
         var10003[4] = 32.0F + (float)var1 * 9.800000190734863F;
         var10003[5] = 94.0F;
         var0.fill(Sdf2D.path(var10001, var10002, var10003), -1326758);
      }

      for (int var3 = 0; var3 < (4); var3++) {
         float var2 = 13.0F + (float)var3 * 21.0F;
         var0.fill(
            Sdf2D.circle(32.0F, var2, 5.0F),
            -5011921
         );
         var0.fill(
            Sdf2D.circle(32.0F, var2, 4.0F),
            -1326758
         );
         var0.fill(
            Sdf2D.circle(
               30.799999237060547F,
               var2 - 1.2999999523162842F,
               1.5F
            ),
            -2868
         );
      }

      return SurfaceDecal.front(
            var0,
            0.0F,
            20.600000381469727F,
            3.0F,
            2.0F,
            3.0F
         )
         .depth(2.5F, 2.0F)
         .maxAngle(70.0F);
   }

   private static Sdf3D fore(Sdf3D var0, int var1) {
      float var11 = var1 * 3.0F;
      float var13 = var1;
      float var15 = ELBOW.x();
      float var14 = var13 * var15;
      float var17 = ELBOW.y();
      float var18 = ELBOW.z();
      return var0.rotate(-12.0F, 0.0F, var11, var14, var17, var18);
   }

   private static Vec3 fore(float var0, float var1, float var2) {
      Vec3 var3 = new Vec3(var0, var1, var2);
      Vec3 var11 = ELBOW;
      return var3.rotate(-12.0F, 0.0F, 3.0F, var11);
   }

   public static void arms(CharacterRig var0, PixelCanvas var1) {
      SurfacePaint var2 = SurfacePaint.of(-6958)
         .flatLight(1.0F)
         .occlusion(0.25F);
      Sdf3D var3 = SdfShapes.ellipsoid(
         -3.5F,
         22.0F,
         -0.10000000149011612F,
         0.9200000166893005F,
         1.0F,
         0.8999999761581421F
      );
      Sdf3D var4 = SdfShapes.cone(
         -3.549999952316284F,
         21.5F,
         -0.10000000149011612F,
         0.6600000262260437F,
         -3.7200000286102295F,
         18.450000762939453F,
         -0.05000000074505806F,
         0.550000011920929F
      );
      Sdf3D var5 = SdfShapes.sphere(
         -3.7200000286102295F,
         18.399999618530273F,
         -0.05000000074505806F,
         0.550000011920929F
      );
      Sdf3D var6 = fore(
         SdfShapes.cone(
            -3.7200000286102295F,
            18.299999237060547F,
            -0.05000000074505806F,
            0.5400000214576721F,
            -3.8399999141693115F,
            15.600000381469727F,
            0.11999999731779099F,
            0.5F
         ),
         1
      );
      float var10000 = 0.3499999940395355F;
      Sdf3D[] var10001 = new Sdf3D[4];
      var10001[0] = var3;
      var10001[1] = var4;
      var10001[2] = var5;
      var10001[3] = var6;
      Sdf3D var7 = SdfShapes.blend(var10000, var10001)
         .paint(
            SurfacePaint.vertical(
               -14867372, 15.0F, -13945223, 22.0F
            )
         );
      Sdf3D var8 = fore(
            SdfShapes.cone(
                  -3.8399999141693115F,
                  16.100000381469727F,
                  0.11999999731779099F,
                  0.5199999809265137F,
                  -3.9200000762939453F,
                  14.300000190734863F,
                  0.20000000298023224F,
                  1.0199999809265137F
               )
               .intersect(SdfShapes.above(14.300000190734863F)),
            1
         )
         .color(-13945223);
      Sdf3D var9 = fore(
            SdfShapes.cone(
               -3.8399999141693115F,
               15.699999809265137F,
               0.11999999731779099F,
               0.20000000298023224F,
               -3.930000066757202F,
               14.0F,
               0.20000000298023224F,
               0.5F
            ),
            1
         )
         .color(-7571752);
      Sdf3D[] var22 = new Sdf3D[2];
      var22[0] = var7;
      var22[1] = SdfShapes.subtract(var8, var9);
      Sdf3D var10 = SdfShapes.union(var22);
      Vec3 var11 = fore(
         -4.0F, 13.300000190734863F, 0.41999998688697815F
      );
      Vec3 var12 = fore(
         -3.9100000858306885F, 14.520000457763672F, 0.20000000298023224F
      );
      Vec3 var13 = new Vec3(
            -0.03999999910593033F, 1.0F, 0.05000000074505806F
         )
         .rotate(-12.0F, 0.0F, 3.0F);
      Vec3 var14 = new Vec3(
            0.0F, 0.0F, 1.0F
         )
         .rotate(-12.0F, 0.0F, 3.0F);
      CharacterPartBuilder var15 = var0.part(CharacterBone.RIGHT_ARM)
         .pivot(-3.5F, 22.299999237060547F, -0.10000000149011612F)
         .grip(var11.x(), var11.y(), var11.z())
         .shape(var10)
         .resolution(0.949999988079071F)
         .detail(0.75F)
         .occlusion(0.30000001192092896F)
         .outline(-15921370, 0.12999999523162842F)
         .swing(0.800000011920929F)
         .joint(ELBOW.x(), ELBOW.y(), ELBOW.z(), 0.550000011920929F)
         .decal(
            SurfaceDecal.wrap(
                  var1,
                  var12.x(),
                  var12.y(),
                  var12.z(),
                  var13.x(),
                  var13.y(),
                  var13.z(),
                  var14.x(),
                  var14.y(),
                  var14.z(),
                  360.0F,
                  0.36000001430511475F
               )
               .offset(0.029999999329447746F)
         );
      var0.part(CharacterBone.LEFT_ARM).mirrorOf(var15);
      ArrayList var16 = new ArrayList();
      var16.add(
         SdfShapes.cone(
            3.9200000762939453F,
            14.600000381469727F,
            0.2199999988079071F,
            0.33000001311302185F,
            3.9700000286102295F,
            13.800000190734863F,
            0.2800000011920929F,
            0.33000001311302185F
         )
      );
      var16.add(
         SdfShapes.ellipsoid(
            4.0F,
            13.25F,
            0.3199999928474426F,
            0.27000001072883606F,
            0.6000000238418579F,
            0.5199999809265137F
         )
      );
      float[] var23 = new float[4];
      var23[0] = -24.0F;
      var23[1] = -19.0F;
      var23[2] = -14.0F;
      var23[3] = -8.0F;
      float[] var17 = var23;

      for (int var18 = 0; var18 < (4); var18++) {
         float var19 = 0.019999999552965164F + (float)var18 * 0.20999999344348907F;
         float var20 = var18 != 0 && var18 != (3)
            ? 0.800000011920929F
            : 0.6200000047683716F;
         var16.add(
            SdfShapes.capsule(
                  4.019999980926514F,
                  12.800000190734863F,
                  var19,
                  3.940000057220459F,
                  12.800000190734863F - var20,
                  var19 + 0.10000000149011612F,
                  0.11999999731779099F
               )
               .rotate(
                  0.0F,
                  0.0F,
                  var17[var18],
                  4.019999980926514F,
                  12.850000381469727F,
                  var19
               )
         );
      }

      var16.add(
         SdfShapes.capsule(
            3.859999895095825F,
            13.350000381469727F,
            0.7599999904632568F,
            3.740000009536743F,
            12.75F,
            0.9599999785423279F,
            0.14000000059604645F
         )
      );
      CharacterPartBuilder var21 = var0.extra(
            "hand_l", CharacterBone.LEFT_ARM
         )
         .shape(
            fore(
               SdfShapes.blend(
                     0.18000000715255737F, ((Sdf3D[]) var16.toArray(new Sdf3D[0]))
                  )
                  .paint(var2),
               -1
            )
         )
         .resolution(0.5F)
         .detail(0.6000000238418579F)
         .outline(-5737368, 0.07999999821186066F);
      var0.extra("hand_r", CharacterBone.RIGHT_ARM).mirrorOf(var21);
   }

   public static void legs(CharacterRig var0) {
      Sdf3D var1 = SdfShapes.cone(
         -1.2999999523162842F,
         15.300000190734863F,
         0.0F,
         1.1799999475479126F,
         -1.100000023841858F,
         8.600000381469727F,
         0.07999999821186066F,
         0.8199999928474426F
      );
      Sdf3D var2 = SdfShapes.sphere(
         -1.0800000429153442F,
         8.25F,
         0.14000000059604645F,
         0.7799999713897705F
      );
      Sdf3D var3 = SdfShapes.sphere(
         -1.0800000429153442F,
         8.300000190734863F,
         0.44999998807907104F,
         0.550000011920929F
      );
      Sdf3D var4 = SdfShapes.cone(
         -1.0800000429153442F,
         8.0F,
         0.10000000149011612F,
         0.800000011920929F,
         -1.1399999856948853F,
         2.0999999046325684F,
         -0.10000000149011612F,
         0.5F
      );
      Sdf3D var5 = SdfShapes.ellipsoid(
         -1.1200000047683716F,
         5.900000095367432F,
         -0.30000001192092896F,
         0.8500000238418579F,
         1.5F,
         0.8999999761581421F
      );
      float var10000 = 0.44999998807907104F;
      Sdf3D[] var10001 = new Sdf3D[5];
      var10001[0] = var1;
      var10001[1] = var2;
      var10001[2] = var3;
      var10001[3] = var4;
      var10001[4] = var5;
      Sdf3D var6 = SdfShapes.blend(var10000, var10001)
         .paint(SurfacePaint.field(LunaDesign::tights));
      Sdf3D var7 = SdfShapes.cone(
            -1.1200000047683716F,
            4.900000095367432F,
            -0.07999999821186066F,
            0.800000011920929F,
            -1.100000023841858F,
            1.5F,
            -0.10000000149011612F,
            0.6200000047683716F
         )
         .intersect(SdfShapes.below(5.0F));
      Sdf3D var8 = SdfShapes.ellipsoid(
         -1.100000023841858F,
         0.47999998927116394F,
         1.0F,
         0.6000000238418579F,
         0.47999998927116394F,
         0.8199999928474426F
      );
      Sdf3D var9 = SdfShapes.ellipsoid(
         -1.100000023841858F,
         1.0F,
         0.25F,
         0.6399999856948853F,
         0.6200000047683716F,
         0.8999999761581421F
      );
      var10000 = 0.3499999940395355F;
      var10001 = new Sdf3D[3];
      var10001[0] = var7;
      var10001[1] = var8;
      var10001[2] = var9;
      Sdf3D var10 = SdfShapes.blend(var10000, var10001)
         .paint(
            SurfacePaint.vertical(
               -9550799, 0.5F, -7710146, 4.599999904632568F
            )
         );
      Sdf3D var11 = SdfShapes.box(
            -1.100000023841858F,
            0.41999998688697815F,
            -0.5F,
            0.4000000059604645F,
            0.41999998688697815F,
            0.36000001430511475F,
            0.14000000059604645F
         )
         .color(-12704232);
      Sdf3D var12 = SdfShapes.box(
            -1.100000023841858F,
            0.11999999731779099F,
            0.9700000286102295F,
            0.6399999856948853F,
            0.11999999731779099F,
            0.800000011920929F,
            0.10000000149011612F
         )
         .color(-12966888);
      Sdf3D var13 = SdfShapes.torus(
            -1.100000023841858F,
            1.75F,
            -0.05000000074505806F,
            0.6200000047683716F,
            0.25999999046325684F
         )
         .color(-11653344);
      Sdf3D var14 = SdfShapes.ellipsoid(
            -1.7200000286102295F,
            1.75F,
            0.5699999928474426F,
            0.23999999463558197F,
            0.30000001192092896F,
            0.14000000059604645F
         )
         .rotate(
            0.0F,
            -45.0F,
            0.0F,
            -1.7200000286102295F,
            1.75F,
            0.5699999928474426F
         )
         .color(-1326758);
      Sdf3D[] var21 = new Sdf3D[5];
      var21[0] = var10;
      var21[1] = var11;
      var21[2] = var12;
      var21[3] = var13;
      var21[4] = var14;
      Sdf3D var15 = SdfShapes.union(var21)
         .rotate(
            0.0F,
            -7.0F,
            0.0F,
            -1.1200000047683716F,
            0.0F,
            -0.10000000149011612F
         );
      Sdf3D[] var22 = new Sdf3D[2];
      var22[0] = var6;
      var22[1] = var15;
      Sdf3D var16 = SdfShapes.union(var22)
         .intersect(SdfShapes.above(0.0F));
      CharacterPartBuilder var17 = var0.part(CharacterBone.RIGHT_LEG)
         .pivot(-1.2999999523162842F, 15.300000190734863F, 0.0F)
         .shape(var16)
         .resolution(1.2000000476837158F)
         .detail(0.75F)
         .occlusion(0.30000001192092896F)
         .outline(-14411226, 0.12999999523162842F)
         .swing(0.550000011920929F, 30.0F)
         .joint(
            -1.0800000429153442F,
            8.25F,
            0.14000000059604645F,
            0.800000011920929F
         );
      var0.part(CharacterBone.LEFT_LEG).mirrorOf(var17);
      Sdf3D var18 = SdfShapes.cylinder(
            -1.1200000047683716F,
            4.449999809265137F,
            -0.07999999821186066F,
            -1.1200000047683716F,
            5.179999828338623F,
            -0.07999999821186066F,
            0.9399999976158142F,
            0.18000000715255737F
         )
         .paint(
            SurfacePaint.vertical(
               -7710146, 4.5F, -6395064, 5.099999904632568F
            )
         );
      CharacterPartBuilder var19 = var0.extra(
            "cuff_r", CharacterBone.RIGHT_LEG
         )
         .shape(var18)
         .resolution(0.699999988079071F)
         .detail(0.8999999761581421F)
         .occlusion(0.30000001192092896F)
         .outline(-12966888, 0.07999999821186066F);
      var0.extra("cuff_l", CharacterBone.LEFT_LEG).mirrorOf(var19);
   }

   public static int tights(float var0, float var1, float var2) {
      float var3 = -1.100000023841858F
         - 0.20000000298023224F
            * clamp01((var1 - 8.0F) / 7.0F);
      float var4 = 0.05000000074505806F;
      float var5 = (float)Math.atan2((double)(var0 - var3), (double)(var2 - var4));
      float var6 = (float)Math.exp(
         (double)(
            -(var5 + 0.3499999940395355F)
               * (var5 + 0.3499999940395355F)
               / 0.1599999964237213F
         )
      );
      int var7 = ArgbColors.mix(
         ArgbColors.shade(-12959880, 0.8199999928474426F),
         -12959880,
         clamp01((var1 - 3.0F) / 6.0F)
      );
      return ArgbColors.mix(var7, -10656082, 0.550000011920929F * var6);
   }

   public static SurfaceDecal faceDecal(List<LunaDesign.CurvedShape> var0) {
      PixelCanvas var1 = new PixelCanvas(192, 158);
      Sdf2D var2 = null;

      for (LunaDesign.CurvedShape var4 : var0) {
         Sdf2D var5 = var4.shadow(0.2800000011920929F).inflate(3.7333333492279053F);
         var2 = var2 == null ? var5 : var2.union(var5);
      }

      var1.fill(
         var2,
         ArgbColors.withAlpha(-1199194, 0.550000011920929F),
         4.0F
      );
      var1.draw(features(), 12, 44);
      Vec3 var6 = hp(
         0.0F, 26.90625F, 3.0F
      );
      return SurfaceDecal.front(
            var1, var6.x(), var6.y(), var6.z(), 4.859999656677246F, 3.9993748664855957F
         )
         .depth(3.0F, 3.0F)
         .maxAngle(74.0F)
         .occlusion(0.30000001192092896F)
         .flatLight(1.0F);
   }

   public static PixelCanvas features() {
      float var0 = 0.5833333134651184F;
      PixelCanvas var1 = new PixelCanvas(168, 114);
      PixelCanvas var2 = new PixelCanvas(64, 80);
      eye(
         new LunaDesign.CanvasTransform(var2, var0, 60.0F, 96.0F),
         122.0F,
         181.0F,
         -1
      );
      var1.draw(var2, 7, 0);
      var1.draw(var2.mirrored(), 97, 0);
      LunaDesign.CanvasTransform var3 = new LunaDesign.CanvasTransform(
         var1, var0, 48.0F, 96.0F
      );

      for (int var4 = -1; var4 <= (1); var4 += 2) {
         float var5 = 192.0F + (float)var4 * 70.0F;
         float var6 = 181.0F;
         var3.fill(
            Sdf2D.star(
               var5 - 10.0F,
               var6 - 13.0F,
               14.0F,
               3.799999952316284F,
               4
            ),
            -1
         );
         var3.fill(
            Sdf2D.circle(
               var5 - 10.0F,
               var6 - 13.0F,
               4.800000190734863F
            ),
            -1
         );
         var3.fill(
            Sdf2D.star(
               var5 + 12.0F,
               var6 + 17.0F,
               7.0F,
               2.0999999046325684F,
               4
            ),
            -285212673
         );
         var3.fill(
            Sdf2D.circle(
               var5 + 10.0F,
               var6 - 2.0F,
               2.299999952316284F
            ),
            -1191182337
         );
         var3.fill(
            Sdf2D.ellipse(
               192.0F + (float)var4 * 96.0F,
               226.0F,
               27.0F,
               12.0F
            ),
            1895793815,
            12.0F
         );
      }

      var3.fill(
         Sdf2D.curve(
            191.0F,
            232.0F,
            195.0F,
            238.0F,
            190.0F,
            242.0F,
            2.4000000953674316F,
            1.600000023841858F
         ),
         -2135459206
      );
      var3.fill(
         Sdf2D.curve(
            180.0F,
            275.0F,
            192.0F,
            284.0F,
            204.0F,
            275.0F,
            3.200000047683716F,
            3.200000047683716F
         ),
         -7060390
      );
      var3.fill(
         Sdf2D.curve(
            188.0F,
            285.0F,
            192.0F,
            287.0F,
            196.0F,
            285.0F,
            1.7999999523162842F,
            1.7999999523162842F
         ),
         1438670960
      );
      return var1;
   }

   public static void eye(LunaDesign.CanvasTransform var0, float var1, float var2, int var3) {
      Sdf2D var4 = Sdf2D.ellipse(
         var1,
         var2 + 2.0F,
         37.0F,
         46.0F
      );
      float var10003 = var2 - 44.0F;
      float var10005 = var2 - 8.0F;
      int[] var10006 = new int[2];
      var10006[0] = -3160852;
      var10006[1] = -1;
      var0.fill(var4, ColorField2D.linear(var1, var10003, var1, var10005, var10006));
      float var10001 = var2 - 36.0F;
      var10003 = var2 + 44.0F;
      int[] var10004 = new int[4];
      var10004[0] = -14282676;
      var10004[1] = -11194192;
      var10004[2] = -6656782;
      var10004[3] = -2044673;
      ColorField2D var5 = ColorField2D.linear(var1, var10001, var1, var10003, var10004);
      var0.fill(
         Sdf2D.ellipse(
               var1,
               var2 + 4.0F,
               29.0F,
               41.0F
            )
            .intersect(var4),
         (var3x, var4x) -> {
            float var5x = (var3x - var1) / 32.0F;
            float var6x = (var4x - var2 + 28.0F) / 19.0F;
            float var7x = (var3x - var1) / 18.0F;
            float var8x = (var4x - var2 - 27.0F) / 10.0F;
            float var9x = (var3x - var1) / 29.0F;
            float var10x = (var4x - var2 - 4.0F) / 41.0F;
            float var11x = clamp01(
                  (1.0F - (float)Math.sqrt((double)(var5x * var5x + var6x * var6x)))
                     * 8.0F
               )
               * 0.4699999988079071F;
            float var12x = clamp01(
                  (1.0F - (float)Math.sqrt((double)(var7x * var7x + var8x * var8x)))
                     * 5.0F
               )
               * 0.5F;
            float var13x = clamp01(
                  ((float)Math.sqrt((double)(var9x * var9x + var10x * var10x)) - 0.8799999952316284F)
                     / 0.05999999865889549F
               )
               * 0.8199999928474426F;
            int var14x = ArgbColors.mix(
               ArgbColors.mix(var5.argb(var3x, var4x), -14676416, var11x), -726785, var12x
            );
            return ArgbColors.mix(var14x, -14479041, var13x);
         }
      );
      var0.fill(
         Sdf2D.ellipse(
            var1,
            var2 + 5.0F,
            12.0F,
            17.0F
         ),
         -15136210
      );
      var10001 = 6.0F;
      float var10002 = 12.0F;
      float[] var12 = new float[12];
      var12[0] = var1 - (float)var3 * 37.0F;
      var12[1] = var2 - 6.0F;
      var12[2] = var1 - (float)var3 * 24.0F;
      var12[3] = var2 - 36.0F;
      var12[4] = var1 + (float)var3 * 2.0F;
      var12[5] = var2 - 48.0F;
      var12[6] = var1 + (float)var3 * 25.0F;
      var12[7] = var2 - 42.0F;
      var12[8] = var1 + (float)var3 * 39.0F;
      var12[9] = var2 - 26.0F;
      var12[10] = var1 + (float)var3 * 50.0F;
      var12[11] = var2 - 32.0F;
      var0.fill(Sdf2D.path(var10001, var10002, var12), -14938064);
      var0.fill(
         Sdf2D.curve(
            var1 + (float)var3 * 40.0F,
            var2 - 28.0F,
            var1 + (float)var3 * 52.0F,
            var2 - 40.0F,
            var1 + (float)var3 * 58.0F,
            var2 - 50.0F,
            5.0F,
            1.0F
         ),
         -14938064
      );
      var0.fill(
         Sdf2D.curve(
            var1 + (float)var3 * 30.0F,
            var2 - 38.0F,
            var1 + (float)var3 * 38.0F,
            var2 - 50.0F,
            var1 + (float)var3 * 40.0F,
            var2 - 58.0F,
            3.5F,
            1.0F
         ),
         -14938064
      );
      var0.fill(
         Sdf2D.curve(
            var1 + (float)var3 * 6.0F,
            var2 + 48.0F,
            var1 + (float)var3 * 26.0F,
            var2 + 44.0F,
            var1 + (float)var3 * 35.0F,
            var2 + 28.0F,
            1.5F,
            4.0F
         ),
         -1069931696
      );
      var10001 = 2.0F;
      var10002 = 2.0F;
      float[] var13 = new float[6];
      var13[0] = var1 - (float)var3 * 18.0F;
      var13[1] = var2 - 55.0F;
      var13[2] = var1 + (float)var3 * 4.0F;
      var13[3] = var2 - 60.0F;
      var13[4] = var1 + (float)var3 * 27.0F;
      var13[5] = var2 - 53.0F;
      var0.fill(Sdf2D.path(var10001, var10002, var13), 1883909461);
      var10001 = 5.5F;
      var10002 = 2.0F;
      float[] var14 = new float[6];
      var14[0] = var1 - (float)var3 * 28.0F;
      var14[1] = var2 - 70.0F;
      var14[2] = var1 + (float)var3 * 2.0F;
      var14[3] = var2 - 82.0F;
      var14[4] = var1 + (float)var3 * 36.0F;
      var14[5] = var2 - 76.0F;
      var0.fill(Sdf2D.path(var10001, var10002, var14), -7703368);
   }

   public static float ellipse(float var0, float var1, float var2, float var3) {
      float var4 = var0 / var2;
      float var5 = var1 / var3;
      float var6 = (float)Math.sqrt((double)(var4 * var4 + var5 * var5));
      float var7 = (float)Math.sqrt((double)(var4 * var4 / (var2 * var2) + var5 * var5 / (var3 * var3)));
      return var7 < 9.999999974752427e-07F ? -Math.min(var2, var3) : var6 * (var6 - 1.0F) / var7;
   }

   public static float spline(float[] var0, float[] var1, float var2) {
      int var3 = var0.length;
      if (var2 <= var0[0]) {
         return var1[0];
      } else if (var2 >= var0[var3 - (1)]) {
         return var1[var3 - (1)];
      } else {
         int var4 = 0;

         while (var4 < var3 - (2) && var2 > var0[var4 + (1)]) {
            var4++;
         }

         float var5 = (var2 - var0[var4]) / (var0[var4 + (1)] - var0[var4]);
         float var6 = var0[var4 + (1)] - var0[var4];
         float var7 = var4 == 0
            ? (var1[1] - var1[0]) / (var0[1] - var0[0])
            : (var1[var4 + (1)] - var1[var4 - (1)])
               / (var0[var4 + (1)] - var0[var4 - (1)]);
         float var8 = var4 + (2) >= var3
            ? (var1[var3 - (1)] - var1[var3 - (2)])
               / (var0[var3 - (1)] - var0[var3 - (2)])
            : (var1[var4 + (2)] - var1[var4]) / (var0[var4 + (2)] - var0[var4]);
         float var9 = var5 * var5;
         float var10 = var9 * var5;
         return (
                  2.0F * var10
                     - 3.0F * var9
                     + 1.0F
               )
               * var1[var4]
            + (var10 - 2.0F * var9 + var5) * var6 * var7
            + (-2.0F * var10 + 3.0F * var9)
               * var1[var4 + (1)]
            + (var10 - var9) * var6 * var8;
      }
   }

   public static float surfaceZ(Sdf3D var0, float var1, float var2, float var3) {
      float var4 = var3;

      for (int var5 = 0; var5 < (80); var5++) {
         float var6 = var0.distance(var1, var2, var4);
         if (Math.abs(var6) < 0.0010000000474974513F) {
            break;
         }

         var4 -= var6;
      }

      return var4;
   }

   public static float clamp01(float var0) {
      return var0 < 0.0F
         ? 0.0F
         : Math.min(var0, 1.0F);
   }

   static {
      float[] var9;
      (var9 = new float[6])[0] = 7.0F;
      var9[1] = 10.0F;
      var9[2] = 13.5F;
      var9[3] = 17.0F;
      var9[4] = 20.5F;
      var9[5] = 23.4F;
      CAPE_Y = var9;
      float[] var11;
      (var11 = new float[6])[0] = 5.15F;
      var11[1] = 4.85F;
      var11[2] = 4.15F;
      var11[3] = 3.45F;
      var11[4] = 3.2F;
      var11[5] = 3.15F;
      CAPE_RX = var11;
      float[] var13;
      (var13 = new float[6])[0] = 4.45F;
      var13[1] = 4.2F;
      var13[2] = 3.5F;
      var13[3] = 2.3F;
      var13[4] = 1.62F;
      var13[5] = 1.3F;
      CAPE_RZ = var13;
      float[] var15;
      (var15 = new float[6])[0] = -0.8F;
      var15[1] = -0.85F;
      var15[2] = -0.85F;
      var15[3] = -0.6F;
      var15[4] = -0.45F;
      var15[5] = -0.35F;
      CAPE_CZ = var15;
      float[] var17;
      (var17 = new float[6])[0] = 104.0F;
      var17[1] = 102.0F;
      var17[2] = 100.0F;
      var17[3] = 105.0F;
      var17[4] = 118.0F;
      var17[5] = 132.0F;
      CAPE_WRAP = var17;
      CAPE_LUT = capeTable();
      float[] var20;
      (var20 = new float[6])[0] = 17.0F;
      var20[1] = 20.0F;
      var20[2] = 22.5F;
      var20[3] = 24.5F;
      var20[4] = 27.6F;
      var20[5] = 29.3F;
      CURTAIN_Y = var20;
      float[] var22;
      (var22 = new float[6])[0] = 3.2F;
      var22[1] = 3.05F;
      var22[2] = 2.95F;
      var22[3] = 2.95F;
      var22[4] = 3.12F;
      var22[5] = 2.35F;
      CURTAIN_RX = var22;
      float[] var24;
      (var24 = new float[6])[0] = 3.0F;
      var24[1] = 2.65F;
      var24[2] = 2.25F;
      var24[3] = 2.55F;
      var24[4] = 3.05F;
      var24[5] = 2.35F;
      CURTAIN_RZ = var24;
      float[] var26;
      (var26 = new float[6])[0] = -0.95F;
      var26[1] = -0.95F;
      var26[2] = -0.9F;
      var26[3] = -0.65F;
      var26[4] = -0.3F;
      var26[5] = -0.3F;
      CURTAIN_CZ = var26;
   }

   @Environment(EnvType.CLIENT)
   private static final class CanvasTransform {
      private final PixelCanvas canvas;
      private final float k;
      private final float ox;
      private final float oy;

      CanvasTransform(PixelCanvas var1, float var2, float var3, float var4) {
         this.canvas = var1;
         this.k = var2;
         this.ox = var3;
         this.oy = var4;
      }

      private Sdf2D map(Sdf2D var1) {
         float var2 = this.k / (this.k - 1.0F);
         return var1.scale(this.k, this.ox * var2, this.oy * var2);
      }

      void fill(Sdf2D var1, int var2) {
         this.canvas.fill(this.map(var1), var2);
      }

      void fill(Sdf2D var1, int var2, float var3) {
         this.canvas.fill(this.map(var1), var2, var3 * this.k);
      }

      void fill(Sdf2D var1, ColorField2D var2) {
         this.canvas
            .fill(
               this.map(var1),
               (var2x, var3) -> var2.argb(
                     var2x / this.k + this.ox, var3 / this.k + this.oy
                  )
            );
      }
   }

   @Environment(EnvType.CLIENT)
   private static final class CurvedShape {
      private static final float CONSTANT_0102 = 2.6F;
      private final float rad;
      private final float top;
      private final float tip;
      private final float width;
      private final float hook;
      private final float g0;
      private final float lift;
      private final float g1;
      private final float t0;
      private final float t1;
      private final float[] ys;
      private final float[] rs;
      private final float[] poly;
      private final Sdf2D outline;

      CurvedShape(
         float var1, float var2, float var3, float var4, float var5, float var6, float var7, float var8, float var9, float var10, float[] var11, float[] var12
      ) {
         this.rad = (float)Math.toRadians((double)var1);
         this.top = var2;
         this.tip = var3;
         this.width = var4;
         this.hook = var5;
         this.g0 = var6;
         this.lift = var7;
         this.g1 = var8;
         this.t0 = var9;
         this.t1 = var10;
         this.ys = var11;
         this.rs = var12;
         int var13 = 7;
         float var14 = var5 > 0.0F
            ? -1.0F
            : 1.0F;
         this.poly = new float[((2) * var13 + (3)) * (2)];
         int var15 = 0;
         this.poly[var15++] = var14 * var4;
         this.poly[var15++] = var2 + 0.5F;

         for (int var16 = 0; var16 <= var13; var16++) {
            float var17 = 1.0F
               - (float)Math.pow(
                  (double)(1.0F - (float)var16 / (float)var13),
                  1.399999976158142
               );
            this.poly[var15++] = var5 * var17 * var17
               + var14
                  * var4
                  * (float)Math.pow(
                     (double)(1.0F - var17), 0.800000011920929
                  );
            this.poly[var15++] = var2 + (var3 - var2) * var17;
         }

         for (int var23 = var13 - (1); var23 >= 0; var23--) {
            float var24 = 1.0F
               - (float)Math.pow(
                  (double)(1.0F - (float)var23 / (float)var13),
                  1.399999976158142
               );
            this.poly[var15++] = var5 * var24 * var24
               - var14
                  * var4
                  * (float)Math.pow(
                     (double)(1.0F - var24), 1.25
                  );
            this.poly[var15++] = var2 + (var3 - var2) * var24;
         }

         this.poly[var15++] = -var14 * var4;
         this.poly[var15] = var2 + 0.5F;
         this.outline = Sdf2D.polygon(this.poly);
      }

      private float gap(float var1) {
         float var2 = 1.0F - var1;
         return this.g0 * var2 * var2
            + 2.0F * this.lift * var1 * var2
            + this.g1 * var1 * var1;
      }

      float distance(float var1, float var2, float var3) {
         float var4 = var3 - -0.30000001192092896F;
         float var5 = (float)Math.sqrt((double)(var1 * var1 + var4 * var4));
         float var6 = LunaDesign.clamp01((this.top - var2) / (this.top - this.tip));
         float var7 = LunaDesign.interp(this.ys, this.rs, var2)
            + this.gap(var6);
         float var8 = this.t0 + (this.t1 - this.t0) * var6;
         float var9 = Math.max(var7 - var5, var5 - var7 - var8);
         if (var9 > 0.800000011920929F) {
            return var9;
         } else {
            float var10 = 2.5999999046325684F * ((float)Math.atan2((double)var1, (double)var4) - this.rad);
            float var11 = this.outline.distance(var10, var2);
            if (var11 > 0.800000011920929F) {
               return var11;
            } else {
               float var12 = Math.min(
                  1.0F,
                  Math.abs(var10 - this.hook * var6 * var6)
                     / (this.width * (1.0F - var6) + 0.05000000074505806F)
               );
               var9 = Math.max(
                  var7 - var5, var5 - var7 - var8 * (1.0F - 0.3499999940395355F * var12 * var12)
               );
               float var13 = LunaDesign.clamp01(
                  0.5F
                     - 0.5F * (var9 - var11) / 0.07000000029802322F
               );
               return var9
                  + (var11 - var9) * var13
                  + 0.07000000029802322F * var13 * (1.0F - var13);
            }
         }
      }

      Sdf3D shape() {
         float var1 = 3.4028234663852886e+38F;
         float var2 = -3.4028234663852886e+38F;
         float var3 = 3.4028234663852886e+38F;
         float var4 = 0.0F;

         for (int var5 = 0; var5 < this.poly.length; var5 += 2) {
            var1 = Math.min(var1, this.poly[var5]);
            var2 = Math.max(var2, this.poly[var5]);
         }

         float[] var18 = this.rs;
         int var6 = var18.length;

         for (int var7 = 0; var7 < var6; var7++) {
            float var8 = var18[var7];
            var3 = Math.min(var3, var8);
            var4 = Math.max(var4, var8);
         }

         var3 = Math.max(
            0.20000000298023224F,
            var3 + Math.min(this.g0, this.g1) - 0.15000000596046448F
         );
         var4 += Math.max(this.g0, Math.max(this.lift, this.g1))
            + this.t0
            + 0.15000000596046448F;
         float var19 = 3.4028234663852886e+38F;
         float var20 = -3.4028234663852886e+38F;
         float var21 = 3.4028234663852886e+38F;
         float var22 = -3.4028234663852886e+38F;

         for (int var9 = 0; var9 <= (12); var9++) {
            double var10 = (double)(
               this.rad
                  + (var1 + (var2 - var1) * (float)var9 / 12.0F) / 2.5999999046325684F
            );
            float[] var10000 = new float[2];
            var10000[0] = var3;
            var10000[1] = var4;
            float[] var12 = var10000;
            int var13 = var12.length;

            for (int var14 = 0; var14 < var13; var14++) {
               float var15 = var12[var14];
               var19 = Math.min(var19, var15 * (float)Math.sin(var10));
               var20 = Math.max(var20, var15 * (float)Math.sin(var10));
               var21 = Math.min(var21, -0.30000001192092896F + var15 * (float)Math.cos(var10));
               var22 = Math.max(var22, -0.30000001192092896F + var15 * (float)Math.cos(var10));
            }
         }

         return SdfShapes.field(
            this::distance,
            var19 - 0.10000000149011612F,
            this.tip - 0.15000000596046448F,
            var21 - 0.10000000149011612F,
            var20 + 0.10000000149011612F,
            this.top + 0.6000000238418579F,
            var22 + 0.10000000149011612F
         );
      }

      Sdf2D shadow(float var1) {
         float[] var2 = (float[])this.poly.clone();

         for (int var3 = 0; var3 < var2.length; var3 += 2) {
            float var4 = var2[var3 + (1)];
            float var5 = LunaDesign.interp(this.ys, this.rs, var4)
               + this.gap(
                  LunaDesign.clamp01((this.top - var4) / (this.top - this.tip))
               )
               + this.t0 * 0.5F;
            var2[var3] = (
                  var5 * (float)Math.sin((double)(this.rad + var2[var3] / 2.5999999046325684F))
                     - -2.3142857551574707F
               )
               * 41.48147964477539F;
            var2[var3 + (1)] = (28.810714721679688F - var4 + var1) * 41.48147964477539F;
         }

         return Sdf2D.polygon(var2);
      }
   }

   @Environment(EnvType.CLIENT)
   private static final class FoldedShape {
      private static final int CONSTANT_0251 = 48;
      private final float yTop;
      private final float yBot;
      private final float rTop;
      private final float rBot;
      private final float folds;
      private final float amp;
      private final float half;
      private final float a0Top;
      private final float a0Bot;
      private final float a1Top;
      private final float a1Bot;
      private final float[] shapeField = new float[98];

      FoldedShape(
         float var1, float var2, float var3, float var4, float var5, float var6, float var7, float var8, float var9, float var10, float var11, float var12
      ) {
         this.yTop = var1;
         this.yBot = var2;
         this.rTop = var3;
         this.rBot = var4;
         this.folds = var6;
         this.amp = var7;
         this.half = var8 * 0.5F;
         this.a0Top = var9;
         this.a0Bot = var10;
         this.a1Top = var11;
         this.a1Bot = var12;

         for (int var13 = 0; var13 <= (48); var13++) {
            float var14 = Math.min((float)var13 / 48.0F, 0.9990000128746033F);
            this.shapeField[var13 * (2)] = 1.0F
               - (float)Math.pow((double)(1.0F - var14), (double)var5);
            this.shapeField[var13 * (2) + (1)] = var5
               * (float)Math.pow((double)(1.0F - var14), (double)(var5 - 1.0F));
         }
      }

      private float u(float var1) {
         return LunaDesign.clamp01(
            (this.yTop - var1) / (this.yTop - this.yBot)
         );
      }

      private float table(int var1, float var2) {
         float var3 = var2 * 48.0F;
         int var4 = Math.min((int)var3, 47);
         float var5 = this.shapeField[var4 * (2) + var1];
         return var5 + (this.shapeField[var4 * (2) + (2) + var1] - var5) * (var3 - (float)var4);
      }

      float radius(float var1, float var2, float var3) {
         float var4 = this.u(var2);
         return this.rTop
            + (this.rBot - this.rTop) * this.table(0, var4)
            + this.amp * var4 * (float)Math.cos((double)this.folds * Math.atan2((double)var1, (double)var3));
      }

      float distance(float var1, float var2, float var3) {
         float var4 = this.u(var2);
         float var5 = this.yTop - this.yBot;
         float var6 = (float)Math.sqrt((double)(var1 * var1 + var3 * var3));
         float var7 = this.rTop
            + (this.rBot - this.rTop) * this.table(0, var4);
         float var8 = Math.abs(var6 - var7) - this.half - this.amp;
         if (var8 > 0.6000000238418579F) {
            return Math.max(
               var8 * 0.699999988079071F, Math.max(var2 - this.yTop, this.yBot - var2)
            );
         } else {
            double var9 = Math.atan2((double)var1, (double)var3);
            float var11 = (float)Math.cos((double)this.folds * var9);
            float var12 = (float)Math.sin((double)this.folds * var9);
            float var13 = var7 + this.amp * var4 * var11;
            float var14 = (
                  (this.rBot - this.rTop) * this.table(1, var4)
                     + this.amp * var11
               )
               / var5;
            float var15 = this.amp
               * var4
               * this.folds
               * var12
               / Math.max(var6, 0.5F);
            float var16 = (Math.abs(var6 - var13) - this.half)
               / (float)Math.sqrt((double)(1.0F + var14 * var14 + var15 * var15));
            var16 = Math.max(var16, Math.max(var2 - this.yTop, this.yBot - var2));
            double var17 = Math.toRadians((double)(this.a0Top + (this.a0Bot - this.a0Top) * var4));
            double var19 = Math.toRadians((double)(this.a1Top + (this.a1Bot - this.a1Top) * var4));
            double var21 = var9 - (var17 + var19) * 0.5;

            while (var21 > 3.141592653589793) {
               var21 -= 6.283185307179586;
            }

            while (var21 < -3.141592653589793) {
               var21 += 6.283185307179586;
            }

            return Math.max(var16, (float)(Math.abs(var21) - (var19 - var17) * 0.5) * var6);
         }
      }

      Sdf3D shape(int var1, int var2) {
         float var3 = Math.max(this.rTop, this.rBot)
            + this.amp
            + this.half
            + 0.20000000298023224F;
         float var4 = Math.min(this.a0Top, this.a0Bot);
         float var5 = Math.max(this.a1Top, this.a1Bot);
         float var6 = 0.0F;
         float var7 = 0.0F;
         float var8 = 0.0F;
         float var9 = 0.0F;

         for (int var10 = 0; var10 <= (64); var10++) {
            double var11 = Math.toRadians((double)(var4 + (var5 - var4) * (float)var10 / 64.0F));
            var6 = Math.min(var6, (float)Math.sin(var11) * var3);
            var7 = Math.max(var7, (float)Math.sin(var11) * var3);
            var8 = Math.min(var8, (float)Math.cos(var11) * var3);
            var9 = Math.max(var9, (float)Math.cos(var11) * var3);
         }

         Sdf3D var13 = SdfShapes.field(
            this::distance,
            var6 - 0.30000001192092896F,
            this.yBot - 0.20000000298023224F,
            var8 - 0.30000001192092896F,
            var7 + 0.30000001192092896F,
            this.yTop + 0.20000000298023224F,
            var9 + 0.30000001192092896F
         );
         return var13.paint(
            SurfacePaint.field(
               (var3x, var4x, var5x) -> {
                  float var6x = (float)Math.sqrt((double)(var3x * var3x + var5x * var5x));
                  return var6x < this.radius(var3x, var4x, var5x)
                     ? var2
                     : ArgbColors.mix(
                        ArgbColors.shade(var1, 0.800000011920929F),
                        var1,
                        LunaDesign.clamp01(
                           (var4x - this.yBot)
                              / (this.yTop - this.yBot)
                              * 1.600000023841858F
                        )
                     );
               }
            )
         );
      }
   }
}

