package krispy.feature;

import krispy.event.EventListener;
import krispy.event.events.TickEvent;
import krispy.mixin.MinecraftClientAccessor;
import krispy.module.Category;
import krispy.module.Module;
import krispy.module.setting.NumberSetting;
import krispy.utils.EncryptedString;
import krispy.utils.InventoryUtil;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.FoodComponent;
import net.minecraft.item.ItemStack;

public final class AutoEatModule extends Module {
   private final NumberSetting healthThreshold;
   private final NumberSetting hungerThreshold;
   public boolean isEa;
   private int selectedFoodSlot;
   private int previousSelectedSlot;

   public AutoEatModule() {
      super(
         EncryptedString.of("Auto Eat"),
         EncryptedString.of(" It detects whenever the hungerbar/health falls a certain threshold, selects food in your hotbar, and starts eating."),
         -1,
         Category.MISC
      );
      this.healthThreshold = new NumberSetting(EncryptedString.of("Health Threshold"), 0.0, 19.0, 17.0, 1.0);
      this.hungerThreshold = new NumberSetting(EncryptedString.of("Hunger Threshold"), 0.0, 19.0, 19.0, 1.0);
      this.addSettings(this.healthThreshold, this.hungerThreshold);
   }

   @Override
   public void onEnable() {
      super.onEnable();
   }

   @Override
   public void onDisable() {
      super.onDisable();
   }

   @EventListener
   public void onTick(TickEvent event) {
      if (!this.isEa) {
         if (this.shouldEat()) {
            this.selectedFoodSlot = this.findBestFoodSlot();
            if (this.selectedFoodSlot != -1) {
               this.saveCurrentSlot();
            }
         }
         return;
      }

      if (!this.shouldEat()) {
         this.stopEating();
         return;
      }
      ItemStack selected = this.mc.player.getInventory().getStack(this.selectedFoodSlot);
      if (selected.get(DataComponentTypes.FOOD) != null) {
         int bestSlot = this.findBestFoodSlot();
         if (bestSlot == -1) {
            this.stopEating();
            return;
         }
         this.selectSlot(bestSlot);
      }
      this.startEating();
   }

   public boolean shouldEat() {
      float healthDifference = this.mc.player.getHealth() - (float)this.healthThreshold.getIntValue();
      boolean lowHealth = healthDifference <= 0.0F;
      boolean lowHunger = this.mc.player.getHungerManager().getFoodLevel() <= this.hungerThreshold.getIntValue();
      return this.findBestFoodSlot() != -1 && (lowHealth || lowHunger);
   }

   private int findBestFoodSlot() {
      int bestSlot = -1;
      int bestNutrition = -1;
      for (int slot = 0; slot < 9; slot++) {
         ItemStack stack = this.mc.player.getInventory().getStack(slot);
         FoodComponent food = stack.get(DataComponentTypes.FOOD);
         if (food != null) {
            int nutrition = food.nutrition();
            if (nutrition > bestNutrition) {
               bestSlot = slot;
               bestNutrition = nutrition;
            }
         }
      }
      return bestSlot;
   }

   private void saveCurrentSlot() {
      this.previousSelectedSlot = this.mc.player.getInventory().getSelectedSlot();
      this.startEating();
   }

   private void startEating() {
      this.selectSlot(this.selectedFoodSlot);
      this.setUseKeyPressed(true);
      if (!this.mc.player.isUsingItem()) {
         ((MinecraftClientAccessor)this.mc).invokeDoItemUse();
      }
      this.isEa = true;
   }

   private void stopEating() {
      this.selectSlot(this.previousSelectedSlot);
      this.setUseKeyPressed(false);
      this.isEa = false;
   }

   private void setUseKeyPressed(boolean pressed) {
      this.mc.options.useKey.setPressed(pressed);
   }

   private void selectSlot(int slot) {
      InventoryUtil.swap(slot);
      this.selectedFoodSlot = slot;
   }
}
