package krispy.utils;

import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.pipeline.RenderPipeline.Snippet;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.vertex.VertexFormat.DrawMode;
import java.awt.Color;
import java.util.List;
import krispy.mixin.RenderLayerAccessor;
import krispy.mixin.RenderPipelinesAccessor;
import net.minecraft.client.gl.UniformType;
import net.minecraft.client.render.RenderSetup;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.util.math.Vec3d;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.util.Identifier;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.MathHelper;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.client.render.BuiltBuffer;
import net.minecraft.client.util.math.MatrixStack.Entry;
import org.joml.Matrix3x2fStack;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;
import org.joml.Vector4f;

public final class RenderUtils {
   private static DrawContext activeContext;
   private static boolean usingUnscaledProjection;
   private static long lastGuiFrameNanos;
   private static Vec3d screenCenter;
   private static Vec3d worldRenderOrigin = Vec3d.ZERO;
   private static final Matrix4f inverseProjectionScratch = new Matrix4f();
   private static final Matrix4f inverseViewScratch = new Matrix4f();
   private static final Vector4f centerScratch = new Vector4f();

   private RenderUtils() {
   }

   public static void setContext(DrawContext var0) {
      activeContext = var0;
   }

   public static Vec3d getCameraPos() {
      return getCamera().getCameraPos();
   }

   public static Camera getCamera() {
      return MinecraftClient.getInstance().gameRenderer.getCamera();
   }

   public static void updateScreenCenter(Matrix4f var0, Matrix4f var1) {
      try {
         Matrix4f var2 = inverseProjectionScratch.set(var0).invert();
         Matrix4f var3 = inverseViewScratch.set(var1).invert();
         Vector4f var4 = centerScratch.set(0.0F, 0.0F, 0.0F, 1.0F).mul(var2).mul(var3);
         var4.div(var4.w);
         Vec3d var5 = getCamera().getCameraPos();
         screenCenter = new Vec3d(var5.x + (double)var4.x, var5.y + (double)var4.y, var5.z + (double)var4.z);
         RenderVisibility.begin(var0, var1, var5.x, var5.y, var5.z);
      } catch (RuntimeException var6) {
         screenCenter = null;
         RenderVisibility.disable();
      }
   }

   public static Vec3d getTracerStart(Camera var0) {
      if (screenCenter != null) {
         return screenCenter;
      } else {
         Vector3f var1 = new Vector3f(0.0F, 0.0F, -1.0F).rotate(var0.getRotation());
         return var0.getCameraPos().add((double)var1.x, (double)var1.y, (double)var1.z);
      }
   }

   public static double deltaTime() {
      int var0 = MinecraftClient.getInstance().getCurrentFps();
      return var0 > 0 ? 1.0 / (double)var0 : 1.0;
   }

   public static float beginGuiFrame() {
      long var0 = System.nanoTime();
      if (lastGuiFrameNanos == 0L) {
         lastGuiFrameNanos = var0;
         return 1.0F;
      } else {
         float var2 = (float)(var0 - lastGuiFrameNanos) / 1.6666667E7F;
         lastGuiFrameNanos = var0;
         return MathHelper.clamp(var2, 0.1F, 3.0F);
      }
   }

   public static float fast(float var0, float var1, float var2) {
      float var3 = MathHelper.clamp((float)(deltaTime() * (double)var2), 0.0F, 1.0F);
      return (1.0F - var3) * var0 + var3 * var1;
   }

   public static Vec3d getPlayerLookVec(PlayerEntity var0) {
      float var1 = MathHelper.cos((double)(var0.getYaw() * (float) (Math.PI / 180.0) - (float) Math.PI));
      float var2 = MathHelper.sin((double)(var0.getYaw() * (float) (Math.PI / 180.0) - (float) Math.PI));
      float var3 = MathHelper.cos((double)(var0.getPitch() * (float) (Math.PI / 180.0)));
      return new Vec3d(
            (double)(var2 * var3), (double)MathHelper.sin((double)(var0.getPitch() * (float) (Math.PI / 180.0))), (double)(var1 * var3)
         )
         .normalize();
   }

   public static void unscaledProjection() {
      if (activeContext != null && !usingUnscaledProjection) {
         float var0 = (float)MinecraftClient.getInstance().getWindow().getScaleFactor();
         if (var0 <= 0.0F) {
            var0 = 1.0F;
         }

         activeContext.getMatrices().pushMatrix();
         activeContext.getMatrices().scale(1.0F / var0, 1.0F / var0);
         usingUnscaledProjection = true;
      }
   }

   public static void scaledProjection() {
      if (activeContext != null && usingUnscaledProjection) {
         activeContext.getMatrices().popMatrix();
         usingUnscaledProjection = false;
      }
   }

   public static void renderRoundedQuad(
      Matrix3x2fStack var0,
      Color var1,
      double var2,
      double var4,
      double var6,
      double var8,
      double var10,
      double var12,
      double var14,
      double var16,
      double var18
   ) {
      if (activeContext != null) {
         int var20 = (int)Math.floor(Math.min(var4, var8));
         int var21 = (int)Math.ceil(Math.max(var4, var8));
         double var22 = Math.min(var2, var6);
         double var24 = Math.max(var2, var6);
         double var26 = (double)(var21 - var20);
         double var28 = Math.min((var24 - var22) / 2.0, var26 / 2.0);
         double var30 = Math.min(Math.max(0.0, var10), var28);
         double var32 = Math.min(Math.max(0.0, var12), var28);
         double var34 = Math.min(Math.max(0.0, var14), var28);
         double var36 = Math.min(Math.max(0.0, var16), var28);
         int var38 = var20;
         int var39 = Integer.MIN_VALUE;
         int var40 = Integer.MIN_VALUE;

         for (int var41 = var20; var41 < var21; var41++) {
            double var42 = (double)var41 + 0.5;
            double var44 = cornerInset(var42 - (double)var20, var26, var30, var36);
            double var46 = cornerInset(var42 - (double)var20, var26, var32, var34);
            int var48 = (int)Math.ceil(var22 + var44);
            int var49 = (int)Math.floor(var24 - var46);
            if (var49 > var48) {
               if (var39 == Integer.MIN_VALUE) {
                  var38 = var41;
                  var39 = var48;
                  var40 = var49;
               } else if (var48 != var39 || var49 != var40) {
                  activeContext.fill(var39, var38, var40, var41, var1.getRGB());
                  var38 = var41;
                  var39 = var48;
                  var40 = var49;
               }
            }
         }

         if (var39 != Integer.MIN_VALUE) {
            activeContext.fill(var39, var38, var40, var21, var1.getRGB());
         }
      }
   }

   public static void renderRoundedQuad(Matrix3x2fStack var0, Color var1, double var2, double var4, double var6, double var8, double var10, double var12) {
      renderRoundedQuad(var0, var1, var2, var4, var6, var8, var10, var10, var10, var10, var12);
   }

   public static void renderCircle(Matrix3x2fStack var0, Color var1, double var2, double var4, double var6, int var8) {
      if (activeContext != null && !(var6 <= 0.0)) {
         int var9 = (int)Math.floor(var4 - var6);
         int var10 = (int)Math.ceil(var4 + var6);
         int var11 = var9;
         int var12 = Integer.MIN_VALUE;
         int var13 = Integer.MIN_VALUE;

         for (int var14 = var9; var14 < var10; var14++) {
            double var15 = (double)var14 + 0.5 - var4;
            double var17 = Math.sqrt(Math.max(0.0, var6 * var6 - var15 * var15));
            int var19 = (int)Math.ceil(var2 - var17);
            int var20 = (int)Math.floor(var2 + var17);
            if (var20 > var19) {
               if (var12 == Integer.MIN_VALUE) {
                  var11 = var14;
                  var12 = var19;
                  var13 = var20;
               } else if (var19 != var12 || var20 != var13) {
                  activeContext.fill(var12, var11, var13, var14, var1.getRGB());
                  var11 = var14;
                  var12 = var19;
                  var13 = var20;
               }
            }
         }

         if (var12 != Integer.MIN_VALUE) {
            activeContext.fill(var12, var11, var13, var10, var1.getRGB());
         }
      }
   }

   private static double cornerInset(double var0, double var2, double var4, double var6) {
      if (var4 > 0.0 && var0 < var4) {
         double var10 = var4 - var0;
         return var4 - Math.sqrt(Math.max(0.0, var4 * var4 - var10 * var10));
      } else if (var6 > 0.0 && var0 > var2 - var6) {
         double var8 = var0 - (var2 - var6);
         return var6 - Math.sqrt(Math.max(0.0, var6 * var6 - var8 * var8));
      } else {
         return 0.0;
      }
   }

   public static void renderRoundedOutline(
      DrawContext var0,
      Color var1,
      double var2,
      double var4,
      double var6,
      double var8,
      double var10,
      double var12,
      double var14,
      double var16,
      double var18,
      double var20
   ) {
      setContext(var0);
      if (!(var18 <= 0.0) && !(var6 <= var2) && !(var8 <= var4)) {
         int var22 = (int)Math.floor(var4);
         int var23 = (int)Math.ceil(var8);
         double var24 = var8 - var4;
         double var26 = Math.min((var6 - var2) / 2.0, var24 / 2.0);
         double var28 = Math.min(Math.max(0.0, var10), var26);
         double var30 = Math.min(Math.max(0.0, var12), var26);
         double var32 = Math.min(Math.max(0.0, var14), var26);
         double var34 = Math.min(Math.max(0.0, var16), var26);
         double var36 = var2 + var18;
         double var38 = var4 + var18;
         double var40 = var6 - var18;
         double var42 = var8 - var18;
         double var44 = Math.max(0.0, var42 - var38);

         for (int var46 = var22; var46 < var23; var46++) {
            double var47 = (double)var46 + 0.5;
            int var49 = (int)Math.ceil(var2 + cornerInset(var47 - var4, var24, var28, var34));
            int var50 = (int)Math.floor(var6 - cornerInset(var47 - var4, var24, var30, var32));
            if (var50 > var49) {
               if (!(var47 <= var38) && !(var47 >= var42) && !(var40 <= var36)) {
                  int var51 = (int)Math.ceil(var36 + cornerInset(var47 - var38, var44, Math.max(0.0, var28 - var18), Math.max(0.0, var34 - var18)));
                  int var52 = (int)Math.floor(var40 - cornerInset(var47 - var38, var44, Math.max(0.0, var30 - var18), Math.max(0.0, var32 - var18)));
                  if (var51 > var49) {
                     var0.fill(var49, var46, var51, var46 + 1, var1.getRGB());
                  }

                  if (var50 > var52) {
                     var0.fill(var52, var46, var50, var46 + 1, var1.getRGB());
                  }
               } else {
                  var0.fill(var49, var46, var50, var46 + 1, var1.getRGB());
               }
            }
         }
      }
   }

   public static void setScissorRegion(int var0, int var1, int var2, int var3) {
   }

   public static MatrixStack matrixFrom(double var0, double var2, double var4) {
      MatrixStack var6 = new MatrixStack();
      Camera var7 = getCamera();
      var6.multiply(RotationAxis.POSITIVE_X.rotationDegrees(var7.getPitch()));
      var6.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(var7.getYaw() + 180.0F));
      Vec3d var8 = var7.getCameraPos();
      var6.translate(var0 - var8.x, var2 - var8.y, var4 - var8.z);
      return var6;
   }

   public static void renderQuad(MatrixStack var0, float var1, float var2, float var3, float var4, int var5) {
   }

   public static void renderFilledBox(MatrixStack var0, float var1, float var2, float var3, float var4, float var5, float var6, Color var7) {
      renderFilledBoxes(var0, List.of(new RenderUtils.ColoredBox((double)var1, (double)var2, (double)var3, (double)var4, (double)var5, (double)var6, var7)));
   }

   public static void renderFilledBoxes(MatrixStack var0, Iterable<RenderUtils.ColoredBox> var1) {
      if (var0 != null && var1 != null) {
         RenderLayer var2 = RenderUtils.EspRenderLayers.FILLED;
         BufferBuilder var3 = null;
         Matrix4f var4 = var0.peek().getPositionMatrix();

         for (RenderUtils.ColoredBox var6 : var1) {
            if (var6 != null
               && var6.color() != null
               && var6.color().getAlpha() > 0
               && RenderVisibility.box(var6.x1(), var6.y1(), var6.z1(), var6.x2(), var6.y2(), var6.z2())) {
               if (var3 == null) {
                  var3 = Tessellator.getInstance().begin(var2.getDrawMode(), var2.getVertexFormat());
               }

               int var7 = var6.color().getRGB();
               float var8 = (float)(var6.x1() - worldRenderOrigin.x);
               float var9 = (float)(var6.y1() - worldRenderOrigin.y);
               float var10 = (float)(var6.z1() - worldRenderOrigin.z);
               float var11 = (float)(var6.x2() - worldRenderOrigin.x);
               float var12 = (float)(var6.y2() - worldRenderOrigin.y);
               float var13 = (float)(var6.z2() - worldRenderOrigin.z);
               quad(var3, var4, var7, var8, var9, var10, var11, var9, var10, var11, var12, var10, var8, var12, var10);
               quad(var3, var4, var7, var8, var9, var13, var8, var12, var13, var11, var12, var13, var11, var9, var13);
               quad(var3, var4, var7, var8, var9, var10, var8, var12, var10, var8, var12, var13, var8, var9, var13);
               quad(var3, var4, var7, var11, var9, var10, var11, var9, var13, var11, var12, var13, var11, var12, var10);
               quad(var3, var4, var7, var8, var9, var10, var8, var9, var13, var11, var9, var13, var11, var9, var10);
               quad(var3, var4, var7, var8, var12, var10, var11, var12, var10, var11, var12, var13, var8, var12, var13);
            }
         }

         BuiltBuffer var14 = var3 == null ? null : var3.endNullable();
         if (var14 != null) {
            var2.draw(var14);
         }
      }
   }

   public static void renderLine(MatrixStack var0, Color var1, Vec3d var2, Vec3d var3) {
      renderLines(var0, List.of(new RenderUtils.ColoredLine(var2, var3, var1)));
   }

   public static void applyCameraTransform(MatrixStack var0, Camera var1) {
      Vec3d var2 = var1.getCameraPos();
      worldRenderOrigin = var2;
      var0.multiply(new Quaternionf(var1.getRotation()).conjugate());
   }

   public static void addBoxOutline(
      List<RenderUtils.ColoredLine> var0, double var1, double var3, double var5, double var7, double var9, double var11, Color var13, float var14
   ) {
      if (var0 != null && var13 != null && var13.getAlpha() != 0 && RenderVisibility.box(var1, var3, var5, var7, var9, var11)) {
         Vec3d var15 = new Vec3d(var1, var3, var5);
         Vec3d var16 = new Vec3d(var7, var3, var5);
         Vec3d var17 = new Vec3d(var1, var9, var5);
         Vec3d var18 = new Vec3d(var7, var9, var5);
         Vec3d var19 = new Vec3d(var1, var3, var11);
         Vec3d var20 = new Vec3d(var7, var3, var11);
         Vec3d var21 = new Vec3d(var1, var9, var11);
         Vec3d var22 = new Vec3d(var7, var9, var11);
         var0.add(new RenderUtils.ColoredLine(var15, var16, var13, var14));
         var0.add(new RenderUtils.ColoredLine(var16, var20, var13, var14));
         var0.add(new RenderUtils.ColoredLine(var20, var19, var13, var14));
         var0.add(new RenderUtils.ColoredLine(var19, var15, var13, var14));
         var0.add(new RenderUtils.ColoredLine(var17, var18, var13, var14));
         var0.add(new RenderUtils.ColoredLine(var18, var22, var13, var14));
         var0.add(new RenderUtils.ColoredLine(var22, var21, var13, var14));
         var0.add(new RenderUtils.ColoredLine(var21, var17, var13, var14));
         var0.add(new RenderUtils.ColoredLine(var15, var17, var13, var14));
         var0.add(new RenderUtils.ColoredLine(var16, var18, var13, var14));
         var0.add(new RenderUtils.ColoredLine(var20, var22, var13, var14));
         var0.add(new RenderUtils.ColoredLine(var19, var21, var13, var14));
      }
   }

   public static void renderLines(MatrixStack var0, Iterable<RenderUtils.ColoredLine> var1) {
      if (var0 != null && var1 != null) {
         RenderLayer var2 = RenderUtils.EspRenderLayers.LINES;
         BufferBuilder var3 = null;
         Entry var4 = var0.peek();

         for (RenderUtils.ColoredLine var6 : var1) {
            if (var6 != null && var6.color() != null && var6.color().getAlpha() > 0 && var6.start() != null && var6.end() != null) {
               Vec3d var7 = var6.start();
               Vec3d var8 = var6.end();
               if (RenderVisibility.box(var7.x, var7.y, var7.z, var8.x, var8.y, var8.z)) {
                  double var9 = var7.x - worldRenderOrigin.x;
                  double var11 = var7.y - worldRenderOrigin.y;
                  double var13 = var7.z - worldRenderOrigin.z;
                  double var15 = var8.x - worldRenderOrigin.x;
                  double var17 = var8.y - worldRenderOrigin.y;
                  double var19 = var8.z - worldRenderOrigin.z;
                  float var21 = (float)(var15 - var9);
                  float var22 = (float)(var17 - var11);
                  float var23 = (float)(var19 - var13);
                  float var24 = MathHelper.sqrt(var21 * var21 + var22 * var22 + var23 * var23);
                  if (!(var24 <= 1.0E-4F)) {
                     var21 /= var24;
                     var22 /= var24;
                     var23 /= var24;
                     if (var3 == null) {
                        var3 = Tessellator.getInstance().begin(var2.getDrawMode(), var2.getVertexFormat());
                     }

                     int var25 = var6.color().getRGB();
                     float var26 = MathHelper.clamp(var6.width(), 1.0F, 10.0F);
                     var3.vertex(var4, (float)var9, (float)var11, (float)var13)
                        .color(var25)
                        .normal(var4, var21, var22, var23)
                        .lineWidth(var26);
                     var3.vertex(var4, (float)var15, (float)var17, (float)var19)
                        .color(var25)
                        .normal(var4, var21, var22, var23)
                        .lineWidth(var26);
                  }
               }
            }
         }

         BuiltBuffer var27 = var3 == null ? null : var3.endNullable();
         if (var27 != null) {
            var2.draw(var27);
         }
      }
   }

   private static void quad(
      BufferBuilder var0,
      Matrix4f var1,
      int var2,
      float var3,
      float var4,
      float var5,
      float var6,
      float var7,
      float var8,
      float var9,
      float var10,
      float var11,
      float var12,
      float var13,
      float var14
   ) {
      var0.vertex(var1, var3, var4, var5).color(var2);
      var0.vertex(var1, var6, var7, var8).color(var2);
      var0.vertex(var1, var9, var10, var11).color(var2);
      var0.vertex(var1, var12, var13, var14).color(var2);
   }

   public static void drawItem(DrawContext var0, ItemStack var1, int var2, int var3, float var4, int var5) {
      if (!var1.isEmpty()) {
         setContext(var0);
         Matrix3x2fStack var6 = var0.getMatrices();
         var6.pushMatrix();
         var6.translate((float)var2, (float)var3);
         float var7 = var4 / 16.0F;
         var6.scale(var7, var7);
         var0.drawItem(var1, 0, 0);
         var6.popMatrix();
      }
   }

   public static record ColoredBox(double x1, double y1, double z1, double x2, double y2, double z2, Color color) {
   }

   public static record ColoredLine(Vec3d start, Vec3d end, Color color, float width) {
      public ColoredLine(Vec3d var1, Vec3d var2, Color var3) {
         this(var1, var2, var3, 2.0F);
      }
   }

   private static final class EspRenderLayers {
      private static final RenderLayer FILLED = createFilled();
      private static final RenderLayer LINES = createLines();

      private static RenderLayer createFilled() {
         RenderPipeline var0 = RenderPipeline.builder(new Snippet[0])
            .withLocation(Identifier.of("krispy", "pipeline/esp_filled"))
            .withUniform("DynamicTransforms", UniformType.UNIFORM_BUFFER)
            .withUniform("Projection", UniformType.UNIFORM_BUFFER)
            .withVertexShader("core/position_color")
            .withFragmentShader("core/position_color")
            .withBlend(BlendFunction.TRANSLUCENT)
            .withCull(false)
            .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
            .withDepthWrite(false)
            .withVertexFormat(VertexFormats.POSITION_COLOR, DrawMode.QUADS)
            .build();
         var0 = RenderPipelinesAccessor.krispy$register(var0);
         return RenderLayerAccessor.krispy$create("krispy_esp_filled", RenderSetup.builder(var0).translucent().expectedBufferSize(1536).build());
      }

      private static RenderLayer createLines() {
         RenderPipeline var0 = RenderPipeline.builder(new Snippet[0])
            .withLocation(Identifier.of("krispy", "pipeline/esp_lines"))
            .withUniform("DynamicTransforms", UniformType.UNIFORM_BUFFER)
            .withUniform("Projection", UniformType.UNIFORM_BUFFER)
            .withUniform("Globals", UniformType.UNIFORM_BUFFER)
            .withVertexShader("core/rendertype_lines")
            .withFragmentShader("core/rendertype_lines")
            .withBlend(BlendFunction.TRANSLUCENT)
            .withCull(false)
            .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
            .withDepthWrite(false)
            .withVertexFormat(VertexFormats.POSITION_COLOR_NORMAL_LINE_WIDTH, DrawMode.LINES)
            .build();
         var0 = RenderPipelinesAccessor.krispy$register(var0);
         return RenderLayerAccessor.krispy$create("krispy_esp_lines", RenderSetup.builder(var0).translucent().expectedBufferSize(256).build());
      }
   }
}
