package krispy.utils;

import java.awt.Color;
import java.io.File;
import java.net.URISyntaxException;
import net.minecraft.util.math.Vec3d;
import org.joml.Vector3d;
import krispy.feature.UiPalette;

public final class Utils {
   public static Color getMainColor(int var0, int var1) {
      return UiPalette.accentColor(var0);
   }

   public static File getCurrentJarPath() throws URISyntaxException {
      return new File(Utils.class.getProtectionDomain().getCodeSource().getLocation().toURI().getPath());
   }

   public static void overwriteFile(String var0, File var1) {
   }

   public static void copyVector(Vector3d var0, Vec3d var1) {
      var0.x = var1.x;
      var0.y = var1.y;
      var0.z = var1.z;
   }
}
