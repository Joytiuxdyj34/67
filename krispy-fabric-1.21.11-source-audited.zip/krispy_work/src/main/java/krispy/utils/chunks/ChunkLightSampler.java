package krispy.utils.chunks;

import java.util.function.LongConsumer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.world.LightType;
import net.minecraft.block.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.block.BlockState;
import net.minecraft.world.chunk.ChunkNibbleArray;
import net.minecraft.world.chunk.WorldChunk;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.world.chunk.light.ChunkLightingView;
import net.minecraft.util.math.ChunkSectionPos;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.BlockPos.Mutable;

@Environment(EnvType.CLIENT)
public final class ChunkLightSampler {
   public static final int MIN_Y = -58;
   public static final int MAX_Y = 30;
   private static final int EDGE_LIGHT = 4;
   private static final int LOW_SECTION = -4;
   private static final int HIGH_SECTION = 1;
   private static final int FIRST_CACHED = -5;
   private static final int CACHED = 8;
   private static final Direction[] SIDES = Direction.values();
   private final ChunkNibbleArray[] layers = new ChunkNibbleArray[72];
   private final Mutable cursor = new Mutable();
   private int chunkX;
   private int chunkZ;

   public int scan(ClientWorld var1, WorldChunk var2, LongConsumer var3) {
      this.chunkX = var2.getPos().x;
      this.chunkZ = var2.getPos().z;
      if (!this.cacheLight(var1)) {
         return 0;
      } else {
         ChunkSection[] var4 = var2.getSectionArray();
         int var5 = this.chunkX << 4;
         int var6 = this.chunkZ << 4;
         int var7 = 0;

         for (int var8 = -4; var8 <= 1; var8++) {
            int var9 = var2.sectionCoordToIndex(var8);
            if (var9 >= 0 && var9 < var4.length && var4[var9] != null && this.nearLight(var8)) {
               ChunkSection var10 = var4[var9];
               if (var10.hasAny(ChunkLightSampler::open)) {
                  int var11 = Math.max(-58, var8 << 4);
                  int var12 = Math.min(30, (var8 << 4) + 15);

                  for (int var13 = var11; var13 <= var12; var13++) {
                     for (int var14 = 0; var14 < 16; var14++) {
                        for (int var15 = 0; var15 < 16; var15++) {
                           if (open(var10.getBlockState(var15, var13 & 15, var14))) {
                              int var16 = var5 + var15;
                              int var17 = var6 + var14;
                              if (this.lightAt(var16, var13, var17) == 0 && this.edge(var1, var16, var13, var17)) {
                                 var7++;
                                 if (var3 != null) {
                                    var3.accept(BlockPos.asLong(var16, var13, var17));
                                 }
                              }
                           }
                        }
                     }
                  }
               }
            }
         }

         return var7;
      }
   }

   private boolean cacheLight(ClientWorld var1) {
      ChunkLightingView var2 = var1.getLightingProvider().get(LightType.BLOCK);
      boolean var3 = false;

      for (int var4 = -1; var4 <= 1; var4++) {
         for (int var5 = -1; var5 <= 1; var5++) {
            for (int var6 = 0; var6 < 8; var6++) {
               ChunkNibbleArray var7 = var2.getLightSection(ChunkSectionPos.from(this.chunkX + var4, -5 + var6, this.chunkZ + var5));
               if (var7 != null && var7.isUninitialized()) {
                  var7 = null;
               }

               this.layers[slot(var4, var5, var6)] = var7;
               var3 |= var7 != null;
            }
         }
      }

      return var3;
   }

   private boolean nearLight(int var1) {
      for (int var2 = -1; var2 <= 1; var2++) {
         for (int var3 = -1; var3 <= 1; var3++) {
            for (int var4 = var1 - 1; var4 <= var1 + 1; var4++) {
               if (this.layers[slot(var2, var3, var4 - -5)] != null) {
                  return true;
               }
            }
         }
      }

      return false;
   }

   private boolean edge(ClientWorld var1, int var2, int var3, int var4) {
      boolean var5 = false;
      int var6 = 0;

      for (Direction var10 : SIDES) {
         int var11 = var2 + var10.getOffsetX();
         int var12 = var3 + var10.getOffsetY();
         int var13 = var4 + var10.getOffsetZ();
         int var14 = this.lightAt(var11, var12, var13);
         if (var14 > 4) {
            return false;
         }

         var6 = Math.max(var6, var14);
         if (var14 == 4 && !var5 && open(var1.getBlockState(this.cursor.set(var11, var12, var13)))) {
            var5 = true;
         }
      }

      return var6 == 4 && var5;
   }

   private int lightAt(int var1, int var2, int var3) {
      int var4 = (var2 >> 4) - -5;
      if (var4 >= 0 && var4 < 8) {
         ChunkNibbleArray var5 = this.layers[slot((var1 >> 4) - this.chunkX, (var3 >> 4) - this.chunkZ, var4)];
         return var5 == null ? 0 : var5.get(var1 & 15, var2 & 15, var3 & 15);
      } else {
         return 0;
      }
   }

   private static int slot(int var0, int var1, int var2) {
      return ((var0 + 1) * 3 + var1 + 1) * 8 + var2;
   }

   private static boolean open(BlockState var0) {
      return var0.isAir() || var0.isOf(Blocks.AMETHYST_CLUSTER);
   }

}
