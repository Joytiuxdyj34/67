package krispy.utils.ext;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.world.World;

@Environment(EnvType.CLIENT)
public final class DonutRegionTracker {
   private static final int OFF_MAP = Integer.MIN_VALUE;
   private ClientWorld level;
   private ClientPlayerEntity self;
   private String brand;
   private int goliath = OFF_MAP;

   public boolean moved(MinecraftClient client) {
      ClientWorld currentLevel = client.world;
      ClientPlayerEntity currentPlayer = client.player;
      if (currentLevel == null || currentPlayer == null) {
         clear();
         return false;
      }
      ClientPlayNetworkHandler network = client.getNetworkHandler();
      String currentBrand = network == null ? null : network.getBrand();
      int currentRegion = region(currentLevel, currentPlayer);
      boolean changed = level != null && (currentLevel != level
            || currentPlayer != self && !self.isDead()
            || currentRegion != goliath
            || currentBrand != null && brand != null && !currentBrand.equals(brand));
      level = currentLevel;
      self = currentPlayer;
      brand = currentBrand;
      goliath = currentRegion;
      return changed;
   }

   public void clear() {
      level = null;
      self = null;
      brand = null;
      goliath = OFF_MAP;
   }

   private static int region(ClientWorld level, ClientPlayerEntity player) {
      return level.getRegistryKey() == World.OVERWORLD
            ? DonutRegionGrid.goliathAt(player.getX(), player.getZ()) : OFF_MAP;
   }
}
