package krispy.utils.ext;

import krispy.utils.RenderVisibility;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.util.math.Vec3d;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.render.Camera;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;
import org.joml.Vector3f;
import org.joml.Vector3fc;
import org.joml.Vector4f;

@Environment(EnvType.CLIENT)
public final class TracerEngine {
   private static final float WIDTH = 1.0F;
   private static boolean active;
   private static Vec3d cameraPos = Vec3d.ZERO;
   private static Vec3d origin = Vec3d.ZERO;
   private static FoglessLines lines;
   private static final Matrix4f viewProjection = new Matrix4f();

   private TracerEngine() {
   }

   public static void beginFrame(Matrix4fc var0, Matrix4fc var1) {
      RenderVisibility.beginWorldFrame(var0, var1);
      active = false;
      lines = null;
      MinecraftClient var2 = MinecraftClient.getInstance();
      if (var2.player != null && var2.world != null && (var2.currentScreen == null || var2.currentScreen instanceof ChatScreen)) {
         Camera var3 = var2.gameRenderer.getCamera();
         if (var3 != null && var3.isReady()) {
            viewProjection.set(var1).mul(var0);
            Matrix4f var4 = viewProjection.invert(new Matrix4f());
            Vector4f var5 = var4.transform(new Vector4f(0.0F, 0.0F, 0.0F, 1.0F));
            Vector4f var6 = var4.transform(new Vector4f(0.0F, 0.0F, -1.0F, 0.0F));
            cameraPos = var3.getCameraPos();
            origin = cameraPos.add((double)(var5.x / var5.w), (double)(var5.y / var5.w), (double)(var5.z / var5.w));
            Vec3d var7 = cameraPos.add((double)(var6.x / var6.w), (double)(var6.y / var6.w), (double)(var6.z / var6.w));
            Vector3f var8 = new Vector3f(
                  (float)(origin.x - var7.x), (float)(origin.y - var7.y), (float)(origin.z - var7.z)
               )
               .normalize();
            double var9 = 2.0 / (double)(var1.m11() * (float)Math.max(1, var2.getWindow().getFramebufferHeight()));
            lines = FoglessLines.forView(var7, var8, var9);
            active = true;
         }
      }
   }

   public static void draw(Vec3d var0, int var1) {
      if (active) {
         lines.line(origin, var0, var1, 1.0F);
      }
   }

   public static void stem(Vec3d var0, double var1, int var3) {
      if (active) {
         lines.line(var0, var0.add(0.0, var1, 0.0), var3, 1.0F);
      }
   }

   public static Vector4f clip(Vec3d var0) {
      return !active
         ? null
         : viewProjection.transform(
            new Vector4f(
               (float)(var0.x - cameraPos.x),
               (float)(var0.y - cameraPos.y),
               (float)(var0.z - cameraPos.z),
               1.0F
            )
         );
   }

   public static boolean isInFront(Camera var0, Vec3d var1) {
      Vec3d var2 = var1.subtract(var0.getCameraPos());
      Vector3fc var3 = var0.getHorizontalPlane();
      return var2.x * (double)var3.x() + var2.y * (double)var3.y() + var2.z * (double)var3.z() > 0.05;
   }
}
