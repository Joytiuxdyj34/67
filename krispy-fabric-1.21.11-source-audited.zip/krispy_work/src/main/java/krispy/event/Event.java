package krispy.event;

public interface Event {
   default boolean isCancelled() {
      return false;
   }
}
