package krispy.event.events;

import krispy.event.Event;

public final class TotemPopEvent implements Event {
}
