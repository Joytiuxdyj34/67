package krispy.event.events;

import krispy.event.CancellableEvent;

public class AttackEvent extends CancellableEvent {
}
