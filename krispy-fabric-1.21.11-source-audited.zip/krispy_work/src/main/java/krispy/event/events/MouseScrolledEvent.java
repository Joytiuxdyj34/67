package krispy.event.events;

import krispy.event.CancellableEvent;

public class MouseScrolledEvent extends CancellableEvent {
   public double amount;

   public MouseScrolledEvent(double amount) {
      this.amount = amount;
   }
}
