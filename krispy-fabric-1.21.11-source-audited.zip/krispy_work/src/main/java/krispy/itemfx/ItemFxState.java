package krispy.itemfx;

import net.minecraft.client.render.item.ItemRenderState.LayerRenderState;

public interface ItemFxState {
   int krispy$fx();

   void krispy$setFx(int var1);

   LayerRenderState krispy$layer0();
}
