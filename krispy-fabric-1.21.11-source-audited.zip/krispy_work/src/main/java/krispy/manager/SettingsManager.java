package krispy.manager;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonPrimitive;
import java.awt.Color;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Locale;
import java.util.Map.Entry;
import krispy.Krispy;
import krispy.module.Module;
import krispy.module.setting.BindSetting;
import krispy.module.setting.BooleanSetting;
import krispy.module.setting.ChoiceSetting;
import krispy.module.setting.ItemSetting;
import krispy.module.setting.MinMaxSetting;
import krispy.module.setting.ModeSetting;
import krispy.module.setting.NumberSetting;
import krispy.module.setting.RgbSetting;
import krispy.module.setting.Setting;
import krispy.module.setting.StorageBlocksSetting;
import krispy.module.setting.StringSetting;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.item.Item;
import net.minecraft.util.Identifier;
import net.minecraft.registry.Registries;
import net.minecraft.registry.entry.RegistryEntry.Reference;

public final class SettingsManager {
   private static final Gson JSON = new GsonBuilder().setPrettyPrinting().create();
   private final Path settingsPath;
   private final JsonObject defaults;
   private final ConfigLibrary configs;

   public SettingsManager() {
      Path var1 = FabricLoader.getInstance().getConfigDir();
      this.settingsPath = var1.resolve("krispy.json");
      this.defaults = this.captureModules();

      for (Entry var3 : this.defaults.entrySet()) {
         ((JsonElement)var3.getValue()).getAsJsonObject().addProperty("enabled", false);
      }

      this.defaults.add("_layout", ConfigLayoutSupport.defaults());
      this.configs = new ConfigLibrary(var1.resolve("krispy-configs.json"), this::capture, this::apply, this::validate, this::resetAll);
   }

   public ConfigLibrary configs() {
      return this.configs;
   }

   private List<Module> modules() {
      return Krispy.INSTANCE.getModuleManager().c();
   }

   private static boolean client(Module var0) {
      return var0 instanceof krispy.module.modules.client.Krispy;
   }

   public synchronized JsonObject capture() {
      JsonObject var1 = this.captureModules();
      var1.add("_layout", ConfigLayoutSupport.capture());
      return var1;
   }

   private JsonObject captureModules() {
      JsonObject var1 = new JsonObject();

      for (Module var3 : this.modules()) {
         JsonObject var4 = new JsonObject();
         var4.addProperty("enabled", !client(var3) && var3.isEnabled());
         var4.addProperty("$keybind", var3.getKeybind());

         for (Setting var6 : var3.getSettings()) {
            JsonElement var7 = encode(var6);
            if (var7 != null) {
               var4.add(var6.getName().toString(), var7);
            }
         }

         var1.add(var3.getName().toString(), var4);
      }

      return var1;
   }

   private static JsonElement encode(Setting var0) {
      if (var0 instanceof BooleanSetting var14) {
         return new JsonPrimitive(var14.getValue());
      } else if (var0 instanceof ModeSetting var13) {
         return new JsonPrimitive(var13.getModeIndex());
      } else if (var0 instanceof NumberSetting var12) {
         return new JsonPrimitive(var12.getValue());
      } else if (var0 instanceof BindSetting var11) {
         return new JsonPrimitive(var11.getValue());
      } else if (var0 instanceof StringSetting var10) {
         return new JsonPrimitive(var10.getValue() == null ? "" : var10.getValue());
      } else if (var0 instanceof MinMaxSetting var9) {
         JsonObject var15 = new JsonObject();
         var15.addProperty("min", var9.getCurrentMin());
         var15.addProperty("max", var9.getCurrentMax());
         return var15;
      } else if (var0 instanceof ItemSetting var8) {
         return new JsonPrimitive(Registries.ITEM.getId(var8.getItem()).toString());
      } else if (var0 instanceof ChoiceSetting var7) {
         return new JsonPrimitive(var7.getMode());
      } else if (var0 instanceof RgbSetting var6) {
         return new JsonPrimitive(String.format(Locale.ROOT, "%08X", var6.getArgb()));
      } else if (!(var0 instanceof StorageBlocksSetting var1)) {
         return null;
      } else {
         JsonObject var2 = new JsonObject();

         for (StorageBlocksSetting.Entry var4 : var1.entries()) {
            JsonObject var5 = new JsonObject();
            var5.addProperty("enabled", var4.enabled());
            var5.addProperty("color", var4.color().getRGB() & 16777215);
            var2.add(var4.id(), var5);
         }

         return var2;
      }
   }

   public synchronized void validate(JsonObject var1) {
      if (var1 != null && var1.size() <= 512) {
         for (Module var3 : this.modules()) {
            JsonElement var4 = var1.get(var3.getName().toString());
            if (var4 != null) {
               if (!var4.isJsonObject()) {
                  throw new IllegalArgumentException("Invalid module settings.");
               }

               JsonObject var5 = var4.getAsJsonObject();
               if (var5.has("enabled")) {
                  bool(var5.get("enabled"));
               }

               if (var5.has("$keybind")) {
                  integer(var5.get("$keybind"), -1, 512);
               }

               for (Setting var7 : var3.getSettings()) {
                  JsonElement var8 = var5.get(var7.getName().toString());
                  if (var8 != null) {
                     try {
                        validateSetting(var7, var8);
                     } catch (RuntimeException var10) {
                        throw new IllegalArgumentException("Invalid value: " + var3.getName() + " / " + var7.getName());
                     }
                  }
               }
            }
         }

         if (var1.has("_layout")) {
            ConfigLayoutSupport.validate(var1.getAsJsonObject("_layout"));
         }
      } else {
         throw new IllegalArgumentException("Invalid config.");
      }
   }

   private static void validateSetting(Setting var0, JsonElement var1) {
      if (var0 instanceof BooleanSetting) {
         bool(var1);
      } else if (var0 instanceof ModeSetting var2) {
         integer(var1, -1, var2.getPossibleValues().size() - 1);
      } else if (var0 instanceof NumberSetting var3) {
         number(var1, var3.getMin(), var3.getMax());
      } else if (var0 instanceof BindSetting) {
         integer(var1, -1, 512);
      } else if (var0 instanceof StringSetting) {
         if (string(var1).length() > 4096) {
            throw new IllegalArgumentException();
         }
      } else if (var0 instanceof MinMaxSetting var4) {
         JsonObject var7 = var1.getAsJsonObject();
         double var8 = number(var7.get("min"), var4.getMinValue(), var4.getMaxValue());
         double var10 = number(var7.get("max"), var4.getMinValue(), var4.getMaxValue());
         if (var8 > var10) {
            throw new IllegalArgumentException();
         }
      } else if (var0 instanceof ItemSetting) {
         Identifier var12 = Identifier.tryParse(string(var1));
         if (var12 == null || Registries.ITEM.getEntry(var12).isEmpty()) {
            throw new IllegalArgumentException();
         }
      } else if (var0 instanceof ChoiceSetting var5) {
         if (!var5.getModes().contains(string(var1))) {
            throw new IllegalArgumentException();
         }
      } else if (var0 instanceof RgbSetting) {
         if (!string(var1).matches("[0-9a-fA-F]{6,8}")) {
            throw new IllegalArgumentException();
         }
      } else if (var0 instanceof StorageBlocksSetting var6) {
         JsonObject var13 = var1.getAsJsonObject();

         for (StorageBlocksSetting.Entry var9 : var6.entries()) {
            if (var13.has(var9.id())) {
               JsonObject var15 = var13.getAsJsonObject(var9.id());
               if (var15.has("enabled")) {
                  bool(var15.get("enabled"));
               }

               if (var15.has("color")) {
                  integer(var15.get("color"), 0, 16777215);
               }
            }
         }
      }
   }

   private static String string(JsonElement var0) {
      if (var0 != null && var0.isJsonPrimitive() && var0.getAsJsonPrimitive().isString()) {
         return var0.getAsString();
      } else {
         throw new IllegalArgumentException();
      }
   }

   private static boolean bool(JsonElement var0) {
      if (var0 != null && var0.isJsonPrimitive() && var0.getAsJsonPrimitive().isBoolean()) {
         return var0.getAsBoolean();
      } else {
         throw new IllegalArgumentException();
      }
   }

   private static double number(JsonElement var0, double var1, double var3) {
      if (var0 != null && var0.isJsonPrimitive() && var0.getAsJsonPrimitive().isNumber()) {
         double var5 = var0.getAsDouble();
         if (Double.isFinite(var5) && !(var5 < var1) && !(var5 > var3)) {
            return var5;
         } else {
            throw new IllegalArgumentException();
         }
      } else {
         throw new IllegalArgumentException();
      }
   }

   private static int integer(JsonElement var0, int var1, int var2) {
      double var3 = number(var0, (double)var1, (double)var2);
      if (var3 != Math.rint(var3)) {
         throw new IllegalArgumentException();
      } else {
         return (int)var3;
      }
   }

   private static void set(Setting var0, JsonElement var1, Module var2) {
      if (var0 instanceof BooleanSetting var3) {
         var3.setValue(var1.getAsBoolean());
      } else if (var0 instanceof ModeSetting var4) {
         int var13 = var1.getAsInt();
         var4.setModeIndex(var13 == -1 ? var4.getOriginalValue() : var13);
      } else if (var0 instanceof NumberSetting var5) {
         var5.getValue(var1.getAsDouble());
      } else if (var0 instanceof BindSetting var6) {
         var6.setValue(var1.getAsInt());
         var6.setListening(false);
         if (var6.isModuleKey()) {
            var2.setKeybind(var6.getValue());
         }
      } else if (var0 instanceof StringSetting var7) {
         var7.setValue(var1.getAsString());
      } else if (var0 instanceof MinMaxSetting var8) {
         JsonObject var17 = var1.getAsJsonObject();
         var8.setCurrentMin(var17.get("min").getAsDouble());
         var8.setCurrentMax(var17.get("max").getAsDouble());
      } else if (var0 instanceof ItemSetting var9) {
         var9.setItem((Item)((Reference)Registries.ITEM.getEntry(Identifier.of(var1.getAsString())).orElseThrow()).value());
      } else if (var0 instanceof ChoiceSetting var10) {
         var10.setMode(var1.getAsString());
      } else if (var0 instanceof RgbSetting var11) {
         var11.setArgb((int)Long.parseLong(var1.getAsString(), 16));
      } else if (var0 instanceof StorageBlocksSetting var12) {
         for (StorageBlocksSetting.Entry var14 : var12.entries()) {
            JsonElement var15 = var1.getAsJsonObject().get(var14.id());
            if (var15 != null) {
               JsonObject var16 = var15.getAsJsonObject();
               if (var16.has("enabled")) {
                  var14.setEnabled(var16.get("enabled").getAsBoolean());
               }

               if (var16.has("color")) {
                  var14.setColor(new Color(var16.get("color").getAsInt()));
               }
            }
         }
      }
   }

   public synchronized void apply(JsonObject var1) {
      this.validate(var1);
      JsonObject var2 = this.capture();

      try {
         this.applyInternal(var1);
         this.writeCurrent();
      } catch (RuntimeException var6) {
         try {
            this.applyInternal(var2);
         } catch (RuntimeException var5) {
            var6.addSuppressed(var5);
            throw new IllegalStateException("Couldn't apply the config. Some module states could not be restored.", var6);
         }

         throw new IllegalStateException("Couldn't apply this config; previous settings were restored.", var6);
      }
   }

   private void applyInternal(JsonObject var1) {
      for (Module var3 : this.modules()) {
         if (client(var3)) {
            var3.setEnabled(false);
         } else {
            var3.toggle(false);
         }
      }

      for (Module var12 : this.modules()) {
         String var4 = var12.getName().toString();
         JsonObject var5 = this.defaults.getAsJsonObject(var4).deepCopy();
         JsonElement var6 = var1.get(var4);
         if (var6 != null) {
            for (Entry var8 : var6.getAsJsonObject().entrySet()) {
               var5.add((String)var8.getKey(), (JsonElement)var8.getValue());
            }
         }

         var12.setKeybind(var5.get("$keybind").getAsInt());

         for (Setting var17 : var12.getSettings()) {
            JsonElement var9 = var5.get(var17.getName().toString());
            if (var9 != null) {
               set(var17, var9, var12);
            }
         }
      }

      if (var1.has("_layout")) {
         ConfigLayoutSupport.apply(var1.getAsJsonObject("_layout"));
      }

      for (Module var13 : this.modules()) {
         if (!client(var13)) {
            JsonElement var14 = var1.get(var13.getName().toString());
            boolean var15 = var14 != null
               && var14.isJsonObject()
               && var14.getAsJsonObject().has("enabled")
               && var14.getAsJsonObject().get("enabled").getAsBoolean();
            var13.toggle(var15);
         }
      }
   }

   public synchronized void resetAll() {
      this.apply(this.defaults.deepCopy());
   }

   public synchronized void loadProfile() {
      try {
         if (Files.isRegularFile(this.settingsPath)) {
            if (Files.size(this.settingsPath) > 1048576L) {
               throw new IllegalArgumentException("Settings file is too large");
            }

            JsonObject var1 = JsonParser.parseString(Files.readString(this.settingsPath)).getAsJsonObject();
            this.validate(var1);
            this.applyInternal(var1);
         }
      } catch (Exception var2) {
         System.err.println("Krispy: couldn't load settings: " + var2.getMessage());
      }
   }

   private void writeCurrent() {
      try {
         ConfigLibrary.writeAtomic(this.settingsPath, JSON.toJson(this.capture()));
      } catch (Exception var2) {
         throw new IllegalStateException("Couldn't save client settings.", var2);
      }
   }

   public synchronized void saveNow() {
      this.writeCurrent();
   }

   public synchronized void shutdown() {
      try {
         this.writeCurrent();
      } catch (Exception var2) {
         System.err.println("Krispy: couldn't save settings: " + var2.getMessage());
      }
   }
}
