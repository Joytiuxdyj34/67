package krispy.imixin;

public interface IKeybinding {
   boolean krispy$isActuallyPressed();

   void krispy$resetPressed();
}
