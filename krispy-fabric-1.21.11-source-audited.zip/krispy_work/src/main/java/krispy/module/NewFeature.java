package krispy.module;

public interface NewFeature {
}
