package krispy.module.ext.setting;

import krispy.module.setting.ButtonSetting;
import krispy.utils.EncryptedString;

public final class ActionSetting extends Setting {
   private final ButtonSetting backing;

   public ActionSetting(String var1, Runnable var2) {
      super(var1);
      this.backing = new ButtonSetting(EncryptedString.of(var1), var2);
   }

   public void run() {
      this.backing.run();
   }

   @Override
   public krispy.module.setting.Setting krispy() {
      return this.backing;
   }

   @Override
   protected Object snapshot() {
      return Boolean.TRUE;
   }
}
