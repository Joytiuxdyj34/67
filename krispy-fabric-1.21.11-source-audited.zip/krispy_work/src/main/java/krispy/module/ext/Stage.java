package krispy.module.ext;

public enum Stage {
   PRE,
   POST;
}
