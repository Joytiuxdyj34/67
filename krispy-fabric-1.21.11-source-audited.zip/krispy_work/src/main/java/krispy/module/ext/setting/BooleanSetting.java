package krispy.module.ext.setting;

import krispy.utils.EncryptedString;

public final class BooleanSetting extends Setting {
   private final krispy.module.setting.BooleanSetting backing;

   public BooleanSetting(String var1, boolean var2) {
      super(var1);
      this.backing = new krispy.module.setting.BooleanSetting(EncryptedString.of(var1), var2);
   }

   public boolean get() {
      return this.backing.getValue();
   }

   public void set(boolean var1) {
      if (this.backing.getValue() != var1) {
         this.backing.setValue(var1);
         this.notifyChanged();
      }
   }

   @Override
   public krispy.module.setting.Setting krispy() {
      return this.backing;
   }

   @Override
   protected Object snapshot() {
      return this.backing.getValue();
   }
}
