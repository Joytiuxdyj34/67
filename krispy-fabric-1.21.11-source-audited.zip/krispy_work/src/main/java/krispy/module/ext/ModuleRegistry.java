package krispy.module.ext;

import krispy.Krispy;
import krispy.module.Module;

public final class ModuleRegistry {
   private ModuleRegistry() {
   }

   public static <T extends Module> T get(Class<T> var0) {
      try {
         Module var1 = Krispy.INSTANCE.getModuleManager().getModuleByClass(var0);
         return (T)(var0.isInstance(var1) ? var0.cast(var1) : null);
      } catch (Throwable var2) {
         return null;
      }
   }
}
