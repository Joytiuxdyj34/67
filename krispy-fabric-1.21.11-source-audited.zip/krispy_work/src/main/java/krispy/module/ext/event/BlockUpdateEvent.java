package krispy.module.ext.event;

import net.minecraft.util.math.BlockPos;
import net.minecraft.block.BlockState;

public final class BlockUpdateEvent {
   public static final EventType<BlockUpdateEvent> TYPE = new EventType<>(BlockUpdateEvent.class);
   public BlockPos pos;
   public BlockState oldState;
   public BlockState newState;

   public BlockUpdateEvent(BlockPos var1, BlockState var2, BlockState var3) {
      this.pos = var1;
      this.oldState = var2;
      this.newState = var3;
   }
}
