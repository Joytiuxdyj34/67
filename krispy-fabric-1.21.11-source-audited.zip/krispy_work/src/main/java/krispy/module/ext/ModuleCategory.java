package krispy.module.ext;

import krispy.module.Category;

public final class ModuleCategory {
   public static final ModuleCategory COMBAT = new ModuleCategory(Category.COMBAT);
   public static final ModuleCategory MISC = new ModuleCategory(Category.MISC);
   public static final ModuleCategory DONUT = new ModuleCategory(Category.DONUT);
   public static final ModuleCategory RENDER = new ModuleCategory(Category.RENDER);
   public static final ModuleCategory CLIENT = new ModuleCategory(Category.CLIENT);
   public static final ModuleCategory MOVEMENT = MISC;
   public static final ModuleCategory BASE_RAID = DONUT;
   public static final ModuleCategory VISUALS = RENDER;
   private final Category krispy;

   private ModuleCategory(Category var1) {
      this.krispy = var1;
   }

   public Category krispy() {
      return this.krispy;
   }
}
