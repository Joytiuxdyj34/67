package krispy.module;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;
import krispy.event.EventListener;
import krispy.event.events.KeyEvent;
import krispy.event.events.MouseButtonEvent;
import krispy.module.modules.client.Krispy;
import krispy.module.setting.BindSetting;
import krispy.utils.EncryptedString;
import net.minecraft.client.gui.screen.ChatScreen;
import krispy.feature.KrispyClickGuiScreen;
import krispy.feature.AnchorMacroModule;
import krispy.feature.AutoCrystalModule;
import krispy.feature.AutoInvTotemModule;
import krispy.feature.AutoTotemModule;
import krispy.feature.DoubleAnchorModule;
import krispy.feature.ElytraSwapModule;
import krispy.feature.HitboxModule;
import krispy.feature.HoverTotemModule;
import krispy.feature.MaceSwapModule;
import krispy.feature.StaticHitboxesModule;
import krispy.feature.AntiTrapModule;
import krispy.feature.AntiVanishModule;
import krispy.feature.AuctionSniperModule;
import krispy.feature.AutoRtpModule;
import krispy.feature.AutoSellModule;
import krispy.feature.AutoSpawnerSellModule;
import krispy.feature.SpawnerDropperModule;
import krispy.feature.ChunkFinderModule;
import krispy.feature.ChunkFinderBetterModule;
import krispy.feature.FakeScoreboardModule;
import krispy.feature.LuckyFinderModule;
import krispy.feature.NetheriteFinderModule;
import krispy.feature.OgScoreboardModule;
import krispy.feature.PlayerBypassModule;
import krispy.feature.PrimeChunkFinderModule;
import krispy.feature.RegionMapModule;
import krispy.feature.RtpBaseFinderModule;
import krispy.feature.ShulkerDropperModule;
import krispy.feature.SpawnerOrderModule;
import krispy.feature.StaffListModule;
import krispy.feature.SusChunkFinderModule;
import krispy.feature.SusChunkV2Module;
import krispy.feature.TunnelBaseFinderModule;
import krispy.feature.SpawnerProtectModule;
import krispy.feature.AutoEatModule;
import krispy.feature.AutoFireworkModule;
import krispy.feature.AutoMineModule;
import krispy.feature.AutoTpaModule;
import krispy.feature.AutoToolModule;
import krispy.feature.CordSnapperModule;
import krispy.feature.ElytraGlideModule;
import krispy.feature.FakePayModule;
import krispy.feature.FastPlaceModule;
import krispy.feature.FreecamModule;
import krispy.feature.FreelookModule;
import krispy.feature.NameProtectModule;
import krispy.feature.PlayerDetectionModule;
import krispy.feature.SkinProtectModule;
import krispy.feature.SwingSpeedModule;
import krispy.feature.BedrockEspModule;
import krispy.feature.BlockEspModule;
import krispy.feature.BlockNotifierModule;
import krispy.feature.BlockOverlayModule;
import krispy.feature.CustomSkysModule;
import krispy.feature.CustomToolsModule;
import krispy.feature.CustomTotemModule;
import krispy.feature.HudModule;
import krispy.feature.HalloweenModule;
import krispy.feature.HandAuraModule;
import krispy.feature.ItemOutlineModule;
import krispy.feature.PlayerEspModule;
import krispy.feature.SpawnerNotifyModule;
import krispy.feature.StorageEspModule;
import krispy.feature.TargetHudModule;
import krispy.feature.Character3dModule;

public final class ModuleManager {
   private final List<Module> modules = new ArrayList<>();
   private final Map<Class<?>, Module> modulesByClass = new HashMap<>();
   private final Map<Category, List<Module>> modulesByCategory = new EnumMap<>(Category.class);

   public ModuleManager() {
      this.a();
      this.d();
   }

   public void a() {
      this.a(new ElytraSwapModule());
      this.a(new MaceSwapModule());
      this.a(new HitboxModule());
      this.a(new StaticHitboxesModule());
      this.a(new AutoTotemModule());
      this.a(new HoverTotemModule());
      this.a(new AutoInvTotemModule());
      this.a(new AnchorMacroModule());
      this.a(new AutoCrystalModule());
      this.a(new DoubleAnchorModule());
      this.a(new FastPlaceModule());
      this.a(new FreecamModule());
      this.a(new FreelookModule());
      this.a(new AutoFireworkModule());
      this.a(new ElytraGlideModule());
      this.a(new AutoToolModule());
      this.a(new SwingSpeedModule());
      this.a(new AutoEatModule());
      this.a(new AutoMineModule());
      this.a(new CordSnapperModule());
      this.a(new NameProtectModule());
      this.a(new SkinProtectModule());
      this.a(new PlayerDetectionModule());
      this.a(new FakePayModule());
      this.macro(new AutoTpaModule());
      this.macro(new AutoRtpModule());
      this.macro(new SpawnerProtectModule());
      this.a(new ChunkFinderModule());
      this.a(new SpawnerOrderModule());
      this.a(new RtpBaseFinderModule());
      this.a(new TunnelBaseFinderModule());
      this.a(new NetheriteFinderModule());
      this.macro(new SpawnerDropperModule());
      this.macro(new AutoSellModule());
      this.macro(new ShulkerDropperModule());
      this.a(new AntiTrapModule());

      try {
         this.macro(new AuctionSniperModule());
      } catch (RuntimeException var3) {
         System.err.println("Krispy: Auction Sniper unavailable: " + var3.getMessage());
      }

      this.macro(new AutoSpawnerSellModule());
      this.a(new FakeScoreboardModule());
      this.a(new OgScoreboardModule());
      this.a(new RegionMapModule());
      this.a(new PlayerBypassModule());
      this.a(new SusChunkFinderModule());
      this.a(new SusChunkV2Module());
      this.a(new ChunkFinderBetterModule());
      this.safe("Prime Chunk Finder", PrimeChunkFinderModule::new);
      this.safe("Anti Vanish", AntiVanishModule::new);
      this.safe("Halloween", HalloweenModule::new);
      this.safe("Custom Totem", CustomTotemModule::new);
      this.safe("Custom Tools", CustomToolsModule::new);
      this.a(new PlayerEspModule());
      this.a(new StorageEspModule());
      this.a(new BlockEspModule());
      this.a(new BlockNotifierModule());
      this.a(new BedrockEspModule());
      this.a(new SpawnerNotifyModule());
      this.a(new TargetHudModule());
      this.safe("3D Character", Character3dModule::new);
      this.safe("Custom Skys", CustomSkysModule::new);
      this.safe("Block Overlay", BlockOverlayModule::new);
      this.safe("Hand Aura", HandAuraModule::new);
      this.a(new Krispy());
      this.a(new HudModule());

      try {
         this.a(new ItemOutlineModule());
      } catch (Throwable var2) {
         System.err.println("Krispy: Item Outline unavailable: " + var2.getClass().getSimpleName());
      }

      this.a(new LuckyFinderModule());
      this.a(new StaffListModule());
   }

   public List<Module> b() {
      return this.modules.stream().filter(Module::isEnabled).toList();
   }

   public List<Module> c() {
      return this.modules;
   }

   public void d() {
      krispy.Krispy.INSTANCE.getEventBus().register(this);

      for (Module var2 : this.modules) {
         var2.addSetting(
            new BindSetting(EncryptedString.of("Keybind"), var2.getKeybind(), true).setDescription(EncryptedString.of("Key to enabled the module"))
         );
      }
   }

   public List<Module> a(Category var1) {
      return this.modulesByCategory.getOrDefault(var1, List.of());
   }

   public Module getModuleByClass(Class<? extends Module> var1) {
      Module var2 = this.modulesByClass.get(var1);
      if (var2 != null) {
         return var2;
      } else {
         for (Module var4 : this.modules) {
            if (var1.isInstance(var4)) {
               return var4;
            }
         }

         return null;
      }
   }

   private void safe(String var1, Supplier<? extends Module> var2) {
      try {
         this.a((Module)var2.get());
      } catch (Throwable var4) {
         System.err.println("Krispy: " + var1 + " unavailable: " + var4);
         var4.printStackTrace(System.err);
      }
   }

   private void macro(Module var1) {
      var1.setCategory(Category.MACROS);
      this.a(var1);
   }

   public void a(Module var1) {
      krispy.Krispy.INSTANCE.getEventBus().register(var1);
      this.modules.add(var1);
      this.modulesByClass.put(var1.getClass(), var1);
      this.modulesByCategory.computeIfAbsent(var1.getCategory(), var0 -> new ArrayList<>()).add(var1);
   }

   @EventListener
   public void a(KeyEvent var1) {
      if (var1.mode == 1 && (krispy.Krispy.mc == null || !(krispy.Krispy.mc.currentScreen instanceof KrispyClickGuiScreen var2) || !var2.isTyping())) {
         this.modules
            .forEach(
               var1x -> {
                  boolean var2x;
                  if (var1x.getKeybind() == var1.key
                     && (
                        (var2x = var1x instanceof Krispy)
                           || krispy.Krispy.mc.player != null && krispy.Krispy.mc.options != null && !(krispy.Krispy.mc.currentScreen instanceof ChatScreen)
                     )) {
                     var1x.toggle();
                  }
               }
            );
      }
   }

   @EventListener
   public void onMouseButton(MouseButtonEvent var1) {
      if (var1.actions == 1
         && var1.button >= 0
         && var1.button <= 7
         && !(krispy.Krispy.mc.currentScreen instanceof KrispyClickGuiScreen)
         && !(krispy.Krispy.mc.currentScreen instanceof ChatScreen)) {
         this.modules
            .forEach(
               var1x -> {
                  boolean var2;
                  if (var1x.getKeybind() == var1.button
                     && ((var2 = var1x instanceof Krispy) || krispy.Krispy.mc.player != null && krispy.Krispy.mc.options != null)) {
                     var1x.toggle();
                  }
               }
            );
      }
   }
}
