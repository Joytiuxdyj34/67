package krispy;

import java.io.File;
import krispy.manager.EventManager;
import krispy.manager.SettingsManager;
import krispy.module.ModuleManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import krispy.feature.KrispyClickGuiScreen;

public final class Krispy {
   public SettingsManager settingsManager;
   public ModuleManager MODULE_MANAGER;
   public EventManager EVENT_BUS;
   public static MinecraftClient mc;
   public String version;
   public static Krispy INSTANCE;
   public boolean shouldPreventClose;
   public KrispyClickGuiScreen GUI;
   public Screen screen;
   public long modified;
   public File jar;

   public Krispy() {
      try {
         INSTANCE = this;
         this.version = " b1.3";
         this.screen = null;
         this.EVENT_BUS = new EventManager();
         this.MODULE_MANAGER = new ModuleManager();
         this.GUI = new KrispyClickGuiScreen();
         this.settingsManager = new SettingsManager();
         this.getSettingsManager().loadProfile();
         this.jar = new File(Krispy.class.getProtectionDomain().getCodeSource().getLocation().toURI());
         this.modified = this.jar.lastModified();
         this.shouldPreventClose = false;
         mc = MinecraftClient.getInstance();
      } catch (Throwable var2) {
         var2.printStackTrace(System.err);
      }
   }

   public SettingsManager getSettingsManager() {
      return this.settingsManager;
   }

   public ModuleManager getModuleManager() {
      return this.MODULE_MANAGER;
   }

   public EventManager getEventBus() {
      return this.EVENT_BUS;
   }

   public void resetModifiedDate() {
      this.jar.setLastModified(this.modified);
   }
}
