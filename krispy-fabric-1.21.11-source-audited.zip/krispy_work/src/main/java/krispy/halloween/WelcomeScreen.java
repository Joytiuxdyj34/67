package krispy.halloween;

import net.minecraft.client.util.Window;
import net.minecraft.client.input.KeyInput;
import net.minecraft.client.gui.Click;
import net.minecraft.text.Text;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import krispy.feature.HalloweenWelcomeAnimation;
import krispy.feature.UiAudio;
import krispy.feature.MinecraftUiRenderer;

public final class WelcomeScreen extends Screen {
   private static final float EXIT_TIME = 0.6F;
   private final HalloweenWelcomeAnimation title = new HalloweenWelcomeAnimation();
   private float t;
   private float exit = -1.0F;
   private long last;
   private boolean done;

   public WelcomeScreen() {
      super(Text.literal("Welcome To Krispy Client"));
   }

   public boolean shouldPause() {
      return false;
   }

   public boolean shouldCloseOnEsc() {
      return false;
   }

   public void close() {
      this.proceed();
   }

   public void renderBackground(DrawContext var1, int var2, int var3, float var4) {
   }

   public void render(DrawContext var1, int var2, int var3, float var4) {
      if (this.client != null) {
         long var5 = System.nanoTime();
         float var7 = this.last == 0L ? 0.016F : Math.min(0.1F, (float)(var5 - this.last) / 1.0E9F);
         this.last = var5;
         this.t += var7;
         if (this.exit >= 0.0F) {
            this.exit = Math.min(1.0F, this.exit + var7 / 0.6F);
         }

         Window var8 = this.client.getWindow();
         int var9 = var8.getFramebufferWidth();
         int var10 = var8.getFramebufferHeight();
         float var11 = (float)var8.getScaleFactor();
         double var12 = this.client.mouse.getX() * (double)var9 / (double)Math.max(1, var8.getWidth());
         double var14 = this.client.mouse.getY() * (double)var10 / (double)Math.max(1, var8.getHeight());
         var1.getMatrices().pushMatrix();
         var1.getMatrices().scale(1.0F / var11, 1.0F / var11);

         try {
            this.title.render(new MinecraftUiRenderer(var1, var11), var9, var10, this.t, var7, Math.max(0.0F, this.exit), var12, var14);
         } finally {
            var1.getMatrices().popMatrix();
         }

         if (this.exit >= 1.0F && !this.done) {
            this.done = true;
            Halloween.titleFinished(this);
         }
      }
   }

   private double px(double var1) {
      return var1 * (this.client == null ? 1.0 : (double)this.client.getWindow().getScaleFactor());
   }

   public boolean mouseClicked(Click var1, boolean var2) {
      if (this.title.overContinue(this.px(var1.x()), this.px(var1.y()))) {
         this.proceed();
      }

      return true;
   }

   public boolean keyPressed(KeyInput var1) {
      int var2 = var1.key();
      if (var2 == 257 || var2 == 335 || var2 == 32 || var2 == 256) {
         this.proceed();
      }

      return true;
   }

   public void proceed() {
      if (this.exit < 0.0F && this.title.continueVisible()) {
         this.exit = 0.0F;
         this.title.pressed();
         UiAudio.play(UiAudio.Cue.CONFIRM);
      }
   }

   public boolean exiting() {
      return this.exit >= 0.0F;
   }
}
