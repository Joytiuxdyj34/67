package krispy.halloween;

import krispy.Krispy;
import krispy.itemfx.ItemFx;
import net.minecraft.client.MinecraftClient;
import net.minecraft.sound.SoundCategory;
import net.minecraft.client.world.ClientWorld;
import krispy.feature.KrispyClickGuiScreen;
import krispy.feature.UiAudio;
import krispy.feature.UiPalette;
import krispy.feature.HalloweenModule;

public final class Halloween {
   public static final float LOCK_SECONDS = 20.0F;
   private static Halloween.Phase phase = Halloween.Phase.IDLE;
   private static float phaseT;
   private static float lockLeft;
   private static long lastNanos;
   private static ClientWorld lastWorld;
   private static boolean moduleOn;
   private static WelcomeScreen welcome;
   public static float worstFrame;

   private Halloween() {
   }

   public static Halloween.Phase phase() {
      return phase;
   }

   public static void onModuleEnabled() {
      moduleOn = true;
      HalloweenAtmosphere.setWanted(true);
      MinecraftClient var0 = MinecraftClient.getInstance();
      if (var0.world != null && var0.player != null) {
         startEvent();
      }
   }

   public static void onModuleDisabled() {
      moduleOn = false;
      HalloweenAtmosphere.setWanted(false);
      HalloweenMusic.stopEvent();
      if (phase != Halloween.Phase.IDLE) {
         abort();
      }
   }

   public static void replayIntro() {
      MinecraftClient var0 = MinecraftClient.getInstance();
      if (moduleOn && phase == Halloween.Phase.IDLE && var0.world != null && var0.player != null) {
         startEvent();
      }
   }

   public static boolean guiLocked() {
      return phase != Halloween.Phase.IDLE || lockLeft > 0.0F;
   }

   public static void lockedNotice() {
      int var0 = Math.max(1, (int)Math.ceil((double)Math.max(lockLeft, phase != Halloween.Phase.IDLE ? 1.0F : 0.0F)));
      CinematicOverlay.notice(phase == Halloween.Phase.IDLE ? "Krispy unlocks in " + var0 + "s" : "Krispy unlocks after the Halloween intro");
   }

   private static void startEvent() {
      MinecraftClient var0 = MinecraftClient.getInstance();
      phase = Halloween.Phase.CLOSING;
      phaseT = 0.0F;
      lockLeft = 20.0F;
      WitchScene.preload();
      HalloweenMusic.playEvent(eventVolume());
      KrispyClickGuiScreen var1 = Krispy.INSTANCE != null ? Krispy.INSTANCE.GUI : null;
      if (var1 != null && var0.currentScreen == var1) {
         var1.requestClose();
      }

      CinematicOverlay.cinematic(true);
   }

   private static float eventVolume() {
      try {
         return (float)(HalloweenModule.eventVolume.getValue() / 100.0);
      } catch (Throwable var1) {
         return 0.6F;
      }
   }

   static void titleFinished(WelcomeScreen var0) {
      MinecraftClient var1 = MinecraftClient.getInstance();
      if (phase == Halloween.Phase.TITLE && var0 == welcome) {
         if (var1.currentScreen == var0) {
            var1.setScreen(null);
         }

         welcome = null;
         beginWitch();
      }
   }

   private static void beginWitch() {
      worstFrame = 0.0F;
      phase = Halloween.Phase.WITCH;
      phaseT = 0.0F;
      CinematicCamera.begin();
      if (!WitchScene.start()) {
         beginOutro();
      }
   }

   private static void beginOutro() {
      phase = Halloween.Phase.OUTRO;
      phaseT = 0.0F;
      CinematicCamera.release();
      CinematicOverlay.cinematic(false);
   }

   private static void abort() {
      MinecraftClient var0 = MinecraftClient.getInstance();
      if (welcome != null) {
         if (var0.currentScreen == welcome) {
            var0.setScreen(null);
         }

         welcome = null;
      }

      if (WitchScene.running()) {
         WitchScene.hurry();
         phase = Halloween.Phase.WITCH;
      } else {
         beginOutro();
      }

      lockLeft = Math.min(lockLeft, 1.5F);
   }

   public static void hardReset() {
      MinecraftClient var0 = MinecraftClient.getInstance();
      if (welcome != null && var0.currentScreen == welcome) {
         var0.setScreen(null);
      }

      welcome = null;
      phase = Halloween.Phase.IDLE;
      phaseT = 0.0F;
      lockLeft = 0.0F;
      CinematicCamera.reset();
      CinematicOverlay.reset();
      WitchScene.reset();
      HalloweenParticles.clear();
      HalloweenMusic.stopEvent();
   }

   public static void frame() {
      MinecraftClient var0 = MinecraftClient.getInstance();
      long var1 = System.nanoTime();
      float var3 = lastNanos == 0L ? 0.016F : Math.min(0.1F, (float)(var1 - lastNanos) / 1.0E9F);
      lastNanos = var1;
      float var4 = var0.isPaused() ? 0.0F : var3;
      if (var0.world != lastWorld) {
         if (lastWorld != null) {
            hardReset();
            HalloweenSky.release();
            HalloweenMist.release();
            HalloweenParticles.release();
         }

         lastWorld = var0.world;
      }

      HalloweenAtmosphere.frame(var4, var0);
      syncMenuMusic(var0);
      if (lockLeft > 0.0F) {
         lockLeft = Math.max(0.0F, lockLeft - var4);
      }

      phaseT += var4;
      if (phase == Halloween.Phase.WITCH) {
         worstFrame = Math.max(worstFrame, var3);
      }

      switch (phase) {
         case CLOSING:
            boolean var5 = Krispy.INSTANCE == null || var0.currentScreen != Krispy.INSTANCE.GUI;
            if (var0.world == null) {
               hardReset();
            } else if (var5 && phaseT > 0.35F || phaseT > 1.2F) {
               welcome = new WelcomeScreen();
               var0.setScreen(welcome);
               phase = Halloween.Phase.TITLE;
               phaseT = 0.0F;
            }
            break;
         case TITLE:
            if (welcome != null && var0.currentScreen != welcome && phaseT > 0.5F) {
               welcome = null;
               beginWitch();
            }
            break;
         case WITCH:
            WitchScene.update(var4);
            if (WitchScene.finished()) {
               beginOutro();
            }
            break;
         case OUTRO:
            if (!CinematicCamera.active() && phaseT > 1.2F) {
               phase = Halloween.Phase.IDLE;
               WitchScene.reset();
            }
      }

      HalloweenParticles.update(var4);
      ItemFx.frame();
      CinematicCamera.update(var4);
      CinematicOverlay.frame(var3);
   }

   private static void syncMenuMusic(MinecraftClient var0) {
      boolean var1 = false;
      float var2 = 0.35F;
      boolean var3 = true;

      try {
         KrispyClickGuiScreen var4 = Krispy.INSTANCE != null ? Krispy.INSTANCE.GUI : null;
         var1 = var4 != null
            && var4.showing()
            && UiPalette.selected() == UiPalette.Halloween
            && krispy.module.modules.client.Krispy.halloweenMusic.getValue();
         var2 = (float)(krispy.module.modules.client.Krispy.halloweenVolume.getValue() / 100.0);
         var3 = krispy.module.modules.client.Krispy.beatShake.getValue();
      } catch (Throwable var7) {
      }

      float var8 = 1.0F;

      try {
         var8 = var0.options.getSoundVolume(SoundCategory.MASTER);
      } catch (Throwable var6) {
      }

      HalloweenMusic.setMenuWanted(var1, var2);
      HalloweenMusic.setBeatEnabled(var3);
      HalloweenMusic.setEventVolume(eventVolume());
      UiAudio.setMaster(var8);
   }

   public static enum Phase {
      IDLE,
      CLOSING,
      TITLE,
      WITCH,
      OUTRO;
   }
}
