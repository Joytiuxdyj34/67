package krispy.halloween.witch;

import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;

public final class WitchRig {
   public final WitchAsset asset;
   public final int count;
   private final Matrix4f[] restLocal;
   private final Matrix4f[] invBind;
   private final Quaternionf[] bindRot;
   private final Quaternionf[] bindRotInv;
   public final Matrix4f[] world;
   public final Matrix4f[] skin;
   public final Quaternionf[] rot;
   public final Vector3f rootOffset = new Vector3f();
   private final Quaternionf tmpQ = new Quaternionf();

   public WitchRig(WitchAsset var1) {
      this.asset = var1;
      this.count = var1.jointNames.length;
      this.restLocal = new Matrix4f[this.count];
      this.invBind = new Matrix4f[this.count];
      this.bindRot = new Quaternionf[this.count];
      this.bindRotInv = new Quaternionf[this.count];
      this.world = new Matrix4f[this.count];
      this.skin = new Matrix4f[this.count];
      this.rot = new Quaternionf[this.count];

      for (int var2 = 0; var2 < this.count; var2++) {
         Matrix4f var3 = var1.bind[var2];
         this.invBind[var2] = new Matrix4f(var3).invert();
         int var4 = var1.parent[var2];
         this.restLocal[var2] = var4 < 0 ? new Matrix4f(var3) : new Matrix4f(var1.bind[var4]).invert().mul(var3);
         this.bindRot[var2] = var3.getNormalizedRotation(new Quaternionf());
         this.bindRotInv[var2] = new Quaternionf(this.bindRot[var2]).invert();
         this.world[var2] = new Matrix4f(var3);
         this.skin[var2] = new Matrix4f();
         this.rot[var2] = new Quaternionf();
      }
   }

   public void reset() {
      for (Quaternionf var4 : this.rot) {
         var4.identity();
      }

      this.rootOffset.zero();
   }

   public void solve() {
      for (int var1 = 0; var1 < this.count; var1++) {
         Matrix4f var2 = this.world[var1];
         int var3 = this.asset.parent[var1];
         if (var3 < 0) {
            var2.translation(this.rootOffset).mul(this.restLocal[var1]);
         } else {
            var2.set(this.world[var3]).mul(this.restLocal[var1]);
         }

         Quaternionf var4 = this.rot[var1];
         if (var4.x != 0.0F || var4.y != 0.0F || var4.z != 0.0F) {
            this.tmpQ.set(this.bindRotInv[var1]).mul(var4).mul(this.bindRot[var1]);
            var2.rotate(this.tmpQ);
         }

         this.skin[var1].set(var2).mul(this.invBind[var1]);
      }
   }

   public Vector3f position(int var1, Vector3f var2) {
      return this.world[var1].getTranslation(var2);
   }

   public Vector3f bindPosition(int var1, Vector3f var2) {
      return this.asset.bind[var1].getTranslation(var2);
   }
}
