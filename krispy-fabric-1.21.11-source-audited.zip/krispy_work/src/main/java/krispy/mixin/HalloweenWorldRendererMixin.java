package krispy.mixin;

import com.mojang.blaze3d.buffers.GpuBufferSlice;
import krispy.halloween.HalloweenSky;
import krispy.halloween.WitchScene;
import net.minecraft.client.render.state.WorldRenderState;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.render.WorldRenderer;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.util.memory.ObjectAllocator;
import org.joml.Matrix4f;
import org.joml.Vector4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({WorldRenderer.class})
public abstract class HalloweenWorldRendererMixin {
   @Inject(
      method = {"render"},
      at = {@At("HEAD")}
   )
   private void krispy$captureMatrices(
      ObjectAllocator var1,
      RenderTickCounter var2,
      boolean var3,
      Camera var4,
      Matrix4f var5,
      Matrix4f var6,
      Matrix4f var7,
      GpuBufferSlice var8,
      Vector4f var9,
      boolean var10,
      CallbackInfo var11
   ) {
      HalloweenSky.capture(var5, var6);
   }

   @Inject(
      method = {"pushEntityRenders"},
      at = {@At("TAIL")}
   )
   private void krispy$witch(MatrixStack var1, WorldRenderState var2, OrderedRenderCommandQueue var3, CallbackInfo var4) {
      if (WitchScene.running()) {
         WitchScene.render(MinecraftClient.getInstance().gameRenderer.getCamera().getCameraPos());
      }
   }
}
