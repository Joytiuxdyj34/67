package krispy.mixin;

import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import krispy.feature.AntiVanishHudOverlay;

@Mixin({InGameHud.class})
public abstract class ExtHudMixin {
   @Inject(
      method = {"render"},
      at = {@At("TAIL")}
   )
   private void krispy$extHud(DrawContext var1, RenderTickCounter var2, CallbackInfo var3) {
      AntiVanishHudOverlay.render(var1);
   }
}
