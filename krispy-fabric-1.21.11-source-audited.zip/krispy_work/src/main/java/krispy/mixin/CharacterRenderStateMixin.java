package krispy.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import krispy.feature.CharacterRenderStateAccess;
import krispy.feature.WornCharacterModel;

@Environment(EnvType.CLIENT)
@Mixin({PlayerEntityRenderState.class})
public abstract class CharacterRenderStateMixin implements CharacterRenderStateAccess {
   @Unique
   private WornCharacterModel krispy$character;
   @Unique
   private float krispy$seat;

   @Override
   public WornCharacterModel krispy$character() {
      return this.krispy$character;
   }

   @Override
   public void krispy$setCharacter(WornCharacterModel var1) {
      this.krispy$character = var1;
   }

   @Override
   public float krispy$seat() {
      return this.krispy$seat;
   }

   @Override
   public void krispy$setSeat(float var1) {
      this.krispy$seat = var1;
   }
}
