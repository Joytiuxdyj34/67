package krispy.mixin;

import net.minecraft.client.render.RenderSetup;
import net.minecraft.client.render.RenderLayer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin({RenderLayer.class})
public interface RenderLayerAccessor {
   @Invoker("of")
   static RenderLayer krispy$create(String var0, RenderSetup var1) {
      throw new AssertionError();
   }

   @Accessor(
      value = "renderSetup",
      remap = true
   )
   RenderSetup krispy$getRenderSetup();
}
