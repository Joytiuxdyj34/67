package krispy.mixin;

import java.util.List;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.model.BakedQuad;
import net.minecraft.item.ItemDisplayContext;
import net.minecraft.client.render.item.ItemRenderState.Glint;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import krispy.feature.ItemOutlineModule;

@Mixin(
   value = {net.minecraft.client.render.item.ItemRenderer.class}
)
public abstract class OutlineItemMixin {
   @Inject(
      method = {"renderItem"},
      at = {@At("HEAD")}
   )
   private static void krispy$outlineHeldItem(
      ItemDisplayContext var0, MatrixStack var1, VertexConsumerProvider var2, int var3, int var4, int[] var5, List<?> var6, RenderLayer var7, Glint var8, CallbackInfo var9
   ) {
      ItemOutlineModule.renderHeldItem(var0, var1, var2, var3, var4, var5, (List<BakedQuad>)(List<?>)var6, var7);
   }
}
