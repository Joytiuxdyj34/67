package krispy.mixin;

import net.minecraft.client.render.model.json.Transformation;
import net.minecraft.client.render.item.ItemRenderState.Glint;
import net.minecraft.client.render.item.ItemRenderState.LayerRenderState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin({LayerRenderState.class})
public interface ItemFxLayerAccessor {
   @Accessor(
      value = "transform",
      remap = true
   )
   Transformation krispy$transform();

   @Accessor(
      value = "glint",
      remap = true
   )
   Glint krispy$glint();
}
