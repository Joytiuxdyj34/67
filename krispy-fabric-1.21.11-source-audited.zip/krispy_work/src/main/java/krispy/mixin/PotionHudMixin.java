package krispy.mixin;

import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import krispy.feature.HudModule;

@Mixin({InGameHud.class})
public abstract class PotionHudMixin {
   @Inject(
      method = {"method_1765"},
      at = {@At("HEAD")},
      cancellable = true,
      remap = false
   )
   private void krispy$hidePotionHud(DrawContext var1, RenderTickCounter var2, CallbackInfo var3) {
      if (HudModule.HIDE_POTION_HUD.getValue()) {
         var3.cancel();
      }
   }
}
