package krispy.mixin;

import krispy.Krispy;
import krispy.imixin.IKeybinding;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.client.util.InputUtil.Key;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@Mixin({KeyBinding.class})
public abstract class KeyBindingMixin implements IKeybinding {
   @Shadow
   private Key boundKey;

   @Shadow
   public abstract void setPressed(boolean var1);

   @Override
   public boolean krispy$isActuallyPressed() {
      return InputUtil.isKeyPressed(Krispy.mc.getWindow(), this.boundKey.getCode());
   }

   @Override
   public void krispy$resetPressed() {
      this.setPressed(this.krispy$isActuallyPressed());
   }
}
