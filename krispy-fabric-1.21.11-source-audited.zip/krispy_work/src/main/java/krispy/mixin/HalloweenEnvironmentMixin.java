package krispy.mixin;

import krispy.halloween.HalloweenAtmosphere;
import net.minecraft.world.attribute.EnvironmentAttribute;
import net.minecraft.world.attribute.EnvironmentAttributeInterpolator;
import net.minecraft.world.attribute.EnvironmentAttributes;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({EnvironmentAttributeInterpolator.class})
public abstract class HalloweenEnvironmentMixin {
   @Inject(
      method = {"get"},
      at = {@At("RETURN")},
      cancellable = true
   )
   private void krispy$halloweenSky(EnvironmentAttribute<?> var1, float var2, CallbackInfoReturnable<Object> var3) {
      if (!(HalloweenAtmosphere.strength() <= 0.0F)) {
         Object var4 = var3.getReturnValue();
         if (var1 == EnvironmentAttributes.SKY_COLOR_VISUAL && var4 instanceof Integer var5) {
            var3.setReturnValue(HalloweenAtmosphere.skyColor(var5));
         } else if (var1 == EnvironmentAttributes.SUNRISE_SUNSET_COLOR_VISUAL && var4 instanceof Integer var6) {
            var3.setReturnValue(HalloweenAtmosphere.sunset(var6));
         } else if (var1 == EnvironmentAttributes.CLOUD_COLOR_VISUAL && var4 instanceof Integer var7) {
            var3.setReturnValue(HalloweenAtmosphere.clouds(var7));
         } else if (var1 == EnvironmentAttributes.STAR_BRIGHTNESS_VISUAL && var4 instanceof Float var8) {
            var3.setReturnValue(HalloweenAtmosphere.stars(var8));
         }
      }
   }
}
