package krispy.mixin;

import krispy.event.events.AttackBlockEvent;
import krispy.manager.EventManager;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({ClientPlayerInteractionManager.class})
public class ClientPlayerInteractionManagerMixin {
   @Inject(
      method = {"attackBlock"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onAttackBlock(BlockPos pos, Direction dir, CallbackInfoReturnable<Boolean> cir) {
      AttackBlockEvent event = new AttackBlockEvent(pos, dir);
      EventManager.b(event);
      if (event.isCancelled()) {
         cir.setReturnValue(false);
      }
   }
}
