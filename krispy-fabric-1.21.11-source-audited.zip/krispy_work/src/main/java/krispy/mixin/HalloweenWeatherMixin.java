package krispy.mixin;

import krispy.halloween.HalloweenMist;
import krispy.halloween.HalloweenParticles;
import net.minecraft.client.render.state.WeatherRenderState;
import net.minecraft.util.math.Vec3d;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.WeatherRendering;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({WeatherRendering.class})
public abstract class HalloweenWeatherMixin {
   @Inject(
      method = {"renderPrecipitation"},
      at = {@At("TAIL")}
   )
   private void krispy$mist(VertexConsumerProvider var1, Vec3d var2, WeatherRenderState var3, CallbackInfo var4) {
      HalloweenMist.draw(MinecraftClient.getInstance().gameRenderer.getCamera());
      HalloweenParticles.render(MinecraftClient.getInstance().gameRenderer.getCamera());
   }
}
