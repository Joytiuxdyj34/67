package krispy.mixin;

import krispy.halloween.HalloweenAtmosphere;
import krispy.halloween.HalloweenSky;
import net.minecraft.client.render.state.SkyRenderState;
import net.minecraft.client.render.Camera;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.client.render.SkyRendering;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({SkyRendering.class})
public abstract class HalloweenSkyMixin {
   @Inject(
      method = {"renderTopSky"},
      at = {@At("TAIL")}
   )
   private void krispy$halloweenSky(int var1, CallbackInfo var2) {
      HalloweenSky.draw();
   }

   @Inject(
      method = {"updateRenderState"},
      at = {@At("TAIL")}
   )
   private void krispy$moon(ClientWorld var1, float var2, Camera var3, SkyRenderState var4, CallbackInfo var5) {
      HalloweenAtmosphere.moonAngle(var4.moonAngle);
   }
}
