package krispy.mixin;

import krispy.halloween.HalloweenAtmosphere;
import net.minecraft.client.render.LightmapTextureManager;
import org.joml.Vector3f;
import org.joml.Vector3fc;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;

@Mixin({LightmapTextureManager.class})
public abstract class HalloweenLightmapMixin {
   private static final String PUT = "Lcom/mojang/blaze3d/buffers/Std140Builder;putFloat(F)Lcom/mojang/blaze3d/buffers/Std140Builder;";
   private static final String VEC = "Lcom/mojang/blaze3d/buffers/Std140Builder;putVec3(Lorg/joml/Vector3fc;)Lcom/mojang/blaze3d/buffers/Std140Builder;";

   @ModifyArg(
      method = {"update"},
      at = @At(
         value = "INVOKE",
         target = "Lcom/mojang/blaze3d/buffers/Std140Builder;putFloat(F)Lcom/mojang/blaze3d/buffers/Std140Builder;",
         ordinal = 1
      )
   )
   private float krispy$sky(float var1) {
      return HalloweenAtmosphere.lightmap(1, var1);
   }

   @ModifyArg(
      method = {"update"},
      at = @At(
         value = "INVOKE",
         target = "Lcom/mojang/blaze3d/buffers/Std140Builder;putFloat(F)Lcom/mojang/blaze3d/buffers/Std140Builder;",
         ordinal = 2
      )
   )
   private float krispy$block(float var1) {
      return HalloweenAtmosphere.lightmap(2, var1);
   }

   @ModifyArg(
      method = {"update"},
      at = @At(
         value = "INVOKE",
         target = "Lcom/mojang/blaze3d/buffers/Std140Builder;putFloat(F)Lcom/mojang/blaze3d/buffers/Std140Builder;",
         ordinal = 3
      )
   )
   private float krispy$nightVision(float var1) {
      return HalloweenAtmosphere.lightmap(3, var1);
   }

   @ModifyArg(
      method = {"update"},
      at = @At(
         value = "INVOKE",
         target = "Lcom/mojang/blaze3d/buffers/Std140Builder;putFloat(F)Lcom/mojang/blaze3d/buffers/Std140Builder;",
         ordinal = 5
      )
   )
   private float krispy$darken(float var1) {
      return HalloweenAtmosphere.lightmap(5, var1);
   }

   @ModifyArg(
      method = {"update"},
      at = @At(
         value = "INVOKE",
         target = "Lcom/mojang/blaze3d/buffers/Std140Builder;putFloat(F)Lcom/mojang/blaze3d/buffers/Std140Builder;",
         ordinal = 6
      )
   )
   private float krispy$gamma(float var1) {
      return HalloweenAtmosphere.lightmap(6, var1);
   }

   @ModifyArg(
      method = {"update"},
      at = @At(
         value = "INVOKE",
         target = "Lcom/mojang/blaze3d/buffers/Std140Builder;putVec3(Lorg/joml/Vector3fc;)Lcom/mojang/blaze3d/buffers/Std140Builder;",
         ordinal = 0
      )
   )
   private Vector3fc krispy$moonlight(Vector3fc var1) {
      return (Vector3fc)(HalloweenAtmosphere.strength() > 0.0F ? HalloweenAtmosphere.skyLight(new Vector3f(var1)) : var1);
   }
}
