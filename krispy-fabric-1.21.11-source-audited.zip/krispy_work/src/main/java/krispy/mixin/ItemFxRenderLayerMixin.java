package krispy.mixin;

import krispy.itemfx.ItemFxRenderer;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.BuiltBuffer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({RenderLayer.class})
public abstract class ItemFxRenderLayerMixin {
   @Inject(
      method = {"draw"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void krispy$drawFx(BuiltBuffer var1, CallbackInfo var2) {
      if (ItemFxRenderer.isMarker(this)) {
         ItemFxRenderer.flush(var1);
         var2.cancel();
      }
   }
}
