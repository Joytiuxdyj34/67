package krispy.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.DiffuseLighting;
import net.minecraft.client.render.DiffuseLighting.Type;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import krispy.feature.CharacterLighting;

@Environment(EnvType.CLIENT)
@Mixin({DiffuseLighting.class})
public abstract class CharacterLightingMixin {
   @Inject(
      method = {"setShaderLights"},
      at = {@At("HEAD")}
   )
   private void krispy$trackCharacterLighting(Type var1, CallbackInfo var2) {
      CharacterLighting.setup(var1);
   }
}
