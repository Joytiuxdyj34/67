package krispy.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.CloudRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import krispy.feature.CustomSkysModule;

@Environment(EnvType.CLIENT)
@Mixin({CloudRenderer.class})
public abstract class CustomSkysCloudMixin {
   @ModifyVariable(
      method = {"renderClouds"},
      at = @At("HEAD"),
      argsOnly = true,
      ordinal = 0
   )
   private int krispy$cloudColour(int var1) {
      CustomSkysModule var2 = CustomSkysModule.get();
      return var2 != null ? var2.clouds(var1) : var1;
   }
}
