package krispy.mixin;

import krispy.Krispy;
import net.minecraft.text.TextVisitFactory;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import krispy.feature.NameProtectModule;

@Mixin({TextVisitFactory.class})
public class TextVisitFactoryMixin {
   @ModifyArg(
      at = @At(
         value = "INVOKE",
         target = "Lnet/minecraft/text/TextVisitFactory;visitFormatted(Ljava/lang/String;ILnet/minecraft/text/Style;Lnet/minecraft/text/Style;Lnet/minecraft/text/CharacterVisitor;)Z",
         ordinal = 0
      ),
      method = {"visitFormatted(Ljava/lang/String;ILnet/minecraft/text/Style;Lnet/minecraft/text/CharacterVisitor;)Z"},
      index = 0
   )
   private static String adjustText(String s) {
      if (Krispy.INSTANCE != null && Krispy.INSTANCE.MODULE_MANAGER != null) {
         NameProtectModule nameprotect = (NameProtectModule)Krispy.INSTANCE.MODULE_MANAGER.getModuleByClass(NameProtectModule.class);
         return nameprotect != null && nameprotect.isEnabled() && s.contains(Krispy.mc.getSession().getUsername())
            ? s.replace(Krispy.mc.getSession().getUsername(), nameprotect.getFakeName())
            : s;
      } else {
         return s;
      }
   }
}
