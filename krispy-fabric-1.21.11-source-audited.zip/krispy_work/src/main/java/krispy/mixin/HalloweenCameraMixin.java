package krispy.mixin;

import krispy.halloween.CinematicCamera;
import net.minecraft.client.render.Camera;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArgs;
import org.spongepowered.asm.mixin.injection.invoke.arg.Args;

@Mixin({Camera.class})
public abstract class HalloweenCameraMixin {
   @ModifyArgs(
      method = {"update"},
      at = @At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/render/Camera;setRotation(FF)V",
         ordinal = 0
      )
   )
   private void krispy$cinematicRiding(Args var1) {
      krispy$apply(var1);
   }

   @ModifyArgs(
      method = {"update"},
      at = @At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/render/Camera;setRotation(FF)V",
         ordinal = 1
      )
   )
   private void krispy$cinematic(Args var1) {
      krispy$apply(var1);
   }

   @Unique
   private static void krispy$apply(Args var0) {
      if (CinematicCamera.active()) {
         float var1 = (Float)var0.get(0);
         float var2 = (Float)var0.get(1);
         var0.set(0, CinematicCamera.yaw(var1));
         var0.set(1, CinematicCamera.pitch(var2));
      }
   }
}
