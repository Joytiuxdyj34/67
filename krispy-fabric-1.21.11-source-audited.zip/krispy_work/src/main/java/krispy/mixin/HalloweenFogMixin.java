package krispy.mixin;

import krispy.halloween.HalloweenAtmosphere;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.LivingEntity;
import net.minecraft.client.render.Camera;
import net.minecraft.block.enums.CameraSubmersionType;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.client.render.fog.FogRenderer;
import net.minecraft.client.render.RenderTickCounter;
import org.joml.Vector4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArgs;
import org.spongepowered.asm.mixin.injection.invoke.arg.Args;

@Mixin({FogRenderer.class})
public abstract class HalloweenFogMixin {
   @ModifyArgs(
      method = {"applyFog"},
      at = @At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/render/fog/FogRenderer;applyFog(Ljava/nio/ByteBuffer;ILorg/joml/Vector4f;FFFFFF)V"
      )
   )
   private void krispy$halloweenFog(Args var1, Camera var2, int var3, RenderTickCounter var4, float var5, ClientWorld var6) {
      if (!(HalloweenAtmosphere.fogAmount() <= 0.0F) && var2.getSubmersionType() == CameraSubmersionType.NONE) {
         if (var2.getFocusedEntity() instanceof LivingEntity var7 && (var7.hasStatusEffect(StatusEffects.BLINDNESS) || var7.hasStatusEffect(StatusEffects.DARKNESS))) {
            return;
         }

         float[] var11 = new float[]{(Float)var1.get(3), (Float)var1.get(4), (Float)var1.get(5), (Float)var1.get(6), (Float)var1.get(7), (Float)var1.get(8)};
         Vector4f var12 = (Vector4f)var1.get(2);
         Vector4f var9 = new Vector4f(var12);
         HalloweenAtmosphere.fog(var11, var9);
         var1.set(2, var9);

         for (int var10 = 0; var10 < 6; var10++) {
            var1.set(3 + var10, var11[var10]);
         }
      }
   }
}
