package krispy.mixin;

import com.llamalad7.mixinextras.sugar.Local;
import krispy.Krispy;
import krispy.event.events.Render3DEvent;
import krispy.manager.EventManager;
import krispy.utils.RenderUtils;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.RenderTickCounter;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import krispy.feature.FreecamModule;

@Mixin({GameRenderer.class})
public abstract class GameRendererMixin {
   @Shadow
   @Final
   private Camera camera;

   @Shadow
   protected abstract float getFov(Camera var1, float var2, boolean var3);

   @Shadow
   public abstract Matrix4f getBasicProjectionMatrix(float var1);

   @Unique
   private static FreecamModule krispy$freecam() {
      try {
         return Krispy.INSTANCE != null && Krispy.INSTANCE.getModuleManager() != null
            ? (FreecamModule)Krispy.INSTANCE.getModuleManager().getModuleByClass(FreecamModule.class)
            : null;
      } catch (Throwable var1) {
         return null;
      }
   }

   @Inject(
      method = {"renderWorld"},
      at = {@At(
         value = "INVOKE_STRING",
         target = "Lnet/minecraft/util/profiler/Profiler;swap(Ljava/lang/String;)V",
         args = {"ldc=hand"}
      )}
   )
   private void onWorldRender(RenderTickCounter var1, CallbackInfo var2, @Local(ordinal = 0) Matrix4f var3, @Local(ordinal = 1) Matrix4f var4) {
      RenderUtils.updateScreenCenter(var3, var4);
      EventManager.b(new Render3DEvent(new MatrixStack(), new Matrix4f(var3), var1.getTickProgress(true)));
   }

   @Inject(
      method = {"shouldRenderBlockOutline"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onShouldRenderBlockOutline(CallbackInfoReturnable<Boolean> var1) {
      FreecamModule var2 = krispy$freecam();
      if (var2 != null && var2.isEnabled()) {
         var1.setReturnValue(false);
      }
   }
}
