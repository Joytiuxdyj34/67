package krispy.mixin;

import krispy.halloween.CinematicCamera;
import net.minecraft.entity.Entity;
import net.minecraft.client.MinecraftClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({Entity.class})
public abstract class HalloweenLookMixin {
   @Inject(
      method = {"changeLookDirection"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void krispy$lockLook(double var1, double var3, CallbackInfo var5) {
      if (CinematicCamera.inputLocked() && (Object)this == MinecraftClient.getInstance().player) {
         var5.cancel();
      }
   }
}
