package krispy.mixin;

import krispy.halloween.CinematicOverlay;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({InGameHud.class})
public abstract class HalloweenHudMixin {
   @Inject(
      method = {"render"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void krispy$cinematicHud(DrawContext var1, RenderTickCounter var2, CallbackInfo var3) {
      if (CinematicOverlay.hideHud()) {
         CinematicOverlay.render(var1);
         var3.cancel();
      }
   }

   @Inject(
      method = {"render"},
      at = {@At("TAIL")}
   )
   private void krispy$cinematicOverlay(DrawContext var1, RenderTickCounter var2, CallbackInfo var3) {
      CinematicOverlay.render(var1);
   }
}
