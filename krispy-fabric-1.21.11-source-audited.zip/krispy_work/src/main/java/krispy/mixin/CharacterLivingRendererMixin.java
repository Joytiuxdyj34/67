package krispy.mixin;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.entity.state.EntityRenderState;
import net.minecraft.client.render.entity.state.LivingEntityRenderState;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.entity.feature.FeatureRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import krispy.feature.Character3dModule;

@Environment(EnvType.CLIENT)
@Mixin({LivingEntityRenderer.class})
public abstract class CharacterLivingRendererMixin {
   @Inject(
      method = {"getRenderLayer"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void krispy$hideModelUnderCharacter(LivingEntityRenderState var1, boolean var2, boolean var3, boolean var4, CallbackInfoReturnable<RenderLayer> var5) {
      if (Character3dModule.hidesModel(var1)) {
         var5.setReturnValue(null);
      }
   }

   @WrapOperation(
      method = {"render"},
      at = {@At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/render/entity/feature/FeatureRenderer;render(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;ILnet/minecraft/client/render/entity/state/EntityRenderState;FF)V"
      )}
   )
   private void krispy$hideLayersUnderCharacter(
      FeatureRenderer<?, ?> var1, MatrixStack var2, OrderedRenderCommandQueue var3, int var4, EntityRenderState var5, float var6, float var7, Operation<Void> var8
   ) {
      if (!Character3dModule.hidesLayer(var1, var5)) {
         var8.call(new Object[]{var1, var2, var3, var4, var5, var6, var7});
      }
   }
}
