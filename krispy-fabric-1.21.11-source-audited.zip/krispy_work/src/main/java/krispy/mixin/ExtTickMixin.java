package krispy.mixin;

import krispy.module.ext.ExtBridge;
import krispy.module.ext.Stage;
import net.minecraft.client.MinecraftClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({MinecraftClient.class})
public abstract class ExtTickMixin {
   @Inject(
      method = {"tick"},
      at = {@At("HEAD")}
   )
   private void krispy$extTickStart(CallbackInfo var1) {
      ExtBridge.tick(Stage.PRE);
   }

   @Inject(
      method = {"tick"},
      at = {@At("RETURN")}
   )
   private void krispy$extTickEnd(CallbackInfo var1) {
      ExtBridge.tick(Stage.POST);
   }
}
